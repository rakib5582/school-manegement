import express, { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || 'edupulse-super-secret-jwt-key-2026-multi-tenant-secure-token';
const PORT = parseInt(process.env.PORT || '3000', 10);

// In-Memory Seed Data matching V2__seed_demo_data.sql
interface TenantData {
  id: string;
  code: string;
  name: string;
  subdomain: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  primaryColor: string;
  secondaryColor: string;
  planCode: string;
  planName: string;
  maxStudents: number;
  maxTeachers: number;
  status: string;
}

const tenants: TenantData[] = [
  {
    id: '11111111-1111-1111-1111-111111111111',
    code: 'GREENWOOD',
    name: 'Greenwood International Academy',
    subdomain: 'greenwood',
    contactEmail: 'contact@greenwood.edu',
    contactPhone: '+1 (555) 234-5678',
    address: '450 University Blvd, Cambridge, MA',
    primaryColor: '#4F46E5',
    secondaryColor: '#06B6D4',
    planCode: 'PREMIUM',
    planName: 'Enterprise Academy',
    maxStudents: 2500,
    maxTeachers: 150,
    status: 'ACTIVE',
  },
  {
    id: '22222222-2222-2222-2222-222222222222',
    code: 'OAKRIDGE',
    name: 'Oakridge Science & Arts School',
    subdomain: 'oakridge',
    contactEmail: 'info@oakridge.edu',
    contactPhone: '+1 (555) 876-5432',
    address: '124 Science Park Lane, Austin, TX',
    primaryColor: '#059669',
    secondaryColor: '#10B981',
    planCode: 'BASIC',
    planName: 'Standard Campus',
    maxStudents: 500,
    maxTeachers: 35,
    status: 'ACTIVE',
  },
];

interface UserData {
  id: string;
  tenantId: string | null;
  username: string;
  email: string;
  password: string;
  role: 'SUPER_ADMIN' | 'SCHOOL_ADMIN' | 'TEACHER' | 'STUDENT' | 'PARENT';
  firstName: string;
  lastName: string;
  phone?: string;
}

const users: UserData[] = [
  {
    id: '99999999-9999-9999-9999-999999999999',
    tenantId: null,
    username: 'superadmin',
    email: 'superadmin@saas-edupulse.com',
    password: 'DemoPassword@2026!',
    role: 'SUPER_ADMIN',
    firstName: 'Platform',
    lastName: 'SuperAdmin',
    phone: '+1 (800) 555-0199',
  },
  {
    id: '10000000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'admin_greenwood',
    email: 'admin@greenwood.edu',
    password: 'DemoPassword@2026!',
    role: 'SCHOOL_ADMIN',
    firstName: 'Eleanor',
    lastName: 'Vance',
    phone: '+1 (555) 234-5601',
  },
  {
    id: '10000000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'teacher_sarah',
    email: 'teacher.sarah@greenwood.edu',
    password: 'DemoPassword@2026!',
    role: 'TEACHER',
    firstName: 'Sarah',
    lastName: 'Jenkins',
    phone: '+1 (555) 234-5602',
  },
  {
    id: '10000000-0000-0000-0000-000000000003',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'teacher_david',
    email: 'teacher.david@greenwood.edu',
    password: 'DemoPassword@2026!',
    role: 'TEACHER',
    firstName: 'David',
    lastName: 'Miller',
    phone: '+1 (555) 234-5603',
  },
  {
    id: '10000000-0000-0000-0000-000000000004',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'parent_robert',
    email: 'parent.robert@greenwood.edu',
    password: 'DemoPassword@2026!',
    role: 'PARENT',
    firstName: 'Robert',
    lastName: 'Rivera',
    phone: '+1 (555) 234-5604',
  },
  {
    id: '10000000-0000-0000-0000-000000000005',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'student_alex',
    email: 'student.alex@greenwood.edu',
    password: 'DemoPassword@2026!',
    role: 'STUDENT',
    firstName: 'Alex',
    lastName: 'Rivera',
    phone: '+1 (555) 234-5605',
  },
  {
    id: '10000000-0000-0000-0000-000000000006',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'student_sophia',
    email: 'student.sophia@greenwood.edu',
    password: 'DemoPassword@2026!',
    role: 'STUDENT',
    firstName: 'Sophia',
    lastName: 'Chen',
    phone: '+1 (555) 234-5606',
  },
  {
    id: '20000000-0000-0000-0000-000000000001',
    tenantId: '22222222-2222-2222-2222-222222222222',
    username: 'admin_oakridge',
    email: 'admin@oakridge.edu',
    password: 'DemoPassword@2026!',
    role: 'SCHOOL_ADMIN',
    firstName: 'Marcus',
    lastName: 'Sterling',
    phone: '+1 (555) 876-5401',
  },
];

// In-Memory Database stores
let classes = [
  { id: '10200000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Grade 10', numericGrade: 10 },
  { id: '10200000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Grade 9', numericGrade: 9 },
];

let sections = [
  { id: '10300000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', classId: '10200000-0000-0000-0000-000000000001', name: 'Section A', capacity: 35 },
  { id: '10300000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', classId: '10200000-0000-0000-0000-000000000001', name: 'Section B', capacity: 35 },
];

let subjects = [
  { id: '10400000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Mathematics', code: 'MATH-101', type: 'THEORY', fullMarks: 100, passMarks: 40 },
  { id: '10400000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Physics', code: 'PHY-102', type: 'PRACTICAL', fullMarks: 100, passMarks: 40 },
  { id: '10400000-0000-0000-0000-000000000003', tenantId: '11111111-1111-1111-1111-111111111111', name: 'English Literature', code: 'ENG-103', type: 'THEORY', fullMarks: 100, passMarks: 40 },
  { id: '10400000-0000-0000-0000-000000000004', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Computer Science', code: 'CS-104', type: 'PRACTICAL', fullMarks: 100, passMarks: 40 },
];

let teachers = [
  {
    id: '10500000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000002',
    employeeId: 'T-GW-001',
    fullName: 'Sarah Jenkins',
    email: 'teacher.sarah@greenwood.edu',
    phone: '+1 (555) 234-5602',
    designation: 'Senior Mathematics Teacher',
    department: 'Science & Mathematics',
    qualification: 'M.Sc in Applied Mathematics',
    joiningDate: '2021-08-15',
    salary: 5200.0,
    status: 'ACTIVE',
  },
  {
    id: '10500000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000003',
    employeeId: 'T-GW-002',
    fullName: 'David Miller',
    email: 'teacher.david@greenwood.edu',
    phone: '+1 (555) 234-5603',
    designation: 'Physics Faculty Lead',
    department: 'Science & Mathematics',
    qualification: 'Ph.D in Physics',
    joiningDate: '2020-07-01',
    salary: 5800.0,
    status: 'ACTIVE',
  },
];

let parents = [
  {
    id: '10600000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000004',
    fullName: 'Robert Rivera',
    email: 'parent.robert@greenwood.edu',
    phone: '+1 (555) 234-5604',
    occupation: 'Architect',
    relationship: 'Father',
    wardCount: 1,
  },
];

let students = [
  {
    id: '10700000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000005',
    parentId: '10600000-0000-0000-0000-000000000001',
    admissionNumber: 'GW-2026-0101',
    rollNumber: '101',
    fullName: 'Alex Rivera',
    email: 'student.alex@greenwood.edu',
    phone: '+1 (555) 234-5605',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    className: 'Grade 10',
    sectionName: 'Section A',
    gender: 'Male',
    dateOfBirth: '2010-04-12',
    bloodGroup: 'O+',
    status: 'ACTIVE',
  },
  {
    id: '10700000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000006',
    parentId: null,
    admissionNumber: 'GW-2026-0102',
    rollNumber: '102',
    fullName: 'Sophia Chen',
    email: 'student.sophia@greenwood.edu',
    phone: '+1 (555) 234-5606',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    className: 'Grade 10',
    sectionName: 'Section A',
    gender: 'Female',
    dateOfBirth: '2010-08-25',
    bloodGroup: 'A+',
    status: 'ACTIVE',
  },
];

let attendanceRecords = [
  {
    id: '10800000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000001',
    attendanceDate: new Date().toISOString().split('T')[0],
    status: 'PRESENT',
    remarks: 'On time',
  },
  {
    id: '10800000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000002',
    attendanceDate: new Date().toISOString().split('T')[0],
    status: 'PRESENT',
    remarks: 'On time',
  },
];

let exams = [
  {
    id: '10900000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    name: 'Mid-Term Examinations 2026',
    startDate: '2026-10-15',
    endDate: '2026-10-25',
    published: true,
  },
];

let marks = [
  {
    id: '10910000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    examId: '10900000-0000-0000-0000-000000000001',
    studentId: '10700000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000001',
    obtainedMarks: 94.5,
    totalMarks: 100.0,
    grade: 'A+',
    remarks: 'Outstanding analytical problem solving',
  },
  {
    id: '10910000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    examId: '10900000-0000-0000-0000-000000000001',
    studentId: '10700000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000002',
    obtainedMarks: 88.0,
    totalMarks: 100.0,
    grade: 'A',
    remarks: 'Strong laboratory performance',
  },
];

let invoices = [
  {
    id: '11100000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000001',
    studentName: 'Alex Rivera',
    invoiceNumber: 'INV-GW-2026-0042',
    title: 'October 2026 Tuition & Lab Fee',
    totalAmount: 450.0,
    paidAmount: 450.0,
    dueAmount: 0.0,
    dueDate: '2026-10-25',
    status: 'PAID',
  },
  {
    id: '11100000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000002',
    studentName: 'Sophia Chen',
    invoiceNumber: 'INV-GW-2026-0043',
    title: 'October 2026 Tuition & Lab Fee',
    totalAmount: 450.0,
    paidAmount: 0.0,
    dueAmount: 450.0,
    dueDate: '2026-10-25',
    status: 'UNPAID',
  },
];

let payments = [
  {
    id: '11200000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    invoiceId: '11100000-0000-0000-0000-000000000001',
    receiptNumber: 'REC-GW-90412',
    amount: 450.0,
    paymentMethod: 'ONLINE',
    transactionId: 'TXN_CH_994827101',
    paidAt: new Date().toISOString(),
  },
];

let routines = [
  {
    id: '11300000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000001',
    teacherId: '10500000-0000-0000-0000-000000000001',
    dayOfWeek: 'MONDAY',
    startTime: '08:30:00',
    endTime: '09:20:00',
    roomNumber: 'Room 301',
  },
  {
    id: '11300000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000002',
    teacherId: '10500000-0000-0000-0000-000000000002',
    dayOfWeek: 'MONDAY',
    startTime: '09:30:00',
    endTime: '10:20:00',
    roomNumber: 'Physics Lab A',
  },
];

let assignments = [
  {
    id: '11400000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000001',
    teacherId: '10500000-0000-0000-0000-000000000001',
    title: 'Quadratic Equations & Complex Numbers',
    description: 'Solve problem set exercises 4.1 to 4.5 from the textbook and show all derivation steps.',
    dueDate: '2026-10-22',
    totalPoints: 20,
    className: 'Grade 10',
    sectionName: 'Section A',
    subjectName: 'Mathematics',
  },
];

let notices = [
  {
    id: '11410000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Annual Science Exhibition 2026',
    content: 'All grade 9 and 10 students are requested to finalize project proposals by October 20th.',
    targetAudience: 'ALL',
    publishedDate: new Date().toISOString().split('T')[0],
  },
  {
    id: '11410000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Quarterly Parent-Teacher Conference',
    content: 'Parent teacher conference scheduled for upcoming Saturday in the Main Auditorium.',
    targetAudience: 'PARENTS',
    publishedDate: new Date().toISOString().split('T')[0],
  },
];

let events = [
  {
    id: '11500000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'National Science Olympiad Qualifiers',
    description: 'Inter-school STEM competition across biology, chemistry and coding.',
    eventDate: '2026-11-05',
    eventType: 'GENERAL',
  },
  {
    id: '11500000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Autumn Break',
    description: 'School campus closed for fall holidays.',
    eventDate: '2026-10-28',
    eventType: 'HOLIDAY',
  },
];

let books = [
  {
    id: '11600000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Introduction to Algorithms (4th Edition)',
    author: 'Cormen, Leiserson, Rivest, Stein',
    isbn: '978-0262046305',
    totalCopies: 12,
    availableCopies: 9,
    rackNumber: 'CS-Rack-02',
  },
  {
    id: '11600000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'University Physics with Modern Physics',
    author: 'Young and Freedman',
    isbn: '978-0135159552',
    totalCopies: 15,
    availableCopies: 11,
    rackNumber: 'PHY-Rack-01',
  },
];

let transportRoutes = [
  {
    id: '11700000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    routeName: 'Route 1: North Cambridge & Harvard Square',
    vehicleNumber: 'BUS-GW-01',
    driverName: 'Samuel Jackson',
    driverPhone: '+1 (555) 345-6789',
    fareMonthly: 65.0,
  },
];

let hostels = [
  {
    id: '11800000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    buildingName: 'Newton Hall (Senior Boys Dorm)',
    roomNumber: 'N-204',
    bedCount: 4,
    monthlyFee: 220.0,
  },
];

// Helper: generate signed JWT
function signToken(payload: object): string {
  const header = { alg: 'HS256', typ: 'JWT' };
  const b64Header = Buffer.from(JSON.stringify(header)).toString('base64url');
  const b64Payload = Buffer.from(JSON.stringify({ ...payload, iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + 86400 * 7 })).toString('base64url');
  const signature = crypto.createHmac('sha256', JWT_SECRET).update(`${b64Header}.${b64Payload}`).digest('base64url');
  return `${b64Header}.${b64Payload}.${signature}`;
}

// Helper: verify JWT
function verifyToken(token: string): any | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [b64Header, b64Payload, signature] = parts;
    const expected = crypto.createHmac('sha256', JWT_SECRET).update(`${b64Header}.${b64Payload}`).digest('base64url');
    if (signature !== expected) return null;
    const payload = JSON.parse(Buffer.from(b64Payload, 'base64url').toString('utf8'));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch {
    return null;
  }
}

// Middleware: Authenticate JWT and extract tenant
interface AuthenticatedRequest extends Request {
  user?: {
    userId: string;
    username: string;
    email: string;
    role: string;
    tenantId: string | null;
  };
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Authorization Bearer token required' });
  }

  const token = authHeader.substring(7);
  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ success: false, message: 'Invalid or expired JWT token' });
  }

  req.user = decoded;
  next();
}

function optionalAuthMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    const decoded = verifyToken(token);
    if (decoded) req.user = decoded;
  }
  next();
}

// Create Express app
const app = express();
app.use(express.json());

// API Response Helpers
function apiOk(res: Response, data: any, message: string = 'Operation completed successfully', status: number = 200) {
  return res.status(status).json({
    success: true,
    message,
    data,
    timestamp: new Date().toISOString(),
  });
}

function apiError(res: Response, message: string, status: number = 400, errors?: any) {
  return res.status(status).json({
    success: false,
    message,
    errors,
    timestamp: new Date().toISOString(),
  });
}

function pageResponse(content: any[], page: number = 0, size: number = 20) {
  const total = content.length;
  const start = page * size;
  const pagedContent = content.slice(start, start + size);
  return {
    content: pagedContent,
    pageNumber: page,
    pageSize: size,
    totalElements: total,
    totalPages: Math.ceil(total / size) || 1,
    isLast: start + size >= total,
  };
}

// -------------------------------------------------------------
// 1. AUTH & ONBOARDING ROUTES
// -------------------------------------------------------------
app.post('/api/v1/auth/login', (req, res) => {
  const { emailOrUsername, password } = req.body;
  if (!emailOrUsername || !password) {
    return apiError(res, 'Email/username and password are required', 400);
  }

  const lower = emailOrUsername.trim().toLowerCase();
  const user = users.find(u => u.email.toLowerCase() === lower || u.username.toLowerCase() === lower);

  if (!user) {
    return apiError(res, 'Invalid email or username. User not found.', 401);
  }

  // Allow standard demo credentials or matching password
  const isValid =
    password === user.password ||
    password === 'DemoPassword@2026!' ||
    password === 'password123' ||
    password === 'admin123';

  if (!isValid) {
    return apiError(res, 'Invalid credentials. Password verification failed.', 401);
  }

  const tenant = user.tenantId ? tenants.find(t => t.id === user.tenantId) : null;
  const token = signToken({
    sub: user.username,
    userId: user.id,
    email: user.email,
    role: user.role,
    tenantId: user.tenantId,
  });

  return apiOk(
    res,
    {
      token,
      tokenType: 'Bearer',
      userId: user.id,
      tenantId: user.tenantId,
      tenantCode: tenant ? tenant.code : null,
      schoolName: tenant ? tenant.name : null,
      username: user.username,
      email: user.email,
      fullName: `${user.firstName} ${user.lastName}`,
      role: user.role,
    },
    'Login successful'
  );
});

app.post('/api/v1/auth/register-school', (req, res) => {
  const {
    schoolCode,
    schoolName,
    contactEmail,
    contactPhone,
    address,
    adminUsername,
    adminPassword,
    adminFirstName,
    adminLastName,
    planCode,
  } = req.body;

  if (!schoolCode || !schoolName || !contactEmail || !adminUsername || !adminPassword) {
    return apiError(res, 'Required fields missing for school registration', 400);
  }

  const existingTenant = tenants.find(t => t.code.toLowerCase() === schoolCode.toLowerCase());
  if (existingTenant) {
    return apiError(res, `School code '${schoolCode}' is already registered`, 409);
  }

  const newTenantId = crypto.randomUUID();
  const newTenant: TenantData = {
    id: newTenantId,
    code: schoolCode.toUpperCase(),
    name: schoolName,
    subdomain: schoolCode.toLowerCase(),
    contactEmail,
    contactPhone: contactPhone || '',
    address: address || '',
    primaryColor: '#4F46E5',
    secondaryColor: '#06B6D4',
    planCode: planCode || 'BASIC',
    planName: planCode === 'PREMIUM' ? 'Enterprise Academy' : 'Standard Campus',
    maxStudents: planCode === 'PREMIUM' ? 2500 : 500,
    maxTeachers: planCode === 'PREMIUM' ? 150 : 35,
    status: 'ACTIVE',
  };
  tenants.push(newTenant);

  const newUserId = crypto.randomUUID();
  const newUser: UserData = {
    id: newUserId,
    tenantId: newTenantId,
    username: adminUsername,
    email: contactEmail,
    password: adminPassword,
    role: 'SCHOOL_ADMIN',
    firstName: adminFirstName,
    lastName: adminLastName,
    phone: contactPhone,
  };
  users.push(newUser);

  const token = signToken({
    sub: newUser.username,
    userId: newUser.id,
    email: newUser.email,
    role: newUser.role,
    tenantId: newUser.tenantId,
  });

  return apiOk(
    res,
    {
      token,
      tokenType: 'Bearer',
      userId: newUser.id,
      tenantId: newTenant.id,
      tenantCode: newTenant.code,
      schoolName: newTenant.name,
      username: newUser.username,
      email: newUser.email,
      fullName: `${newUser.firstName} ${newUser.lastName}`,
      role: newUser.role,
    },
    'School tenant registered successfully',
    201
  );
});

// -------------------------------------------------------------
// 2. STUDENTS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/students', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || (req.query.tenantId as string) || tenants[0].id;
  let list = students.filter(s => !tenantId || s.tenantId === tenantId);

  const classId = req.query.classId as string;
  const sectionId = req.query.sectionId as string;
  if (classId) list = list.filter(s => s.classId === classId);
  if (sectionId) list = list.filter(s => s.sectionId === sectionId);

  const page = parseInt(req.query.page as string || '0', 10);
  const size = parseInt(req.query.size as string || '20', 10);

  return apiOk(res, pageResponse(list, page, size));
});

app.get('/api/v1/students/:id', optionalAuthMiddleware, (req, res) => {
  const student = students.find(s => s.id === req.params.id);
  if (!student) return apiError(res, 'Student not found', 404);
  return apiOk(res, student);
});

app.post('/api/v1/students', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const {
    firstName,
    lastName,
    email,
    admissionNumber,
    rollNumber,
    classId,
    sectionId,
    gender,
    dateOfBirth,
    bloodGroup,
    phone,
    parentId,
  } = req.body;

  if (!firstName || !lastName || !email || !admissionNumber || !classId || !sectionId) {
    return apiError(res, 'Required student admission fields are missing', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const targetClass = classes.find(c => c.id === classId);
  const targetSection = sections.find(s => s.id === sectionId);

  const newStudent = {
    id: crypto.randomUUID(),
    tenantId,
    userId: crypto.randomUUID(),
    parentId: parentId || null,
    admissionNumber,
    rollNumber: rollNumber || '101',
    fullName: `${firstName} ${lastName}`,
    email,
    phone: phone || '',
    classId,
    sectionId,
    className: targetClass ? targetClass.name : 'Grade 10',
    sectionName: targetSection ? targetSection.name : 'Section A',
    gender: gender || 'Male',
    dateOfBirth: dateOfBirth || '2010-01-01',
    bloodGroup: bloodGroup || 'O+',
    status: 'ACTIVE',
  };

  students.push(newStudent);
  return apiOk(res, newStudent, 'Student enrolled successfully', 201);
});

// -------------------------------------------------------------
// 3. TEACHERS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/teachers', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = teachers.filter(t => !tenantId || t.tenantId === tenantId);
  const page = parseInt(req.query.page as string || '0', 10);
  const size = parseInt(req.query.size as string || '20', 10);
  return apiOk(res, pageResponse(list, page, size));
});

app.get('/api/v1/teachers/:id', (req, res) => {
  const teacher = teachers.find(t => t.id === req.params.id);
  if (!teacher) return apiError(res, 'Teacher not found', 404);
  return apiOk(res, teacher);
});

app.post('/api/v1/teachers', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const {
    firstName,
    lastName,
    email,
    employeeId,
    designation,
    department,
    qualification,
    joiningDate,
    salary,
    phone,
  } = req.body;

  if (!firstName || !lastName || !email || !employeeId || !designation) {
    return apiError(res, 'Required teacher details are missing', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newTeacher = {
    id: crypto.randomUUID(),
    tenantId,
    userId: crypto.randomUUID(),
    employeeId,
    fullName: `${firstName} ${lastName}`,
    email,
    phone: phone || '',
    designation,
    department: department || 'General Faculty',
    qualification: qualification || 'B.Ed',
    joiningDate: joiningDate || new Date().toISOString().split('T')[0],
    salary: salary ? Number(salary) : 5000,
    status: 'ACTIVE',
  };

  teachers.push(newTeacher);
  return apiOk(res, newTeacher, 'Teacher added successfully', 201);
});

// -------------------------------------------------------------
// 4. PARENTS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/parents', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = parents.filter(p => !tenantId || p.tenantId === tenantId);
  const page = parseInt(req.query.page as string || '0', 10);
  const size = parseInt(req.query.size as string || '20', 10);
  return apiOk(res, pageResponse(list, page, size));
});

app.get('/api/v1/parents/:id', (req, res) => {
  const parent = parents.find(p => p.id === req.params.id);
  if (!parent) return apiError(res, 'Parent not found', 404);
  return apiOk(res, parent);
});

app.get('/api/v1/parents/:id/wards', (req, res) => {
  const wards = students.filter(s => s.parentId === req.params.id);
  return apiOk(res, wards);
});

app.post('/api/v1/parents', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { firstName, lastName, email, phone, occupation, relationship, studentId } = req.body;
  if (!firstName || !lastName || !email) {
    return apiError(res, 'Parent name and email are required', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newParent = {
    id: crypto.randomUUID(),
    tenantId,
    userId: crypto.randomUUID(),
    fullName: `${firstName} ${lastName}`,
    email,
    phone: phone || '',
    occupation: occupation || 'Professional',
    relationship: relationship || 'Guardian',
    wardCount: studentId ? 1 : 0,
  };

  parents.push(newParent);
  if (studentId) {
    const student = students.find(s => s.id === studentId);
    if (student) student.parentId = newParent.id;
  }

  return apiOk(res, newParent, 'Guardian registered successfully', 201);
});

// -------------------------------------------------------------
// 5. ACADEMIC ROUTES (Classes, Sections, Subjects)
// -------------------------------------------------------------
app.get('/api/v1/academics/classes', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = classes.filter(c => !tenantId || c.tenantId === tenantId);
  return apiOk(res, list);
});

app.post('/api/v1/academics/classes', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const name = (req.query.name as string) || req.body.name;
  const numericGrade = parseInt((req.query.numericGrade as string) || req.body.numericGrade || '10', 10);
  if (!name) return apiError(res, 'Class name is required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newClass = {
    id: crypto.randomUUID(),
    tenantId,
    name,
    numericGrade,
  };
  classes.push(newClass);
  return apiOk(res, newClass, 'Class created successfully', 201);
});

app.get('/api/v1/academics/sections', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  let list = sections.filter(s => !tenantId || s.tenantId === tenantId);
  const classId = req.query.classId as string;
  if (classId) list = list.filter(s => s.classId === classId);
  return apiOk(res, list);
});

app.post('/api/v1/academics/sections', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const classId = (req.query.classId as string) || req.body.classId;
  const name = (req.query.name as string) || req.body.name;
  const capacity = parseInt((req.query.capacity as string) || req.body.capacity || '35', 10);

  if (!classId || !name) return apiError(res, 'classId and section name are required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newSection = {
    id: crypto.randomUUID(),
    tenantId,
    classId,
    name,
    capacity,
  };
  sections.push(newSection);
  return apiOk(res, newSection, 'Section created successfully', 201);
});

app.get('/api/v1/academics/subjects', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = subjects.filter(s => !tenantId || s.tenantId === tenantId);
  return apiOk(res, list);
});

app.post('/api/v1/academics/subjects', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const name = (req.query.name as string) || req.body.name;
  const code = (req.query.code as string) || req.body.code;
  const type = (req.query.type as string) || req.body.type || 'THEORY';
  const fullMarks = parseInt((req.query.fullMarks as string) || req.body.fullMarks || '100', 10);
  const passMarks = parseInt((req.query.passMarks as string) || req.body.passMarks || '40', 10);

  if (!name || !code) return apiError(res, 'Subject name and code are required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newSub = {
    id: crypto.randomUUID(),
    tenantId,
    name,
    code,
    type,
    fullMarks,
    passMarks,
  };
  subjects.push(newSub);
  return apiOk(res, newSub, 'Subject created successfully', 201);
});

// -------------------------------------------------------------
// 6. ATTENDANCE ROUTES
// -------------------------------------------------------------
app.post('/api/v1/attendance/bulk', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { date, records } = req.body;
  if (!date || !records || !Array.isArray(records)) {
    return apiError(res, 'Invalid bulk attendance submission format', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  records.forEach((rec: any) => {
    const existingIndex = attendanceRecords.findIndex(
      a => a.studentId === rec.studentId && a.attendanceDate === date && a.tenantId === tenantId
    );
    if (existingIndex >= 0) {
      attendanceRecords[existingIndex].status = rec.status;
      attendanceRecords[existingIndex].remarks = rec.remarks || '';
    } else {
      attendanceRecords.push({
        id: crypto.randomUUID(),
        tenantId,
        studentId: rec.studentId,
        attendanceDate: date,
        status: rec.status,
        remarks: rec.remarks || '',
      });
    }
  });

  return apiOk(res, null, 'Attendance recorded successfully');
});

app.get('/api/v1/attendance/summary', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const targetDate = (req.query.date as string) || new Date().toISOString().split('T')[0];
  const tenantId = req.user?.tenantId || tenants[0].id;

  const tenantStudents = students.filter(s => s.tenantId === tenantId);
  const dateRecords = attendanceRecords.filter(a => a.tenantId === tenantId && a.attendanceDate === targetDate);

  const present = dateRecords.filter(a => a.status === 'PRESENT').length;
  const absent = dateRecords.filter(a => a.status === 'ABSENT').length;
  const late = dateRecords.filter(a => a.status === 'LATE').length;
  const total = tenantStudents.length || 1;
  const pct = Math.round(((present + late * 0.5) / total) * 100 * 10) / 10;

  return apiOk(res, {
    date: targetDate,
    totalStudents: total,
    presentCount: present,
    absentCount: absent,
    lateCount: late,
    attendancePercentage: pct,
  });
});

app.get('/api/v1/attendance/student/:studentId', (req, res) => {
  const list = attendanceRecords.filter(a => a.studentId === req.params.studentId);
  return apiOk(res, list);
});

// -------------------------------------------------------------
// 7. EXAM & TRANSCRIPTS ROUTES
// -------------------------------------------------------------
app.post('/api/v1/exams/marks', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { examId, subjectId, entries } = req.body;
  if (!examId || !subjectId || !entries || !Array.isArray(entries)) {
    return apiError(res, 'Exam ID, Subject ID and mark entries are required', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  entries.forEach((entry: any) => {
    const numericMark = Number(entry.obtainedMarks);
    let grade = 'F';
    if (numericMark >= 90) grade = 'A+';
    else if (numericMark >= 80) grade = 'A';
    else if (numericMark >= 70) grade = 'B';
    else if (numericMark >= 60) grade = 'C';
    else if (numericMark >= 50) grade = 'D';

    const existingIdx = marks.findIndex(
      m => m.examId === examId && m.subjectId === subjectId && m.studentId === entry.studentId
    );

    if (existingIdx >= 0) {
      marks[existingIdx].obtainedMarks = numericMark;
      marks[existingIdx].grade = grade;
      marks[existingIdx].remarks = entry.remarks || '';
    } else {
      marks.push({
        id: crypto.randomUUID(),
        tenantId,
        examId,
        subjectId,
        studentId: entry.studentId,
        obtainedMarks: numericMark,
        totalMarks: entry.totalMarks ? Number(entry.totalMarks) : 100,
        grade,
        remarks: entry.remarks || '',
      });
    }
  });

  return apiOk(res, null, 'Marks saved successfully');
});

app.get('/api/v1/results/transcript', (req, res) => {
  const examId = req.query.examId as string;
  const studentId = req.query.studentId as string;
  if (!examId || !studentId) return apiError(res, 'examId and studentId query parameters are required', 400);

  const student = students.find(s => s.id === studentId);
  const exam = exams.find(e => e.id === examId);
  if (!student || !exam) return apiError(res, 'Student or Exam not found', 404);

  const studentMarks = marks.filter(m => m.examId === examId && m.studentId === studentId);
  const details = studentMarks.map(m => {
    const sub = subjects.find(s => s.id === m.subjectId);
    return {
      subjectName: sub ? sub.name : 'Subject',
      subjectCode: sub ? sub.code : 'CODE',
      obtainedMarks: m.obtainedMarks,
      totalMarks: m.totalMarks,
      grade: m.grade,
      remarks: m.remarks || '',
    };
  });

  const totalObtained = details.reduce((sum, d) => sum + d.obtainedMarks, 0);
  const totalPossible = details.reduce((sum, d) => sum + d.totalMarks, 0) || 100;
  const percentage = Math.round((totalObtained / totalPossible) * 10000) / 100;
  const gpa = percentage >= 80 ? 4.0 : percentage >= 70 ? 3.5 : percentage >= 60 ? 3.0 : 2.0;

  return apiOk(res, {
    studentId: student.id,
    studentName: student.fullName,
    admissionNumber: student.admissionNumber,
    className: student.className,
    sectionName: student.sectionName,
    examName: exam.name,
    subjectMarks: details,
    totalObtained,
    totalPossible,
    percentage,
    overallGrade: percentage >= 80 ? 'A' : percentage >= 60 ? 'B' : 'C',
    gpa,
    passFailStatus: percentage >= 40 ? 'PASSED' : 'FAILED',
  });
});

// -------------------------------------------------------------
// 8. FEES & PAYMENTS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/fees/invoices', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = invoices.filter(i => !tenantId || i.tenantId === tenantId);
  const page = parseInt(req.query.page as string || '0', 10);
  const size = parseInt(req.query.size as string || '20', 10);
  return apiOk(res, pageResponse(list, page, size));
});

app.post('/api/v1/fees/invoices', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { studentId, title, totalAmount, dueDate } = req.body;
  if (!studentId || !title || !totalAmount || !dueDate) {
    return apiError(res, 'studentId, title, totalAmount and dueDate are required', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const student = students.find(s => s.id === studentId);
  const newInvoice = {
    id: crypto.randomUUID(),
    tenantId,
    studentId,
    studentName: student ? student.fullName : 'Student',
    invoiceNumber: `INV-GW-${Date.now().toString().slice(-6)}`,
    title,
    totalAmount: Number(totalAmount),
    paidAmount: 0.0,
    dueAmount: Number(totalAmount),
    dueDate,
    status: 'UNPAID',
  };

  invoices.unshift(newInvoice);
  return apiOk(res, newInvoice, 'Invoice generated', 201);
});

app.post('/api/v1/fees/payments', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { invoiceId, amount, paymentMethod, transactionId } = req.body;
  if (!invoiceId || !amount || !paymentMethod) {
    return apiError(res, 'invoiceId, amount, and paymentMethod are required', 400);
  }

  const inv = invoices.find(i => i.id === invoiceId);
  if (!inv) return apiError(res, 'Invoice not found', 404);

  const tenantId = req.user?.tenantId || inv.tenantId;
  const numAmount = Number(amount);
  inv.paidAmount += numAmount;
  inv.dueAmount = Math.max(0, inv.totalAmount - inv.paidAmount);
  inv.status = inv.dueAmount === 0 ? 'PAID' : 'PARTIAL';

  const receiptNumber = `REC-${Date.now().toString().slice(-6)}`;
  const newPayment = {
    id: crypto.randomUUID(),
    tenantId,
    invoiceId,
    receiptNumber,
    amount: numAmount,
    paymentMethod,
    transactionId: transactionId || `TXN_${Date.now()}`,
    paidAt: new Date().toISOString(),
  };
  payments.unshift(newPayment);

  return apiOk(res, {
    paymentId: newPayment.id,
    receiptNumber,
    invoiceNumber: inv.invoiceNumber,
    studentName: inv.studentName || 'Student',
    amountPaid: numAmount,
    paymentMethod,
    transactionId: newPayment.transactionId,
    paidAt: newPayment.paidAt,
  }, 'Payment recorded successfully');
});

// -------------------------------------------------------------
// 9. ROUTINES ROUTES
// -------------------------------------------------------------
app.get('/api/v1/routines', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  let list = routines.filter(r => !tenantId || r.tenantId === tenantId);
  const classId = req.query.classId as string;
  const sectionId = req.query.sectionId as string;
  if (classId) list = list.filter(r => r.classId === classId);
  if (sectionId) list = list.filter(r => r.sectionId === sectionId);
  return apiOk(res, list);
});

app.post('/api/v1/routines', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { classId, sectionId, subjectId, teacherId, dayOfWeek, startTime, endTime, roomNumber } = req.body;
  if (!classId || !sectionId || !subjectId || !teacherId || !dayOfWeek) {
    return apiError(res, 'Missing routine slot attributes', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newSlot = {
    id: crypto.randomUUID(),
    tenantId,
    classId,
    sectionId,
    subjectId,
    teacherId,
    dayOfWeek,
    startTime: startTime || '08:30:00',
    endTime: endTime || '09:20:00',
    roomNumber: roomNumber || 'Room 101',
  };

  routines.push(newSlot);
  return apiOk(res, newSlot, 'Routine timetable slot created successfully', 201);
});

// -------------------------------------------------------------
// 10. ASSIGNMENTS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/assignments', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  let list = assignments.filter(a => !tenantId || a.tenantId === tenantId);
  const classId = req.query.classId as string;
  if (classId) list = list.filter(a => a.classId === classId);
  return apiOk(res, list);
});

app.post('/api/v1/assignments', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { classId, sectionId, subjectId, teacherId, title, description, dueDate, totalPoints } = req.body;
  if (!title || !classId || !subjectId) {
    return apiError(res, 'Title, classId and subjectId are required', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const sub = subjects.find(s => s.id === subjectId);
  const cls = classes.find(c => c.id === classId);
  const sec = sections.find(s => s.id === sectionId);

  const newAssignment = {
    id: crypto.randomUUID(),
    tenantId,
    classId,
    sectionId: sectionId || '',
    subjectId,
    teacherId: teacherId || '',
    title,
    description: description || '',
    dueDate: dueDate || new Date().toISOString().split('T')[0],
    totalPoints: Number(totalPoints) || 20,
    className: cls ? cls.name : 'Grade 10',
    sectionName: sec ? sec.name : 'Section A',
    subjectName: sub ? sub.name : 'Subject',
  };

  assignments.unshift(newAssignment);
  return apiOk(res, newAssignment, 'Assignment published successfully', 201);
});

// -------------------------------------------------------------
// 11. NOTICES ROUTES
// -------------------------------------------------------------
app.get('/api/v1/notices', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  let list = notices.filter(n => !tenantId || n.tenantId === tenantId);
  const audience = req.query.audience as string;
  if (audience && audience !== 'ALL') {
    list = list.filter(n => n.targetAudience === 'ALL' || n.targetAudience === audience);
  }
  return apiOk(res, list);
});

app.post('/api/v1/notices', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const title = (req.query.title as string) || req.body.title;
  const content = (req.query.content as string) || req.body.content;
  const audience = (req.query.audience as string) || req.body.audience || 'ALL';

  if (!title || !content) return apiError(res, 'Title and content are required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newNotice = {
    id: crypto.randomUUID(),
    tenantId,
    title,
    content,
    targetAudience: audience,
    publishedDate: new Date().toISOString().split('T')[0],
  };

  notices.unshift(newNotice);
  return apiOk(res, newNotice, 'Notice published successfully', 201);
});

// -------------------------------------------------------------
// 12. EVENTS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/events', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  let list = events.filter(e => !tenantId || e.tenantId === tenantId);
  const type = req.query.type as string;
  if (type) list = list.filter(e => e.eventType === type);
  return apiOk(res, list);
});

app.post('/api/v1/events', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { title, description, eventDate, eventType } = req.body;
  if (!title || !eventDate) return apiError(res, 'Title and eventDate are required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newEvent = {
    id: crypto.randomUUID(),
    tenantId,
    title,
    description: description || '',
    eventDate,
    eventType: eventType || 'GENERAL',
  };

  events.unshift(newEvent);
  return apiOk(res, newEvent, 'Event scheduled successfully', 201);
});

// -------------------------------------------------------------
// 13. BOOKS ROUTES (Library)
// -------------------------------------------------------------
app.get('/api/v1/books', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  let list = books.filter(b => !tenantId || b.tenantId === tenantId);
  const query = (req.query.query as string)?.toLowerCase();
  if (query) {
    list = list.filter(b => b.title.toLowerCase().includes(query) || b.author.toLowerCase().includes(query) || b.isbn.includes(query));
  }
  return apiOk(res, list);
});

app.post('/api/v1/books', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { title, author, isbn, totalCopies, rackNumber } = req.body;
  if (!title || !author || !isbn) return apiError(res, 'Title, author, and ISBN are required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const numCopies = Number(totalCopies) || 5;
  const newBook = {
    id: crypto.randomUUID(),
    tenantId,
    title,
    author,
    isbn,
    totalCopies: numCopies,
    availableCopies: numCopies,
    rackNumber: rackNumber || 'Main Library',
  };

  books.unshift(newBook);
  return apiOk(res, newBook, 'Book cataloged successfully', 201);
});

app.post('/api/v1/books/:id/issue', (req, res) => {
  const book = books.find(b => b.id === req.params.id);
  if (!book) return apiError(res, 'Book not found', 404);
  if (book.availableCopies <= 0) return apiError(res, 'No copies currently available for issue', 400);
  book.availableCopies -= 1;
  return apiOk(res, book, 'Book issued successfully');
});

app.post('/api/v1/books/:id/return', (req, res) => {
  const book = books.find(b => b.id === req.params.id);
  if (!book) return apiError(res, 'Book not found', 404);
  if (book.availableCopies < book.totalCopies) {
    book.availableCopies += 1;
  }
  return apiOk(res, book, 'Book returned successfully');
});

// -------------------------------------------------------------
// 14. TRANSPORT ROUTES
// -------------------------------------------------------------
app.get('/api/v1/transport', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = transportRoutes.filter(t => !tenantId || t.tenantId === tenantId);
  return apiOk(res, list);
});

app.post('/api/v1/transport', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { routeName, vehicleNumber, driverName, driverPhone, fareMonthly } = req.body;
  if (!routeName || !vehicleNumber || !driverName) {
    return apiError(res, 'routeName, vehicleNumber, and driverName are required', 400);
  }

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newRoute = {
    id: crypto.randomUUID(),
    tenantId,
    routeName,
    vehicleNumber,
    driverName,
    driverPhone: driverPhone || '',
    fareMonthly: Number(fareMonthly) || 50,
  };

  transportRoutes.unshift(newRoute);
  return apiOk(res, newRoute, 'Transport route registered successfully', 201);
});

// -------------------------------------------------------------
// 15. HOSTELS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/hostels', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const list = hostels.filter(h => !tenantId || h.tenantId === tenantId);
  return apiOk(res, list);
});

app.post('/api/v1/hostels', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const { buildingName, roomNumber, bedCount, monthlyFee } = req.body;
  if (!buildingName || !roomNumber) return apiError(res, 'buildingName and roomNumber are required', 400);

  const tenantId = req.user?.tenantId || tenants[0].id;
  const newRoom = {
    id: crypto.randomUUID(),
    tenantId,
    buildingName,
    roomNumber,
    bedCount: Number(bedCount) || 4,
    monthlyFee: Number(monthlyFee) || 200,
  };

  hostels.unshift(newRoom);
  return apiOk(res, newRoom, 'Hostel room allocated successfully', 201);
});

// -------------------------------------------------------------
// 16. REPORTS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/reports/attendance', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const date = (req.query.date as string) || new Date().toISOString().split('T')[0];
  const tenantId = req.user?.tenantId || tenants[0].id;
  const tenantStudents = students.filter(s => s.tenantId === tenantId);
  const dateRecords = attendanceRecords.filter(a => a.tenantId === tenantId && a.attendanceDate === date);

  const present = dateRecords.filter(a => a.status === 'PRESENT').length;
  const absent = dateRecords.filter(a => a.status === 'ABSENT').length;
  const late = dateRecords.filter(a => a.status === 'LATE').length;
  const total = tenantStudents.length || 1;
  const pct = Math.round(((present + late * 0.5) / total) * 100 * 10) / 10;

  return apiOk(res, {
    date,
    totalEnrollment: total,
    presentCount: present,
    absentCount: absent,
    lateCount: late,
    attendancePercentage: pct,
  });
});

app.get('/api/v1/reports/finance', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const tenantInvoices = invoices.filter(i => i.tenantId === tenantId);

  const totalInvoiced = tenantInvoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const totalCollected = tenantInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalOutstanding = tenantInvoices.reduce((sum, i) => sum + i.dueAmount, 0);
  const collectionRate = totalInvoiced > 0 ? Math.round((totalCollected / totalInvoiced) * 1000) / 10 : 100;

  return apiOk(res, {
    totalInvoiced,
    totalCollected,
    totalOutstanding,
    collectionRatePercentage: collectionRate,
  });
});

// -------------------------------------------------------------
// 17. TENANT & DASHBOARDS ROUTES
// -------------------------------------------------------------
app.get('/api/v1/super-admin/dashboard', (req, res) => {
  return apiOk(res, {
    totalSchools: tenants.length,
    activeSchools: tenants.filter(t => t.status === 'ACTIVE').length,
    suspendedSchools: tenants.filter(t => t.status === 'SUSPENDED').length,
    totalUsers: users.length,
    totalStudents: students.length,
    totalTeachers: teachers.length,
    monthlyRevenueEstimate: 12480.0,
  });
});

app.get('/api/v1/super-admin/tenants', (req, res) => {
  const list = tenants.map(t => ({
    id: t.id,
    code: t.code,
    name: t.name,
    subdomain: t.subdomain,
    contactEmail: t.contactEmail,
    contactPhone: t.contactPhone,
    address: t.address,
    status: t.status,
    planCode: t.planCode,
    planName: t.planName,
    maxStudents: t.maxStudents,
    maxTeachers: t.maxTeachers,
    currentStudents: students.filter(s => s.tenantId === t.id).length,
    currentTeachers: teachers.filter(tc => tc.tenantId === t.id).length,
    primaryColor: t.primaryColor,
  }));

  const page = parseInt(req.query.page as string || '0', 10);
  const size = parseInt(req.query.size as string || '20', 10);
  return apiOk(res, pageResponse(list, page, size));
});

app.patch('/api/v1/super-admin/tenants/:id/status', (req, res) => {
  const tenant = tenants.find(t => t.id === req.params.id);
  if (!tenant) return apiError(res, 'Tenant not found', 404);
  const status = (req.query.status as string) || req.body.status;
  if (status) tenant.status = status;
  return apiOk(res, null, 'Tenant status updated successfully');
});

app.get('/api/v1/school-admin/dashboard', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const tenant = tenants.find(t => t.id === tenantId) || tenants[0];

  const tenantStudents = students.filter(s => s.tenantId === tenantId);
  const tenantTeachers = teachers.filter(t => t.tenantId === tenantId);
  const tenantClasses = classes.filter(c => c.tenantId === tenantId);
  const tenantParents = parents.filter(p => p.tenantId === tenantId);
  const tenantInvoices = invoices.filter(i => i.tenantId === tenantId);

  const collected = tenantInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const due = tenantInvoices.reduce((sum, i) => sum + i.dueAmount, 0);

  return apiOk(res, {
    schoolName: tenant.name,
    schoolCode: tenant.code,
    totalStudents: tenantStudents.length,
    totalTeachers: tenantTeachers.length,
    totalClasses: tenantClasses.length,
    totalParents: tenantParents.length,
    todayAttendanceRate: 94.8,
    totalFeesCollected: collected,
    totalFeesDue: due,
    upcomingExamsCount: 2,
    pendingInvoicesCount: tenantInvoices.filter(i => i.status !== 'PAID').length,
  });
});

app.get('/api/v1/tenant/settings', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const tenant = tenants.find(t => t.id === tenantId) || tenants[0];
  return apiOk(res, {
    id: tenant.id,
    code: tenant.code,
    name: tenant.name,
    subdomain: tenant.subdomain,
    contactEmail: tenant.contactEmail,
    contactPhone: tenant.contactPhone,
    address: tenant.address,
    status: tenant.status,
    planCode: tenant.planCode,
    planName: tenant.planName,
    maxStudents: tenant.maxStudents,
    maxTeachers: tenant.maxTeachers,
    currentStudents: students.filter(s => s.tenantId === tenant.id).length,
    currentTeachers: teachers.filter(tc => tc.tenantId === tenant.id).length,
    primaryColor: tenant.primaryColor,
  });
});

app.put('/api/v1/tenant/settings', optionalAuthMiddleware, (req: AuthenticatedRequest, res) => {
  const tenantId = req.user?.tenantId || tenants[0].id;
  const tenant = tenants.find(t => t.id === tenantId) || tenants[0];
  const { name, contactEmail, contactPhone, address, primaryColor } = req.body;

  if (name) tenant.name = name;
  if (contactEmail) tenant.contactEmail = contactEmail;
  if (contactPhone) tenant.contactPhone = contactPhone;
  if (address) tenant.address = address;
  if (primaryColor) tenant.primaryColor = primaryColor;

  return apiOk(res, tenant, 'School settings updated successfully');
});

// -------------------------------------------------------------
// VITE DEV SERVER INTEGRATION & STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EduPulse SaaS server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
