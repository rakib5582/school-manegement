package com.example.school.service;

import com.example.school.dto.AttendanceDTOs.*;
import com.example.school.entity.Attendance;
import com.example.school.entity.Student;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.AttendanceRepository;
import com.example.school.repository.StudentRepository;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;

    @Transactional
    public void recordBulkAttendance(BulkAttendanceRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        for (MarkStudentAttendanceRequest item : request.getRecords()) {
            Student student = studentRepository.findByIdAndTenantId(item.getStudentId(), tenantId)
                    .orElseThrow(() -> new ResourceNotFoundException("Student not found in this school: " + item.getStudentId()));

            // Prevent duplicate records for student + date
            Attendance attendance = attendanceRepository
                    .findByTenantIdAndStudentIdAndAttendanceDate(tenantId, student.getId(), request.getDate())
                    .orElseGet(() -> {
                        Attendance newAtt = Attendance.builder()
                                .student(student)
                                .attendanceDate(request.getDate())
                                .build();
                        newAtt.setTenantId(tenantId);
                        return newAtt;
                    });

            attendance.setStatus(item.getStatus().toUpperCase());
            attendance.setRemarks(item.getRemarks());

            attendanceRepository.save(attendance);
        }
    }

    @Transactional(readOnly = true)
    public AttendanceSummaryResponse getDailySummary(LocalDate date) {
        UUID tenantId = TenantContext.getTenantId();
        LocalDate targetDate = date != null ? date : LocalDate.now();

        long total = attendanceRepository.countByTenantIdAndAttendanceDate(tenantId, targetDate);
        long present = attendanceRepository.countByTenantIdAndAttendanceDateAndStatus(tenantId, targetDate, "PRESENT");
        long absent = attendanceRepository.countByTenantIdAndAttendanceDateAndStatus(tenantId, targetDate, "ABSENT");
        long late = attendanceRepository.countByTenantIdAndAttendanceDateAndStatus(tenantId, targetDate, "LATE");

        double percentage = total > 0 ? ((double) present / total) * 100.0 : 0.0;

        return AttendanceSummaryResponse.builder()
                .date(targetDate)
                .totalStudents(total)
                .presentCount(present)
                .absentCount(absent)
                .lateCount(late)
                .attendancePercentage(Math.round(percentage * 10.0) / 10.0)
                .build();
    }

    @Transactional(readOnly = true)
    public List<Attendance> getStudentAttendanceHistory(UUID studentId) {
        UUID tenantId = TenantContext.getTenantId();
        return attendanceRepository.findByTenantIdAndStudentId(tenantId, studentId);
    }
}
