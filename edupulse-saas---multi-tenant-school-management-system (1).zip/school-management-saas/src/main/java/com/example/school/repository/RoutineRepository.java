package com.example.school.repository;

import com.example.school.entity.Routine;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RoutineRepository extends JpaRepository<Routine, UUID> {

    @Query("SELECT r FROM Routine r WHERE r.id = :id AND r.tenantId = :tenantId")
    Optional<Routine> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Routine> findByTenantIdAndSchoolClassIdAndSectionId(UUID tenantId, UUID classId, UUID sectionId);

    List<Routine> findByTenantIdAndTeacherId(UUID tenantId, UUID teacherId);

    // Timetable Conflict Checks:
    // 1. Teacher cannot teach two classes at the same day & time
    @Query("SELECT r FROM Routine r WHERE r.tenantId = :tenantId AND r.teacher.id = :teacherId " +
           "AND r.dayOfWeek = :dayOfWeek AND ((r.startTime < :endTime AND r.endTime > :startTime))")
    List<Routine> findTeacherConflicts(@Param("tenantId") UUID tenantId,
                                       @Param("teacherId") UUID teacherId,
                                       @Param("dayOfWeek") String dayOfWeek,
                                       @Param("startTime") LocalTime startTime,
                                       @Param("endTime") LocalTime endTime);

    // 2. Room cannot host two classes at the same day & time
    @Query("SELECT r FROM Routine r WHERE r.tenantId = :tenantId AND r.roomNumber = :roomNumber " +
           "AND r.dayOfWeek = :dayOfWeek AND ((r.startTime < :endTime AND r.endTime > :startTime))")
    List<Routine> findRoomConflicts(@Param("tenantId") UUID tenantId,
                                    @Param("roomNumber") String roomNumber,
                                    @Param("dayOfWeek") String dayOfWeek,
                                    @Param("startTime") LocalTime startTime,
                                    @Param("endTime") LocalTime endTime);
}
