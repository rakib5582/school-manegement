package com.example.school.repository;

import com.example.school.entity.Teacher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface TeacherRepository extends JpaRepository<Teacher, UUID> {

    @Query("SELECT t FROM Teacher t WHERE t.id = :id AND t.tenantId = :tenantId")
    Optional<Teacher> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    Page<Teacher> findByTenantId(UUID tenantId, Pageable pageable);

    Optional<Teacher> findByTenantIdAndUserId(UUID tenantId, UUID userId);

    Optional<Teacher> findByTenantIdAndEmployeeId(UUID tenantId, String employeeId);

    long countByTenantId(UUID tenantId);

    boolean existsByTenantIdAndEmployeeId(UUID tenantId, String employeeId);
}
