package com.example.school.repository;

import com.example.school.entity.SchoolClass;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SchoolClassRepository extends JpaRepository<SchoolClass, UUID> {

    @Query("SELECT c FROM SchoolClass c WHERE c.id = :id AND c.tenantId = :tenantId")
    Optional<SchoolClass> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<SchoolClass> findByTenantIdOrderByNumericGradeAsc(UUID tenantId);

    long countByTenantId(UUID tenantId);
}
