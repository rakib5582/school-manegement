package com.example.school.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public class TeacherDTOs {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateTeacherRequest {
        @NotBlank(message = "First name is required")
        private String firstName;

        @NotBlank(message = "Last name is required")
        private String lastName;

        @NotBlank(message = "Email is required")
        @Email(message = "Valid email is required")
        private String email;

        @NotBlank(message = "Employee ID is required")
        private String employeeId;

        @NotBlank(message = "Designation is required")
        private String designation;

        private String department;
        private String qualification;
        private LocalDate joiningDate;
        private BigDecimal salary;
        private String phone;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TeacherResponse {
        private UUID id;
        private UUID tenantId;
        private UUID userId;
        private String employeeId;
        private String fullName;
        private String email;
        private String phone;
        private String designation;
        private String department;
        private String qualification;
        private LocalDate joiningDate;
        private BigDecimal salary;
        private String status;
    }
}
