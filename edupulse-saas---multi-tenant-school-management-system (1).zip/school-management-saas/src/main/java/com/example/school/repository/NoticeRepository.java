package com.example.school.repository;

import com.example.school.entity.Notice;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface NoticeRepository extends JpaRepository<Notice, UUID> {

    @Query("SELECT n FROM Notice n WHERE n.id = :id AND n.tenantId = :tenantId")
    Optional<Notice> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Notice> findByTenantIdOrderByPublishedDateDesc(UUID tenantId);

    Page<Notice> findByTenantId(UUID tenantId, Pageable pageable);

    @Query("SELECT n FROM Notice n WHERE n.tenantId = :tenantId AND (n.targetAudience = 'ALL' OR n.targetAudience = :audience) ORDER BY n.publishedDate DESC")
    List<Notice> findByTenantIdAndAudience(@Param("tenantId") UUID tenantId, @Param("audience") String audience);
}
