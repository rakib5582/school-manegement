package com.example.school.service;

import com.example.school.entity.*;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.*;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class RoutineService {

    private final RoutineRepository routineRepository;
    private final SchoolClassRepository classRepository;
    private final SectionRepository sectionRepository;
    private final SubjectRepository subjectRepository;
    private final TeacherRepository teacherRepository;

    @Transactional(readOnly = true)
    public List<Routine> getClassRoutine(UUID classId, UUID sectionId) {
        UUID tenantId = TenantContext.getTenantId();
        return routineRepository.findByTenantIdAndSchoolClassIdAndSectionId(tenantId, classId, sectionId);
    }

    @Transactional
    public Routine createRoutineSlot(UUID classId, UUID sectionId, UUID subjectId, UUID teacherId,
                                     String dayOfWeek, LocalTime startTime, LocalTime endTime, String roomNumber) {
        UUID tenantId = TenantContext.getTenantId();

        // 1. Conflict Check: Teacher overlap
        List<Routine> teacherConflicts = routineRepository.findTeacherConflicts(tenantId, teacherId, dayOfWeek, startTime, endTime);
        if (!teacherConflicts.isEmpty()) {
            throw new IllegalArgumentException("Teacher conflict: Assigned teacher is already scheduled in another class at this time.");
        }

        // 2. Conflict Check: Room overlap
        List<Routine> roomConflicts = routineRepository.findRoomConflicts(tenantId, roomNumber, dayOfWeek, startTime, endTime);
        if (!roomConflicts.isEmpty()) {
            throw new IllegalArgumentException("Room conflict: Room " + roomNumber + " is already occupied during this time.");
        }

        SchoolClass schoolClass = classRepository.findByIdAndTenantId(classId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + classId));
        Section section = sectionRepository.findByIdAndTenantId(sectionId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Section not found: " + sectionId));
        Subject subject = subjectRepository.findByIdAndTenantId(subjectId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found: " + subjectId));
        Teacher teacher = teacherRepository.findByIdAndTenantId(teacherId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Teacher not found: " + teacherId));

        Routine routine = Routine.builder()
                .schoolClass(schoolClass)
                .section(section)
                .subject(subject)
                .teacher(teacher)
                .dayOfWeek(dayOfWeek.toUpperCase())
                .startTime(startTime)
                .endTime(endTime)
                .roomNumber(roomNumber)
                .build();
        routine.setTenantId(tenantId);

        return routineRepository.save(routine);
    }
}
