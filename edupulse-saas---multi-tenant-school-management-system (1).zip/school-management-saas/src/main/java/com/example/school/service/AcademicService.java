package com.example.school.service;

import com.example.school.entity.SchoolClass;
import com.example.school.entity.Section;
import com.example.school.entity.Subject;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.SchoolClassRepository;
import com.example.school.repository.SectionRepository;
import com.example.school.repository.SubjectRepository;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AcademicService {

    private final SchoolClassRepository classRepository;
    private final SectionRepository sectionRepository;
    private final SubjectRepository subjectRepository;

    @Transactional(readOnly = true)
    public List<SchoolClass> getClasses() {
        UUID tenantId = TenantContext.getTenantId();
        return classRepository.findByTenantIdOrderByNumericGradeAsc(tenantId);
    }

    @Transactional(readOnly = true)
    public List<Section> getSections(UUID classId) {
        UUID tenantId = TenantContext.getTenantId();
        if (classId != null) {
            return sectionRepository.findByTenantIdAndSchoolClassId(tenantId, classId);
        }
        return sectionRepository.findAll().stream().filter(s -> tenantId.equals(s.getTenantId())).toList();
    }

    @Transactional(readOnly = true)
    public List<Subject> getSubjects() {
        UUID tenantId = TenantContext.getTenantId();
        return subjectRepository.findByTenantId(tenantId);
    }

    @Transactional
    public SchoolClass createClass(String name, Integer numericGrade) {
        UUID tenantId = TenantContext.getTenantId();
        SchoolClass schoolClass = SchoolClass.builder()
                .name(name)
                .numericGrade(numericGrade)
                .build();
        schoolClass.setTenantId(tenantId);
        return classRepository.save(schoolClass);
    }

    @Transactional
    public Section createSection(UUID classId, String name, Integer capacity) {
        UUID tenantId = TenantContext.getTenantId();
        SchoolClass schoolClass = classRepository.findByIdAndTenantId(classId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + classId));

        Section section = Section.builder()
                .schoolClass(schoolClass)
                .name(name)
                .capacity(capacity != null ? capacity : 40)
                .build();
        section.setTenantId(tenantId);
        return sectionRepository.save(section);
    }

    @Transactional
    public Subject createSubject(String name, String code, String type, Integer fullMarks, Integer passMarks) {
        UUID tenantId = TenantContext.getTenantId();
        Subject subject = Subject.builder()
                .name(name)
                .code(code)
                .type(type != null ? type : "THEORY")
                .fullMarks(fullMarks != null ? fullMarks : 100)
                .passMarks(passMarks != null ? passMarks : 40)
                .build();
        subject.setTenantId(tenantId);
        return subjectRepository.save(subject);
    }
}
