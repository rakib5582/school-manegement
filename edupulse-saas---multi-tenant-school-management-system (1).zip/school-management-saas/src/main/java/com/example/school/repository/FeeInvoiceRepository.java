package com.example.school.repository;

import com.example.school.entity.FeeInvoice;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FeeInvoiceRepository extends JpaRepository<FeeInvoice, UUID> {

    @Query("SELECT f FROM FeeInvoice f WHERE f.id = :id AND f.tenantId = :tenantId")
    Optional<FeeInvoice> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    Page<FeeInvoice> findByTenantId(UUID tenantId, Pageable pageable);

    List<FeeInvoice> findByTenantIdAndStudentId(UUID tenantId, UUID studentId);

    Optional<FeeInvoice> findByTenantIdAndInvoiceNumber(UUID tenantId, String invoiceNumber);

    @Query("SELECT COALESCE(SUM(f.totalAmount), 0) FROM FeeInvoice f WHERE f.tenantId = :tenantId")
    BigDecimal sumTotalAmountByTenantId(@Param("tenantId") UUID tenantId);

    @Query("SELECT COALESCE(SUM(f.paidAmount), 0) FROM FeeInvoice f WHERE f.tenantId = :tenantId")
    BigDecimal sumPaidAmountByTenantId(@Param("tenantId") UUID tenantId);

    long countByTenantIdAndStatus(UUID tenantId, String status);
}
