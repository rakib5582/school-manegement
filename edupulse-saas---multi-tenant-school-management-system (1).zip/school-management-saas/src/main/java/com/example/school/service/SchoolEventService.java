package com.example.school.service;

import com.example.school.entity.SchoolEvent;
import com.example.school.repository.SchoolEventRepository;
import com.example.school.tenant.TenantContext;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SchoolEventService {

    private final SchoolEventRepository eventRepository;

    @Transactional(readOnly = true)
    public List<SchoolEvent> getEvents(String type) {
        UUID tenantId = TenantContext.getTenantId();
        if (type != null && !type.equalsIgnoreCase("ALL") && !type.isBlank()) {
            return eventRepository.findByTenantIdAndEventType(tenantId, type.toUpperCase());
        }
        return eventRepository.findByTenantIdOrderByEventDateAsc(tenantId);
    }

    @Transactional
    public SchoolEvent addEvent(CreateEventRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        SchoolEvent event = SchoolEvent.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .eventDate(request.getEventDate())
                .eventType(request.getEventType() != null ? request.getEventType().toUpperCase() : "GENERAL")
                .build();
        event.setTenantId(tenantId);

        return eventRepository.save(event);
    }

    @Data
    public static class CreateEventRequest {
        private String title;
        private String description;
        private LocalDate eventDate;
        private String eventType;
    }
}
