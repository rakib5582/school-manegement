package com.example.school.entity;

import com.example.school.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "notices")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Notice extends TenantAwareEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, length = 255)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String content;

    @Column(name = "target_audience", length = 50)
    @Builder.Default
    private String targetAudience = "ALL"; // ALL, TEACHERS, STUDENTS, PARENTS

    @Column(name = "published_date", nullable = false)
    private LocalDate publishedDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;
}
