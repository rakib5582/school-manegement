package com.example.school.service;

import com.example.school.entity.Notice;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.NoticeRepository;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeRepository noticeRepository;

    @Transactional(readOnly = true)
    public List<Notice> getNotices(String audience) {
        UUID tenantId = TenantContext.getTenantId();
        if (audience != null && !audience.isBlank() && !"ALL".equalsIgnoreCase(audience)) {
            return noticeRepository.findByTenantIdAndAudience(tenantId, audience.toUpperCase());
        }
        return noticeRepository.findByTenantIdOrderByPublishedDateDesc(tenantId);
    }

    @Transactional
    public Notice createNotice(String title, String content, String audience) {
        UUID tenantId = TenantContext.getTenantId();
        Notice notice = Notice.builder()
                .title(title)
                .content(content)
                .targetAudience(audience != null ? audience.toUpperCase() : "ALL")
                .publishedDate(LocalDate.now())
                .build();
        notice.setTenantId(tenantId);
        return noticeRepository.save(notice);
    }
}
