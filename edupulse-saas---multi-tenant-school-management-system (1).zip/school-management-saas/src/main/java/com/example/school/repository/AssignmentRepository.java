package com.example.school.repository;

import com.example.school.entity.Assignment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AssignmentRepository extends JpaRepository<Assignment, UUID> {

    @Query("SELECT a FROM Assignment a WHERE a.id = :id AND a.tenantId = :tenantId")
    Optional<Assignment> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Assignment> findByTenantId(UUID tenantId);

    Page<Assignment> findByTenantId(UUID tenantId, Pageable pageable);

    @Query("SELECT a FROM Assignment a WHERE a.tenantId = :tenantId AND a.schoolClass.id = :classId")
    List<Assignment> findByTenantIdAndClassId(@Param("tenantId") UUID tenantId, @Param("classId") UUID classId);
}
