package com.example.school.service;

import com.example.school.dto.FeeDTOs.*;
import com.example.school.entity.FeeInvoice;
import com.example.school.entity.PaymentRecord;
import com.example.school.entity.Student;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.FeeInvoiceRepository;
import com.example.school.repository.PaymentRecordRepository;
import com.example.school.repository.StudentRepository;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class FeeService {

    private final FeeInvoiceRepository feeInvoiceRepository;
    private final PaymentRecordRepository paymentRecordRepository;
    private final StudentRepository studentRepository;

    @Transactional(readOnly = true)
    public Page<InvoiceResponse> getInvoices(Pageable pageable) {
        UUID tenantId = TenantContext.getTenantId();
        return feeInvoiceRepository.findByTenantId(tenantId, pageable).map(this::mapToResponse);
    }

    @Transactional
    public InvoiceResponse createInvoice(CreateInvoiceRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        Student student = studentRepository.findByIdAndTenantId(request.getStudentId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + request.getStudentId()));

        String invoiceNumber = "INV-" + System.currentTimeMillis();

        FeeInvoice invoice = FeeInvoice.builder()
                .student(student)
                .invoiceNumber(invoiceNumber)
                .title(request.getTitle())
                .totalAmount(request.getTotalAmount())
                .paidAmount(BigDecimal.ZERO)
                .dueDate(request.getDueDate())
                .status("UNPAID")
                .build();
        invoice.setTenantId(tenantId);

        invoice = feeInvoiceRepository.save(invoice);
        return mapToResponse(invoice);
    }

    @Transactional
    public ReceiptResponse recordPayment(RecordPaymentRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        FeeInvoice invoice = feeInvoiceRepository.findByIdAndTenantId(request.getInvoiceId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found: " + request.getInvoiceId()));

        BigDecimal newPaidAmount = invoice.getPaidAmount().add(request.getAmount());
        if (newPaidAmount.compareTo(invoice.getTotalAmount()) > 0) {
            throw new IllegalArgumentException("Payment amount exceeds remaining balance");
        }

        invoice.setPaidAmount(newPaidAmount);
        if (newPaidAmount.compareTo(invoice.getTotalAmount()) >= 0) {
            invoice.setStatus("PAID");
        } else {
            invoice.setStatus("PARTIAL");
        }
        feeInvoiceRepository.save(invoice);

        String receiptNumber = "REC-" + System.currentTimeMillis();
        PaymentRecord payment = PaymentRecord.builder()
                .invoice(invoice)
                .receiptNumber(receiptNumber)
                .amount(request.getAmount())
                .paymentMethod(request.getPaymentMethod())
                .transactionId(request.getTransactionId())
                .build();
        payment.setTenantId(tenantId);
        payment = paymentRecordRepository.save(payment);

        return ReceiptResponse.builder()
                .paymentId(payment.getId())
                .receiptNumber(payment.getReceiptNumber())
                .invoiceNumber(invoice.getInvoiceNumber())
                .studentName(invoice.getStudent().getUser().getFullName())
                .amountPaid(payment.getAmount())
                .paymentMethod(payment.getPaymentMethod())
                .transactionId(payment.getTransactionId())
                .paidAt(payment.getPaidAt())
                .build();
    }

    private InvoiceResponse mapToResponse(FeeInvoice invoice) {
        return InvoiceResponse.builder()
                .id(invoice.getId())
                .studentId(invoice.getStudent().getId())
                .studentName(invoice.getStudent().getUser().getFullName())
                .invoiceNumber(invoice.getInvoiceNumber())
                .title(invoice.getTitle())
                .totalAmount(invoice.getTotalAmount())
                .paidAmount(invoice.getPaidAmount())
                .dueAmount(invoice.getDueAmount())
                .dueDate(invoice.getDueDate())
                .status(invoice.getStatus())
                .build();
    }
}
