package com.example.school.service;

import com.example.school.dto.ExamDTOs.*;
import com.example.school.entity.Exam;
import com.example.school.entity.Mark;
import com.example.school.entity.Student;
import com.example.school.entity.Subject;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.ExamRepository;
import com.example.school.repository.MarkRepository;
import com.example.school.repository.StudentRepository;
import com.example.school.repository.SubjectRepository;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ExamResultService {

    private final ExamRepository examRepository;
    private final MarkRepository markRepository;
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;

    @Transactional
    public void submitSubjectMarks(SubmitSubjectMarksRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        Exam exam = examRepository.findByIdAndTenantId(request.getExamId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found: " + request.getExamId()));

        Subject subject = subjectRepository.findByIdAndTenantId(request.getSubjectId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found: " + request.getSubjectId()));

        for (EntryMarkItem item : request.getEntries()) {
            Student student = studentRepository.findByIdAndTenantId(item.getStudentId(), tenantId)
                    .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + item.getStudentId()));

            Mark mark = markRepository.findByTenantIdAndExamIdAndStudentIdAndSubjectId(tenantId, exam.getId(), student.getId(), subject.getId())
                    .orElseGet(() -> {
                        Mark newMark = Mark.builder()
                                .exam(exam)
                                .student(student)
                                .subject(subject)
                                .build();
                        newMark.setTenantId(tenantId);
                        return newMark;
                    });

            BigDecimal total = item.getTotalMarks() != null ? item.getTotalMarks() : BigDecimal.valueOf(subject.getFullMarks());
            mark.setObtainedMarks(item.getObtainedMarks());
            mark.setTotalMarks(total);
            mark.setGrade(calculateGrade(item.getObtainedMarks(), total));
            mark.setRemarks(item.getRemarks());

            markRepository.save(mark);
        }
    }

    @Transactional(readOnly = true)
    public StudentTranscriptResponse generateTranscript(UUID examId, UUID studentId) {
        UUID tenantId = TenantContext.getTenantId();

        Exam exam = examRepository.findByIdAndTenantId(examId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Exam not found"));

        Student student = studentRepository.findByIdAndTenantId(studentId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));

        List<Mark> marks = markRepository.findByTenantIdAndExamIdAndStudentId(tenantId, examId, studentId);

        List<SubjectMarkDetail> details = new ArrayList<>();
        BigDecimal totalObtained = BigDecimal.ZERO;
        BigDecimal totalPossible = BigDecimal.ZERO;
        boolean hasFailed = false;

        for (Mark m : marks) {
            details.add(SubjectMarkDetail.builder()
                    .subjectName(m.getSubject().getName())
                    .subjectCode(m.getSubject().getCode())
                    .obtainedMarks(m.getObtainedMarks())
                    .totalMarks(m.getTotalMarks())
                    .grade(m.getGrade())
                    .remarks(m.getRemarks())
                    .build());

            totalObtained = totalObtained.add(m.getObtainedMarks());
            totalPossible = totalPossible.add(m.getTotalMarks());

            if (m.getObtainedMarks().compareTo(BigDecimal.valueOf(m.getSubject().getPassMarks())) < 0) {
                hasFailed = true;
            }
        }

        BigDecimal percentage = BigDecimal.ZERO;
        if (totalPossible.compareTo(BigDecimal.ZERO) > 0) {
            percentage = totalObtained.divide(totalPossible, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP);
        }

        String overallGrade = calculateGrade(totalObtained, totalPossible);
        double gpa = calculateGpa(percentage);

        return StudentTranscriptResponse.builder()
                .studentId(student.getId())
                .studentName(student.getUser().getFullName())
                .admissionNumber(student.getAdmissionNumber())
                .className(student.getSchoolClass().getName())
                .sectionName(student.getSection().getName())
                .examName(exam.getName())
                .subjectMarks(details)
                .totalObtained(totalObtained)
                .totalPossible(totalPossible)
                .percentage(percentage)
                .overallGrade(overallGrade)
                .gpa(gpa)
                .passFailStatus(hasFailed ? "FAILED" : "PASSED")
                .build();
    }

    private String calculateGrade(BigDecimal obtained, BigDecimal total) {
        if (total == null || total.compareTo(BigDecimal.ZERO) == 0) return "N/A";
        double pct = obtained.doubleValue() / total.doubleValue() * 100.0;
        if (pct >= 90.0) return "A+";
        if (pct >= 80.0) return "A";
        if (pct >= 70.0) return "B";
        if (pct >= 60.0) return "C";
        if (pct >= 50.0) return "D";
        return "F";
    }

    private double calculateGpa(BigDecimal percentage) {
        double pct = percentage.doubleValue();
        if (pct >= 90.0) return 4.0;
        if (pct >= 80.0) return 3.7;
        if (pct >= 70.0) return 3.0;
        if (pct >= 60.0) return 2.0;
        if (pct >= 50.0) return 1.0;
        return 0.0;
    }
}
