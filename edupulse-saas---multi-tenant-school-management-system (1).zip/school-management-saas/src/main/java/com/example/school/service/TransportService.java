package com.example.school.service;

import com.example.school.entity.TransportRoute;
import com.example.school.repository.TransportRouteRepository;
import com.example.school.tenant.TenantContext;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TransportService {

    private final TransportRouteRepository transportRouteRepository;

    @Transactional(readOnly = true)
    public List<TransportRoute> getRoutes() {
        UUID tenantId = TenantContext.getTenantId();
        return transportRouteRepository.findByTenantId(tenantId);
    }

    @Transactional
    public TransportRoute addRoute(CreateRouteRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        TransportRoute route = TransportRoute.builder()
                .routeName(request.getRouteName())
                .vehicleNumber(request.getVehicleNumber())
                .driverName(request.getDriverName())
                .driverPhone(request.getDriverPhone())
                .fareMonthly(request.getFareMonthly() != null ? request.getFareMonthly() : BigDecimal.ZERO)
                .build();
        route.setTenantId(tenantId);

        return transportRouteRepository.save(route);
    }

    @Data
    public static class CreateRouteRequest {
        private String routeName;
        private String vehicleNumber;
        private String driverName;
        private String driverPhone;
        private BigDecimal fareMonthly;
    }
}
