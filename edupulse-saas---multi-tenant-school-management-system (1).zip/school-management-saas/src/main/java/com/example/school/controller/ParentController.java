package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.common.PageResponse;
import com.example.school.entity.Student;
import com.example.school.service.ParentService;
import com.example.school.service.ParentService.CreateParentRequest;
import com.example.school.service.ParentService.ParentResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/parents")
@RequiredArgsConstructor
@Tag(name = "Parents", description = "Endpoints for managing parents, guardians, and linked student dependents")
public class ParentController {

    private final ParentService parentService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Get list of parents and guardians")
    public ResponseEntity<ApiResponse<PageResponse<ParentResponse>>> getParents(Pageable pageable) {
        Page<ParentResponse> page = parentService.getParents(pageable);
        return ResponseEntity.ok(ApiResponse.ok(PageResponse.of(page)));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'PARENT')")
    @Operation(summary = "Get guardian profile by ID")
    public ResponseEntity<ApiResponse<ParentResponse>> getParentById(@PathVariable UUID id) {
        ParentResponse parent = parentService.getParentById(id);
        return ResponseEntity.ok(ApiResponse.ok(parent));
    }

    @GetMapping("/{id}/wards")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'PARENT')")
    @Operation(summary = "Get all student wards associated with guardian")
    public ResponseEntity<ApiResponse<List<Student>>> getParentWards(@PathVariable UUID id) {
        List<Student> wards = parentService.getParentWards(id);
        return ResponseEntity.ok(ApiResponse.ok(wards));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Register new guardian and optionally link to student profile")
    public ResponseEntity<ApiResponse<ParentResponse>> registerParent(
            @RequestBody CreateParentRequest request,
            HttpServletRequest httpRequest) {
        String clientIp = httpRequest.getRemoteAddr();
        ParentResponse response = parentService.registerParent(request, clientIp);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Guardian registered successfully", response));
    }
}
