package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.dto.AuthDTOs.*;
import com.example.school.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication & Onboarding", description = "Endpoints for user login, JWT tokens, and multi-tenant school onboarding")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    @Operation(summary = "Authenticate user and generate JWT token")
    public ResponseEntity<ApiResponse<LoginResponse>> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        String clientIp = httpRequest.getRemoteAddr();
        LoginResponse response = authService.login(request, clientIp);
        return ResponseEntity.ok(ApiResponse.ok("Login successful", response));
    }

    @PostMapping("/register-school")
    @Operation(summary = "Register new school tenant and create school admin user")
    public ResponseEntity<ApiResponse<LoginResponse>> registerSchool(@Valid @RequestBody RegisterSchoolRequest request, HttpServletRequest httpRequest) {
        String clientIp = httpRequest.getRemoteAddr();
        LoginResponse response = authService.registerSchool(request, clientIp);
        return ResponseEntity.ok(ApiResponse.ok("School tenant registered successfully", response));
    }
}
