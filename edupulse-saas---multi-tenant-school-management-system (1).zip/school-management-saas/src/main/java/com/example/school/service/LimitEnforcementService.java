package com.example.school.service;

import com.example.school.entity.Tenant;
import com.example.school.exception.PlanLimitExceededException;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.StudentRepository;
import com.example.school.repository.TeacherRepository;
import com.example.school.repository.TenantRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class LimitEnforcementService {

    private final TenantRepository tenantRepository;
    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;

    public void validateStudentCreationAllowed(UUID tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found: " + tenantId));

        int maxAllowed = tenant.getPlan().getMaxStudents();
        long currentCount = studentRepository.countByTenantId(tenantId);

        if (currentCount >= maxAllowed) {
            throw new PlanLimitExceededException(
                    String.format("School has reached subscription limit of %d students on the '%s' plan. Please upgrade plan.",
                            maxAllowed, tenant.getPlan().getName()));
        }
    }

    public void validateTeacherCreationAllowed(UUID tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found: " + tenantId));

        int maxAllowed = tenant.getPlan().getMaxTeachers();
        long currentCount = teacherRepository.countByTenantId(tenantId);

        if (currentCount >= maxAllowed) {
            throw new PlanLimitExceededException(
                    String.format("School has reached subscription limit of %d teachers on the '%s' plan. Please upgrade plan.",
                            maxAllowed, tenant.getPlan().getName()));
        }
    }
}
