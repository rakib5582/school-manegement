package com.example.school.repository;

import com.example.school.entity.Section;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SectionRepository extends JpaRepository<Section, UUID> {

    @Query("SELECT s FROM Section s WHERE s.id = :id AND s.tenantId = :tenantId")
    Optional<Section> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Section> findByTenantIdAndSchoolClassId(UUID tenantId, UUID classId);
}
