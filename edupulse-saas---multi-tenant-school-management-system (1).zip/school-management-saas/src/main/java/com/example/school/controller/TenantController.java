package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.common.PageResponse;
import com.example.school.dto.TenantDTOs.*;
import com.example.school.service.TenantService;
import com.example.school.tenant.TenantContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Tenants & Dashboards", description = "Endpoints for Super Admin SaaS overview, School Admin dashboard, and tenant lifecycle")
public class TenantController {

    private final TenantService tenantService;

    @GetMapping("/super-admin/dashboard")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Get global SaaS metrics (Super Admin only)")
    public ResponseEntity<ApiResponse<SuperAdminDashboardStats>> getSuperAdminDashboard() {
        SuperAdminDashboardStats stats = tenantService.getSuperAdminStats();
        return ResponseEntity.ok(ApiResponse.ok(stats));
    }

    @GetMapping("/super-admin/tenants")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "List all registered schools with subscription metrics")
    public ResponseEntity<ApiResponse<PageResponse<TenantDetailResponse>>> getAllTenants(Pageable pageable) {
        Page<TenantDetailResponse> page = tenantService.getAllTenants(pageable);
        return ResponseEntity.ok(ApiResponse.ok(PageResponse.of(page)));
    }

    @PatchMapping("/super-admin/tenants/{id}/status")
    @PreAuthorize("hasRole('SUPER_ADMIN')")
    @Operation(summary = "Activate or suspend school tenant")
    public ResponseEntity<ApiResponse<Void>> updateTenantStatus(@PathVariable UUID id, @RequestParam String status) {
        tenantService.updateTenantStatus(id, status);
        return ResponseEntity.ok(ApiResponse.ok("Tenant status updated successfully", null));
    }

    @GetMapping("/school-admin/dashboard")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Get school dashboard metrics for the current tenant")
    public ResponseEntity<ApiResponse<SchoolAdminDashboardStats>> getSchoolAdminDashboard() {
        UUID tenantId = TenantContext.getTenantId();
        SchoolAdminDashboardStats stats = tenantService.getSchoolAdminStats(tenantId);
        return ResponseEntity.ok(ApiResponse.ok(stats));
    }

    @GetMapping("/tenant/settings")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Get school tenant profile and settings")
    public ResponseEntity<ApiResponse<TenantDetailResponse>> getTenantSettings() {
        UUID tenantId = TenantContext.getTenantId();
        TenantDetailResponse settings = tenantService.getTenantSettings(tenantId);
        return ResponseEntity.ok(ApiResponse.ok(settings));
    }

    @PutMapping("/tenant/settings")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Update school tenant profile, session dates, timezone, and portal theme")
    public ResponseEntity<ApiResponse<TenantDetailResponse>> updateTenantSettings(
            @RequestBody UpdateTenantSettingsRequest request) {
        UUID tenantId = TenantContext.getTenantId();
        TenantDetailResponse settings = tenantService.updateTenantSettings(tenantId, request);
        return ResponseEntity.ok(ApiResponse.ok("School settings updated successfully", settings));
    }
}
