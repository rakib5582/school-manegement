package com.example.school.service;

import com.example.school.entity.*;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.*;
import com.example.school.tenant.TenantContext;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AssignmentService {

    private final AssignmentRepository assignmentRepository;
    private final SchoolClassRepository classRepository;
    private final SectionRepository sectionRepository;
    private final SubjectRepository subjectRepository;
    private final TeacherRepository teacherRepository;

    @Transactional(readOnly = true)
    public List<AssignmentResponse> getAssignments(UUID classId) {
        UUID tenantId = TenantContext.getTenantId();
        List<Assignment> list;
        if (classId != null) {
            list = assignmentRepository.findByTenantIdAndClassId(tenantId, classId);
        } else {
            list = assignmentRepository.findByTenantId(tenantId);
        }
        return list.stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    @Transactional
    public AssignmentResponse createAssignment(CreateAssignmentRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        SchoolClass schoolClass = classRepository.findByIdAndTenantId(request.getClassId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found: " + request.getClassId()));
        Section section = sectionRepository.findByIdAndTenantId(request.getSectionId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Section not found: " + request.getSectionId()));
        Subject subject = subjectRepository.findByIdAndTenantId(request.getSubjectId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found: " + request.getSubjectId()));
        Teacher teacher = teacherRepository.findByIdAndTenantId(request.getTeacherId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Teacher not found: " + request.getTeacherId()));

        Assignment assignment = Assignment.builder()
                .schoolClass(schoolClass)
                .section(section)
                .subject(subject)
                .teacher(teacher)
                .title(request.getTitle())
                .description(request.getDescription())
                .dueDate(request.getDueDate())
                .totalPoints(request.getTotalPoints() != null ? request.getTotalPoints() : 100)
                .build();
        assignment.setTenantId(tenantId);

        return mapToResponse(assignmentRepository.save(assignment));
    }

    private AssignmentResponse mapToResponse(Assignment a) {
        return AssignmentResponse.builder()
                .id(a.getId())
                .tenantId(a.getTenantId())
                .classId(a.getSchoolClass() != null ? a.getSchoolClass().getId() : null)
                .className(a.getSchoolClass() != null ? a.getSchoolClass().getName() : "")
                .sectionId(a.getSection() != null ? a.getSection().getId() : null)
                .sectionName(a.getSection() != null ? a.getSection().getName() : "")
                .subjectId(a.getSubject() != null ? a.getSubject().getId() : null)
                .subjectName(a.getSubject() != null ? a.getSubject().getName() : "")
                .teacherId(a.getTeacher() != null ? a.getTeacher().getId() : null)
                .title(a.getTitle())
                .description(a.getDescription())
                .dueDate(a.getDueDate())
                .totalPoints(a.getTotalPoints())
                .build();
    }

    @Data
    public static class CreateAssignmentRequest {
        private UUID classId;
        private UUID sectionId;
        private UUID subjectId;
        private UUID teacherId;
        private String title;
        private String description;
        private LocalDate dueDate;
        private Integer totalPoints;
    }

    @Data
    @Builder
    public static class AssignmentResponse {
        private UUID id;
        private UUID tenantId;
        private UUID classId;
        private String className;
        private UUID sectionId;
        private String sectionName;
        private UUID subjectId;
        private String subjectName;
        private UUID teacherId;
        private String title;
        private String description;
        private LocalDate dueDate;
        private Integer totalPoints;
    }
}
