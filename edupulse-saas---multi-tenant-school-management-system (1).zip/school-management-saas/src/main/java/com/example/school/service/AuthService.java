package com.example.school.service;

import com.example.school.dto.AuthDTOs.*;
import com.example.school.entity.SubscriptionPlan;
import com.example.school.entity.Tenant;
import com.example.school.entity.User;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.SubscriptionPlanRepository;
import com.example.school.repository.TenantRepository;
import com.example.school.repository.UserRepository;
import com.example.school.security.JwtTokenProvider;
import com.example.school.security.Role;
import com.example.school.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;
    private final UserRepository userRepository;
    private final TenantRepository tenantRepository;
    private final SubscriptionPlanRepository planRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    @Transactional
    public LoginResponse login(LoginRequest request, String ipAddress) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmailOrUsername(), request.getPassword())
        );

        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();

        String token = tokenProvider.generateToken(principal);

        // Update user last login timestamp
        userRepository.findById(principal.getId()).ifPresent(user -> {
            user.setLastLoginAt(Instant.now());
            userRepository.save(user);
        });

        String schoolName = null;
        String tenantCode = null;
        if (principal.getTenantId() != null) {
            Tenant tenant = tenantRepository.findById(principal.getTenantId()).orElse(null);
            if (tenant != null) {
                schoolName = tenant.getName();
                tenantCode = tenant.getCode();
            }
        }

        auditLogService.logAction(principal.getId(), principal.getEmail(), "LOGIN", "User",
                principal.getId().toString(), ipAddress, "Successful login as " + principal.getRole());

        return LoginResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .userId(principal.getId())
                .tenantId(principal.getTenantId())
                .tenantCode(tenantCode)
                .schoolName(schoolName)
                .username(principal.getUsername())
                .email(principal.getEmail())
                .fullName(principal.getUsername())
                .role(principal.getRole())
                .build();
    }

    @Transactional
    public LoginResponse registerSchool(RegisterSchoolRequest request, String ipAddress) {
        if (tenantRepository.existsByCode(request.getSchoolCode())) {
            throw new IllegalArgumentException("School code '" + request.getSchoolCode() + "' is already registered");
        }

        SubscriptionPlan plan = planRepository.findByCode(request.getPlanCode())
                .orElseThrow(() -> new ResourceNotFoundException("Subscription plan not found: " + request.getPlanCode()));

        // Create Tenant
        Tenant tenant = Tenant.builder()
                .code(request.getSchoolCode().toUpperCase())
                .name(request.getSchoolName())
                .contactEmail(request.getContactEmail())
                .contactPhone(request.getContactPhone())
                .address(request.getAddress())
                .plan(plan)
                .status("ACTIVE")
                .subscriptionExpiresAt(Instant.now().plus(365, ChronoUnit.DAYS))
                .build();
        tenant = tenantRepository.save(tenant);

        // Create School Admin User
        User schoolAdmin = User.builder()
                .tenantId(tenant.getId())
                .username(request.getAdminUsername())
                .email(request.getContactEmail())
                .passwordHash(passwordEncoder.encode(request.getAdminPassword()))
                .role(Role.SCHOOL_ADMIN)
                .firstName(request.getAdminFirstName())
                .lastName(request.getAdminLastName())
                .phone(request.getContactPhone())
                .active(true)
                .build();
        schoolAdmin = userRepository.save(schoolAdmin);

        auditLogService.logAction(schoolAdmin.getId(), schoolAdmin.getEmail(), "REGISTER_SCHOOL", "Tenant",
                tenant.getId().toString(), ipAddress, "New school registered: " + tenant.getName());

        UserPrincipal principal = UserPrincipal.builder()
                .id(schoolAdmin.getId())
                .tenantId(tenant.getId())
                .username(schoolAdmin.getUsername())
                .email(schoolAdmin.getEmail())
                .password(schoolAdmin.getPasswordHash())
                .role(Role.SCHOOL_ADMIN)
                .active(true)
                .build();

        String token = tokenProvider.generateToken(principal);

        return LoginResponse.builder()
                .token(token)
                .tokenType("Bearer")
                .userId(schoolAdmin.getId())
                .tenantId(tenant.getId())
                .tenantCode(tenant.getCode())
                .schoolName(tenant.getName())
                .username(schoolAdmin.getUsername())
                .email(schoolAdmin.getEmail())
                .fullName(schoolAdmin.getFullName())
                .role(Role.SCHOOL_ADMIN)
                .build();
    }
}
