package com.example.school.repository;

import com.example.school.entity.TransportRoute;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface TransportRouteRepository extends JpaRepository<TransportRoute, UUID> {

    @Query("SELECT r FROM TransportRoute r WHERE r.id = :id AND r.tenantId = :tenantId")
    Optional<TransportRoute> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<TransportRoute> findByTenantId(UUID tenantId);
}
