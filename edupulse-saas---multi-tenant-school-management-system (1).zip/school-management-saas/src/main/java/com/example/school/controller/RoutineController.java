package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.Routine;
import com.example.school.service.RoutineService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/routines")
@RequiredArgsConstructor
@Tag(name = "Class Routines", description = "Endpoints for class schedule management and conflict-checked timetable slots")
public class RoutineController {

    private final RoutineService routineService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get routine timetable slots for a class and section")
    public ResponseEntity<ApiResponse<List<Routine>>> getClassRoutine(
            @RequestParam UUID classId,
            @RequestParam UUID sectionId) {
        List<Routine> routines = routineService.getClassRoutine(classId, sectionId);
        return ResponseEntity.ok(ApiResponse.ok(routines));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Create routine slot with automated teacher and room conflict detection")
    public ResponseEntity<ApiResponse<Routine>> createRoutineSlot(@RequestBody CreateRoutineRequest request) {
        Routine routine = routineService.createRoutineSlot(
                request.getClassId(),
                request.getSectionId(),
                request.getSubjectId(),
                request.getTeacherId(),
                request.getDayOfWeek(),
                request.getStartTime(),
                request.getEndTime(),
                request.getRoomNumber()
        );
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Routine timetable slot created successfully", routine));
    }

    @Data
    public static class CreateRoutineRequest {
        private UUID classId;
        private UUID sectionId;
        private UUID subjectId;
        private UUID teacherId;
        private String dayOfWeek;
        @DateTimeFormat(iso = DateTimeFormat.ISO.TIME)
        private LocalTime startTime;
        @DateTimeFormat(iso = DateTimeFormat.ISO.TIME)
        private LocalTime endTime;
        private String roomNumber;
    }
}
