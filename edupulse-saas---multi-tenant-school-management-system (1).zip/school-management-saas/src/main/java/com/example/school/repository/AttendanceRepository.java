package com.example.school.repository;

import com.example.school.entity.Attendance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, UUID> {

    @Query("SELECT a FROM Attendance a WHERE a.id = :id AND a.tenantId = :tenantId")
    Optional<Attendance> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Attendance> findByTenantIdAndAttendanceDate(UUID tenantId, LocalDate date);

    List<Attendance> findByTenantIdAndStudentId(UUID tenantId, UUID studentId);

    Optional<Attendance> findByTenantIdAndStudentIdAndAttendanceDate(UUID tenantId, UUID studentId, LocalDate date);

    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.tenantId = :tenantId AND a.attendanceDate = :date AND a.status = :status")
    long countByTenantIdAndAttendanceDateAndStatus(@Param("tenantId") UUID tenantId, @Param("date") LocalDate date, @Param("status") String status);

    @Query("SELECT COUNT(a) FROM Attendance a WHERE a.tenantId = :tenantId AND a.attendanceDate = :date")
    long countByTenantIdAndAttendanceDate(@Param("tenantId") UUID tenantId, @Param("date") LocalDate date);

    boolean existsByTenantIdAndStudentIdAndAttendanceDate(UUID tenantId, UUID studentId, LocalDate date);
}
