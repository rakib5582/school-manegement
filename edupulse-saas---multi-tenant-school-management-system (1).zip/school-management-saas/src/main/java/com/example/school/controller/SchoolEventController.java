package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.SchoolEvent;
import com.example.school.service.SchoolEventService;
import com.example.school.service.SchoolEventService.CreateEventRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/events")
@RequiredArgsConstructor
@Tag(name = "Events", description = "Endpoints for academic calendar, holidays, and school events")
public class SchoolEventController {

    private final SchoolEventService eventService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get list of scheduled school events")
    public ResponseEntity<ApiResponse<List<SchoolEvent>>> getEvents(@RequestParam(required = false) String type) {
        List<SchoolEvent> events = eventService.getEvents(type);
        return ResponseEntity.ok(ApiResponse.ok(events));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Schedule new institutional event")
    public ResponseEntity<ApiResponse<SchoolEvent>> addEvent(@RequestBody CreateEventRequest request) {
        SchoolEvent event = eventService.addEvent(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Event scheduled successfully", event));
    }
}
