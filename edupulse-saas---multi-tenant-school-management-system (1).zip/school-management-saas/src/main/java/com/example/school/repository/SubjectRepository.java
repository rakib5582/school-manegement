package com.example.school.repository;

import com.example.school.entity.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SubjectRepository extends JpaRepository<Subject, UUID> {

    @Query("SELECT s FROM Subject s WHERE s.id = :id AND s.tenantId = :tenantId")
    Optional<Subject> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Subject> findByTenantId(UUID tenantId);

    long countByTenantId(UUID tenantId);
}
