package com.example.school.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public class FeeDTOs {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateInvoiceRequest {
        @NotNull(message = "Student ID is required")
        private UUID studentId;

        @NotBlank(message = "Invoice title is required")
        private String title;

        @NotNull(message = "Total amount is required")
        @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
        private BigDecimal totalAmount;

        @NotNull(message = "Due date is required")
        private LocalDate dueDate;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RecordPaymentRequest {
        @NotNull(message = "Invoice ID is required")
        private UUID invoiceId;

        @NotNull(message = "Payment amount is required")
        @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
        private BigDecimal amount;

        @NotBlank(message = "Payment method is required (CASH, CARD, BANK_TRANSFER, ONLINE)")
        private String paymentMethod;

        private String transactionId;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class InvoiceResponse {
        private UUID id;
        private UUID studentId;
        private String studentName;
        private String invoiceNumber;
        private String title;
        private BigDecimal totalAmount;
        private BigDecimal paidAmount;
        private BigDecimal dueAmount;
        private LocalDate dueDate;
        private String status;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReceiptResponse {
        private UUID paymentId;
        private String receiptNumber;
        private String invoiceNumber;
        private String studentName;
        private BigDecimal amountPaid;
        private String paymentMethod;
        private String transactionId;
        private Instant paidAt;
    }
}
