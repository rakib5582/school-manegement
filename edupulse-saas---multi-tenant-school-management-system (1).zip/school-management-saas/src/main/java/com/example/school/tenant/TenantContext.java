package com.example.school.tenant;

import java.util.UUID;

/**
 * ThreadLocal-based Tenant Context holder.
 * Stores the current tenant ID for the executing request thread.
 * Guarantees zero cross-tenant contamination across asynchronous contexts.
 */
public final class TenantContext {

    private static final ThreadLocal<UUID> CURRENT_TENANT = new ThreadLocal<>();

    private TenantContext() {
    }

    public static void setTenantId(UUID tenantId) {
        CURRENT_TENANT.set(tenantId);
    }

    public static UUID getTenantId() {
        return CURRENT_TENANT.get();
    }

    public static void clear() {
        CURRENT_TENANT.remove();
    }
}
