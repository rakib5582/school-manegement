package com.example.school.repository;

import com.example.school.entity.Parent;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface ParentRepository extends JpaRepository<Parent, UUID> {

    @Query("SELECT p FROM Parent p WHERE p.id = :id AND p.tenantId = :tenantId")
    Optional<Parent> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    Page<Parent> findByTenantId(UUID tenantId, Pageable pageable);

    Optional<Parent> findByTenantIdAndUserId(UUID tenantId, UUID userId);

    long countByTenantId(UUID tenantId);
}
