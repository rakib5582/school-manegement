package com.example.school.service;

import com.example.school.dto.TenantDTOs.*;
import com.example.school.entity.Tenant;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TenantService {

    private final TenantRepository tenantRepository;
    private final StudentRepository studentRepository;
    private final TeacherRepository teacherRepository;
    private final SchoolClassRepository classRepository;
    private final ParentRepository parentRepository;
    private final AttendanceRepository attendanceRepository;
    private final FeeInvoiceRepository feeInvoiceRepository;
    private final ExamRepository examRepository;
    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public SuperAdminDashboardStats getSuperAdminStats() {
        long totalSchools = tenantRepository.count();
        long activeSchools = tenantRepository.findAll().stream().filter(t -> "ACTIVE".equalsIgnoreCase(t.getStatus())).count();
        long suspendedSchools = totalSchools - activeSchools;
        long totalUsers = userRepository.count();
        long totalStudents = studentRepository.count();
        long totalTeachers = teacherRepository.count();

        // Estimated MRR based on active plans
        BigDecimal mrr = tenantRepository.findAll().stream()
                .filter(t -> "ACTIVE".equalsIgnoreCase(t.getStatus()) && t.getPlan() != null)
                .map(t -> t.getPlan().getPricePerMonth())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        return SuperAdminDashboardStats.builder()
                .totalSchools(totalSchools)
                .activeSchools(activeSchools)
                .suspendedSchools(suspendedSchools)
                .totalUsers(totalUsers)
                .totalStudents(totalStudents)
                .totalTeachers(totalTeachers)
                .monthlyRevenueEstimate(mrr)
                .build();
    }

    @Transactional(readOnly = true)
    public SchoolAdminDashboardStats getSchoolAdminStats(UUID tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("School tenant not found"));

        long totalStudents = studentRepository.countByTenantId(tenantId);
        long totalTeachers = teacherRepository.countByTenantId(tenantId);
        long totalClasses = classRepository.countByTenantId(tenantId);
        long totalParents = parentRepository.countByTenantId(tenantId);

        LocalDate today = LocalDate.now();
        long totalTodayAttendance = attendanceRepository.countByTenantIdAndAttendanceDate(tenantId, today);
        long presentToday = attendanceRepository.countByTenantIdAndAttendanceDateAndStatus(tenantId, today, "PRESENT");
        double attendanceRate = totalTodayAttendance > 0 ? ((double) presentToday / totalTodayAttendance) * 100.0 : 0.0;

        BigDecimal totalCollected = feeInvoiceRepository.sumPaidAmountByTenantId(tenantId);
        BigDecimal totalInvoiced = feeInvoiceRepository.sumTotalAmountByTenantId(tenantId);
        BigDecimal totalDue = totalInvoiced.subtract(totalCollected);

        long upcomingExams = examRepository.countByTenantId(tenantId);
        long pendingInvoices = feeInvoiceRepository.countByTenantIdAndStatus(tenantId, "UNPAID");

        return SchoolAdminDashboardStats.builder()
                .schoolName(tenant.getName())
                .schoolCode(tenant.getCode())
                .totalStudents(totalStudents)
                .totalTeachers(totalTeachers)
                .totalClasses(totalClasses)
                .totalParents(totalParents)
                .todayAttendanceRate(Math.round(attendanceRate * 10.0) / 10.0)
                .totalFeesCollected(totalCollected)
                .totalFeesDue(totalDue)
                .upcomingExamsCount(upcomingExams)
                .pendingInvoicesCount(pendingInvoices)
                .build();
    }

    @Transactional(readOnly = true)
    public Page<TenantDetailResponse> getAllTenants(Pageable pageable) {
        return tenantRepository.findAll(pageable).map(tenant -> TenantDetailResponse.builder()
                .id(tenant.getId())
                .code(tenant.getCode())
                .name(tenant.getName())
                .subdomain(tenant.getSubdomain())
                .contactEmail(tenant.getContactEmail())
                .contactPhone(tenant.getContactPhone())
                .address(tenant.getAddress())
                .status(tenant.getStatus())
                .planCode(tenant.getPlan().getCode())
                .planName(tenant.getPlan().getName())
                .maxStudents(tenant.getPlan().getMaxStudents())
                .maxTeachers(tenant.getPlan().getMaxTeachers())
                .currentStudents(studentRepository.countByTenantId(tenant.getId()))
                .currentTeachers(teacherRepository.countByTenantId(tenant.getId()))
                .primaryColor(tenant.getPrimaryColor())
                .build());
    }

    @Transactional
    public void updateTenantStatus(UUID tenantId, String status) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found: " + tenantId));
        tenant.setStatus(status.toUpperCase());
        tenantRepository.save(tenant);
    }

    @Transactional(readOnly = true)
    public TenantDetailResponse getTenantSettings(UUID tenantId) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found: " + tenantId));
        return mapToDetailResponse(tenant);
    }

    @Transactional
    public TenantDetailResponse updateTenantSettings(UUID tenantId, UpdateTenantSettingsRequest request) {
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant not found: " + tenantId));

        if (request.getName() != null) tenant.setName(request.getName());
        if (request.getContactEmail() != null) tenant.setContactEmail(request.getContactEmail());
        if (request.getContactPhone() != null) tenant.setContactPhone(request.getContactPhone());
        if (request.getAddress() != null) tenant.setAddress(request.getAddress());
        if (request.getPrimaryColor() != null) tenant.setPrimaryColor(request.getPrimaryColor());
        if (request.getSecondaryColor() != null) tenant.setSecondaryColor(request.getSecondaryColor());
        if (request.getTimezone() != null) tenant.setTimezone(request.getTimezone());
        if (request.getCurrency() != null) tenant.setCurrency(request.getCurrency());
        if (request.getAcademicYearName() != null) tenant.setAcademicYearName(request.getAcademicYearName());

        return mapToDetailResponse(tenantRepository.save(tenant));
    }

    private TenantDetailResponse mapToDetailResponse(Tenant tenant) {
        return TenantDetailResponse.builder()
                .id(tenant.getId())
                .code(tenant.getCode())
                .name(tenant.getName())
                .subdomain(tenant.getSubdomain())
                .contactEmail(tenant.getContactEmail())
                .contactPhone(tenant.getContactPhone())
                .address(tenant.getAddress())
                .status(tenant.getStatus())
                .planCode(tenant.getPlan() != null ? tenant.getPlan().getCode() : "BASIC")
                .planName(tenant.getPlan() != null ? tenant.getPlan().getName() : "Standard")
                .maxStudents(tenant.getPlan() != null ? tenant.getPlan().getMaxStudents() : 500)
                .maxTeachers(tenant.getPlan() != null ? tenant.getPlan().getMaxTeachers() : 35)
                .currentStudents(studentRepository.countByTenantId(tenant.getId()))
                .currentTeachers(teacherRepository.countByTenantId(tenant.getId()))
                .primaryColor(tenant.getPrimaryColor())
                .build();
    }
}
