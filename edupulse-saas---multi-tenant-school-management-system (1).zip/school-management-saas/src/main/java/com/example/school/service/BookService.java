package com.example.school.service;

import com.example.school.entity.Book;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.BookRepository;
import com.example.school.tenant.TenantContext;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepository;

    @Transactional(readOnly = true)
    public List<Book> getBooks(String query) {
        UUID tenantId = TenantContext.getTenantId();
        if (query != null && !query.isBlank()) {
            return bookRepository.searchBooks(tenantId, query.trim());
        }
        return bookRepository.findByTenantId(tenantId);
    }

    @Transactional
    public Book addBook(CreateBookRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        int copies = request.getTotalCopies() != null && request.getTotalCopies() > 0 ? request.getTotalCopies() : 1;

        Book book = Book.builder()
                .title(request.getTitle())
                .author(request.getAuthor())
                .isbn(request.getIsbn())
                .totalCopies(copies)
                .availableCopies(copies)
                .rackNumber(request.getRackNumber())
                .build();
        book.setTenantId(tenantId);

        return bookRepository.save(book);
    }

    @Transactional
    public Book issueBook(UUID bookId) {
        UUID tenantId = TenantContext.getTenantId();
        Book book = bookRepository.findByIdAndTenantId(bookId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found: " + bookId));

        if (book.getAvailableCopies() <= 0) {
            throw new IllegalStateException("No available copies to issue for book: " + book.getTitle());
        }

        book.setAvailableCopies(book.getAvailableCopies() - 1);
        return bookRepository.save(book);
    }

    @Transactional
    public Book returnBook(UUID bookId) {
        UUID tenantId = TenantContext.getTenantId();
        Book book = bookRepository.findByIdAndTenantId(bookId, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found: " + bookId));

        if (book.getAvailableCopies() >= book.getTotalCopies()) {
            throw new IllegalStateException("All copies of this book are already in the library.");
        }

        book.setAvailableCopies(book.getAvailableCopies() + 1);
        return bookRepository.save(book);
    }

    @Data
    public static class CreateBookRequest {
        private String title;
        private String author;
        private String isbn;
        private Integer totalCopies;
        private String rackNumber;
    }
}
