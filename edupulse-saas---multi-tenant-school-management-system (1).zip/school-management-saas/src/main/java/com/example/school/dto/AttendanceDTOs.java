package com.example.school.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class AttendanceDTOs {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MarkStudentAttendanceRequest {
        @NotNull(message = "Student ID is required")
        private UUID studentId;

        @NotBlank(message = "Status is required (PRESENT, ABSENT, LATE, LEAVE)")
        private String status;

        private String remarks;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BulkAttendanceRequest {
        @NotNull(message = "Class ID is required")
        private UUID classId;

        @NotNull(message = "Section ID is required")
        private UUID sectionId;

        @NotNull(message = "Date is required")
        private LocalDate date;

        @NotNull(message = "Attendance list is required")
        private List<MarkStudentAttendanceRequest> records;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AttendanceSummaryResponse {
        private LocalDate date;
        private long totalStudents;
        private long presentCount;
        private long absentCount;
        private long lateCount;
        private double attendancePercentage;
    }
}
