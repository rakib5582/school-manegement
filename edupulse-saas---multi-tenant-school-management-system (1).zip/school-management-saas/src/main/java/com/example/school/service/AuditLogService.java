package com.example.school.service;

import com.example.school.entity.AuditLog;
import com.example.school.repository.AuditLogRepository;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogService {

    private final AuditLogRepository auditLogRepository;

    @Async
    public void logAction(UUID userId, String userEmail, String action, String entityName, String entityId, String ipAddress, String description) {
        try {
            AuditLog auditLog = AuditLog.builder()
                    .tenantId(TenantContext.getTenantId())
                    .userId(userId)
                    .userEmail(userEmail)
                    .action(action)
                    .entityName(entityName)
                    .entityId(entityId)
                    .ipAddress(ipAddress != null ? ipAddress : "127.0.0.1")
                    .description(description)
                    .build();

            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.error("Failed to persist audit log: {}", e.getMessage());
        }
    }
}
