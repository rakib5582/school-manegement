package com.example.school.service;

import com.example.school.dto.TeacherDTOs.*;
import com.example.school.entity.Teacher;
import com.example.school.entity.User;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.exception.TenantAccessDeniedException;
import com.example.school.repository.TeacherRepository;
import com.example.school.repository.UserRepository;
import com.example.school.security.Role;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TeacherService {

    private final TeacherRepository teacherRepository;
    private final UserRepository userRepository;
    private final LimitEnforcementService limitEnforcementService;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    @Transactional(readOnly = true)
    public Page<TeacherResponse> getTeachers(Pageable pageable) {
        UUID tenantId = TenantContext.getTenantId();
        return teacherRepository.findByTenantId(tenantId, pageable).map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public TeacherResponse getTeacherById(UUID id) {
        UUID currentTenantId = TenantContext.getTenantId();
        Teacher teacher = teacherRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Teacher not found with ID: " + id));

        if (!teacher.getTenantId().equals(currentTenantId)) {
            throw new TenantAccessDeniedException("Cross-tenant access prohibited. Teacher belongs to tenant: " + teacher.getTenantId());
        }

        return mapToResponse(teacher);
    }

    @Transactional
    public TeacherResponse createTeacher(CreateTeacherRequest request, String ipAddress) {
        UUID tenantId = TenantContext.getTenantId();

        limitEnforcementService.validateTeacherCreationAllowed(tenantId);

        if (teacherRepository.existsByTenantIdAndEmployeeId(tenantId, request.getEmployeeId())) {
            throw new IllegalArgumentException("Employee ID already exists in this school: " + request.getEmployeeId());
        }

        String username = request.getEmployeeId().toLowerCase().replace("-", "_");
        User user = User.builder()
                .tenantId(tenantId)
                .username(username)
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode("Teacher@2026!"))
                .role(Role.TEACHER)
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .phone(request.getPhone())
                .active(true)
                .build();
        user = userRepository.save(user);

        Teacher teacher = Teacher.builder()
                .user(user)
                .employeeId(request.getEmployeeId())
                .designation(request.getDesignation())
                .department(request.getDepartment())
                .qualification(request.getQualification())
                .joiningDate(request.getJoiningDate())
                .salary(request.getSalary())
                .status("ACTIVE")
                .build();
        teacher.setTenantId(tenantId);
        teacher = teacherRepository.save(teacher);

        auditLogService.logAction(user.getId(), user.getEmail(), "CREATE_TEACHER", "Teacher",
                teacher.getId().toString(), ipAddress, "Added faculty member " + user.getFullName() + " (" + teacher.getEmployeeId() + ")");

        return mapToResponse(teacher);
    }

    private TeacherResponse mapToResponse(Teacher teacher) {
        return TeacherResponse.builder()
                .id(teacher.getId())
                .tenantId(teacher.getTenantId())
                .userId(teacher.getUser().getId())
                .employeeId(teacher.getEmployeeId())
                .fullName(teacher.getUser().getFullName())
                .email(teacher.getUser().getEmail())
                .phone(teacher.getUser().getPhone())
                .designation(teacher.getDesignation())
                .department(teacher.getDepartment())
                .qualification(teacher.getQualification())
                .joiningDate(teacher.getJoiningDate())
                .salary(teacher.getSalary())
                .status(teacher.getStatus())
                .build();
    }
}
