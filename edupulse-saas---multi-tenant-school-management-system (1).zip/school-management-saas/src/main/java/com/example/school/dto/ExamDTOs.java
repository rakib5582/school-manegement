package com.example.school.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public class ExamDTOs {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateExamRequest {
        @NotBlank(message = "Exam name is required")
        private String name;

        @NotNull(message = "Start date is required")
        private LocalDate startDate;

        @NotNull(message = "End date is required")
        private LocalDate endDate;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class EntryMarkItem {
        @NotNull(message = "Student ID is required")
        private UUID studentId;

        @NotNull(message = "Obtained marks is required")
        private BigDecimal obtainedMarks;

        private BigDecimal totalMarks;
        private String remarks;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubmitSubjectMarksRequest {
        @NotNull(message = "Exam ID is required")
        private UUID examId;

        @NotNull(message = "Subject ID is required")
        private UUID subjectId;

        @NotNull(message = "Marks list is required")
        private List<EntryMarkItem> entries;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubjectMarkDetail {
        private String subjectName;
        private String subjectCode;
        private BigDecimal obtainedMarks;
        private BigDecimal totalMarks;
        private String grade;
        private String remarks;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StudentTranscriptResponse {
        private UUID studentId;
        private String studentName;
        private String admissionNumber;
        private String className;
        private String sectionName;
        private String examName;
        private List<SubjectMarkDetail> subjectMarks;
        private BigDecimal totalObtained;
        private BigDecimal totalPossible;
        private BigDecimal percentage;
        private String overallGrade;
        private double gpa;
        private String passFailStatus;
    }
}
