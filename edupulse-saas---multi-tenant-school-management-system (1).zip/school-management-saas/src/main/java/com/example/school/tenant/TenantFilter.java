package com.example.school.tenant;

import com.example.school.security.UserPrincipal;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.lang.NonNull;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * Filter that establishes the tenant context from authenticated JWT principal.
 * Never trusts raw, spoofable client-side headers without server-side validation.
 */
@Slf4j
@Component
public class TenantFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(
            @NonNull HttpServletRequest request,
            @NonNull HttpServletResponse response,
            @NonNull FilterChain filterChain) throws ServletException, IOException {

        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

            if (authentication != null && authentication.getPrincipal() instanceof UserPrincipal principal) {
                // Determine tenant from server-side authenticated context
                if (principal.isSuperAdmin()) {
                    // Super Admins may optionally simulate/scope to a tenant via header
                    String requestedTenantHeader = request.getHeader("X-Tenant-ID");
                    if (requestedTenantHeader != null && !requestedTenantHeader.isBlank()) {
                        try {
                            TenantContext.setTenantId(UUID.fromString(requestedTenantHeader));
                        } catch (IllegalArgumentException e) {
                            log.warn("Invalid X-Tenant-ID provided by super admin: {}", requestedTenantHeader);
                        }
                    }
                } else if (principal.getTenantId() != null) {
                    // Regular tenant users are strictly pinned to their own tenant
                    TenantContext.setTenantId(principal.getTenantId());
                }
            }

            filterChain.doFilter(request, response);
        } finally {
            TenantContext.clear();
        }
    }
}
