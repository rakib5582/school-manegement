package com.example.school.repository;

import com.example.school.entity.SchoolEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface SchoolEventRepository extends JpaRepository<SchoolEvent, UUID> {

    @Query("SELECT e FROM SchoolEvent e WHERE e.id = :id AND e.tenantId = :tenantId")
    Optional<SchoolEvent> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<SchoolEvent> findByTenantIdOrderByEventDateAsc(UUID tenantId);

    @Query("SELECT e FROM SchoolEvent e WHERE e.tenantId = :tenantId AND e.eventType = :type ORDER BY e.eventDate ASC")
    List<SchoolEvent> findByTenantIdAndEventType(@Param("tenantId") UUID tenantId, @Param("type") String type);
}
