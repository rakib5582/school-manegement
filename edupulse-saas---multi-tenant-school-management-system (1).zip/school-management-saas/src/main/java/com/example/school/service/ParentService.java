package com.example.school.service;

import com.example.school.entity.Parent;
import com.example.school.entity.Student;
import com.example.school.entity.User;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.repository.ParentRepository;
import com.example.school.repository.StudentRepository;
import com.example.school.repository.UserRepository;
import com.example.school.security.Role;
import com.example.school.tenant.TenantContext;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ParentService {

    private final ParentRepository parentRepository;
    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    @Transactional(readOnly = true)
    public Page<ParentResponse> getParents(Pageable pageable) {
        UUID tenantId = TenantContext.getTenantId();
        return parentRepository.findByTenantId(tenantId, pageable).map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public ParentResponse getParentById(UUID id) {
        UUID tenantId = TenantContext.getTenantId();
        Parent parent = parentRepository.findByIdAndTenantId(id, tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Parent not found: " + id));
        return mapToResponse(parent);
    }

    @Transactional(readOnly = true)
    public List<Student> getParentWards(UUID parentId) {
        UUID tenantId = TenantContext.getTenantId();
        return studentRepository.findByTenantIdAndParentId(tenantId, parentId);
    }

    @Transactional
    public ParentResponse registerParent(CreateParentRequest request, String ipAddress) {
        UUID tenantId = TenantContext.getTenantId();

        String username = "parent_" + request.getEmail().split("@")[0].toLowerCase().replaceAll("[^a-z0-9]", "_");
        User user = User.builder()
                .tenantId(tenantId)
                .username(username)
                .email(request.getEmail().toLowerCase().trim())
                .passwordHash(passwordEncoder.encode("Parent@123"))
                .role(Role.PARENT)
                .firstName(request.getFirstName().trim())
                .lastName(request.getLastName().trim())
                .phone(request.getPhone())
                .active(true)
                .build();
        user = userRepository.save(user);

        Parent parent = Parent.builder()
                .user(user)
                .occupation(request.getOccupation())
                .relationship(request.getRelationship() != null ? request.getRelationship() : "Parent")
                .build();
        parent.setTenantId(tenantId);
        parent = parentRepository.save(parent);

        if (request.getStudentId() != null) {
            Student student = studentRepository.findByIdAndTenantId(request.getStudentId(), tenantId)
                    .orElse(null);
            if (student != null) {
                student.setParent(parent);
                studentRepository.save(student);
            }
        }

        auditLogService.logAction(
                user.getId(),
                user.getEmail(),
                "REGISTER_PARENT",
                "Parent",
                parent.getId().toString(),
                ipAddress,
                "Registered parent guardian " + request.getFirstName() + " " + request.getLastName()
        );

        return mapToResponse(parent);
    }

    private ParentResponse mapToResponse(Parent parent) {
        return ParentResponse.builder()
                .id(parent.getId())
                .tenantId(parent.getTenantId())
                .userId(parent.getUser() != null ? parent.getUser().getId() : null)
                .firstName(parent.getUser() != null ? parent.getUser().getFirstName() : "")
                .lastName(parent.getUser() != null ? parent.getUser().getLastName() : "")
                .email(parent.getUser() != null ? parent.getUser().getEmail() : "")
                .phone(parent.getUser() != null ? parent.getUser().getPhone() : "")
                .occupation(parent.getOccupation())
                .relationship(parent.getRelationship())
                .build();
    }

    @Data
    public static class CreateParentRequest {
        private String firstName;
        private String lastName;
        private String email;
        private String phone;
        private String occupation;
        private String relationship;
        private UUID studentId;
    }

    @Data
    @Builder
    public static class ParentResponse {
        private UUID id;
        private UUID tenantId;
        private UUID userId;
        private String firstName;
        private String lastName;
        private String email;
        private String phone;
        private String occupation;
        private String relationship;
    }
}
