package com.example.school.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.UUID;

public class StudentDTOs {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateStudentRequest {
        @NotBlank(message = "First name is required")
        private String firstName;

        @NotBlank(message = "Last name is required")
        private String lastName;

        @NotBlank(message = "Email is required")
        private String email;

        @NotBlank(message = "Admission number is required")
        private String admissionNumber;

        private String rollNumber;

        @NotNull(message = "Class ID is required")
        private UUID classId;

        @NotNull(message = "Section ID is required")
        private UUID sectionId;

        private String gender;
        private LocalDate dateOfBirth;
        private String bloodGroup;
        private String phone;
        private String emergencyContact;
        private UUID parentId;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StudentResponse {
        private UUID id;
        private UUID tenantId;
        private UUID userId;
        private String admissionNumber;
        private String rollNumber;
        private String fullName;
        private String email;
        private String phone;
        private String className;
        private String sectionName;
        private String gender;
        private LocalDate dateOfBirth;
        private String bloodGroup;
        private String status;
        private String avatarUrl;
    }
}
