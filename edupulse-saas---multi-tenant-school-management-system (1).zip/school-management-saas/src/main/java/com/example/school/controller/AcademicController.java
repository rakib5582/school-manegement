package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.SchoolClass;
import com.example.school.entity.Section;
import com.example.school.entity.Subject;
import com.example.school.service.AcademicService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/academics")
@RequiredArgsConstructor
@Tag(name = "Academics", description = "Endpoints for managing School Classes, Sections, and Subjects")
public class AcademicController {

    private final AcademicService academicService;

    @GetMapping("/classes")
    @Operation(summary = "Get list of classes in current tenant")
    public ResponseEntity<ApiResponse<List<SchoolClass>>> getClasses() {
        return ResponseEntity.ok(ApiResponse.ok(academicService.getClasses()));
    }

    @PostMapping("/classes")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Create class grade")
    public ResponseEntity<ApiResponse<SchoolClass>> createClass(@RequestParam String name, @RequestParam Integer numericGrade) {
        SchoolClass c = academicService.createClass(name, numericGrade);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(c));
    }

    @GetMapping("/sections")
    @Operation(summary = "Get list of sections for class")
    public ResponseEntity<ApiResponse<List<Section>>> getSections(@RequestParam(required = false) UUID classId) {
        return ResponseEntity.ok(ApiResponse.ok(academicService.getSections(classId)));
    }

    @PostMapping("/sections")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Create section for class")
    public ResponseEntity<ApiResponse<Section>> createSection(@RequestParam UUID classId, @RequestParam String name, @RequestParam(required = false) Integer capacity) {
        Section s = academicService.createSection(classId, name, capacity);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(s));
    }

    @GetMapping("/subjects")
    @Operation(summary = "Get list of subjects")
    public ResponseEntity<ApiResponse<List<Subject>>> getSubjects() {
        return ResponseEntity.ok(ApiResponse.ok(academicService.getSubjects()));
    }

    @PostMapping("/subjects")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Create subject")
    public ResponseEntity<ApiResponse<Subject>> createSubject(
            @RequestParam String name,
            @RequestParam String code,
            @RequestParam(required = false) String type,
            @RequestParam(required = false) Integer fullMarks,
            @RequestParam(required = false) Integer passMarks) {
        Subject s = academicService.createSubject(name, code, type, fullMarks, passMarks);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok(s));
    }
}
