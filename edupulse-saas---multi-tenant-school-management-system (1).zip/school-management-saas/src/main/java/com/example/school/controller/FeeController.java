package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.common.PageResponse;
import com.example.school.dto.FeeDTOs.*;
import com.example.school.service.FeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/fees")
@RequiredArgsConstructor
@Tag(name = "Fees & Payments", description = "Endpoints for managing invoices, student balances, and generating official payment receipts")
public class FeeController {

    private final FeeService feeService;

    @GetMapping("/invoices")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get list of invoices within current tenant")
    public ResponseEntity<ApiResponse<PageResponse<InvoiceResponse>>> getInvoices(Pageable pageable) {
        Page<InvoiceResponse> page = feeService.getInvoices(pageable);
        return ResponseEntity.ok(ApiResponse.ok(PageResponse.of(page)));
    }

    @PostMapping("/invoices")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Generate new fee invoice for a student")
    public ResponseEntity<ApiResponse<InvoiceResponse>> createInvoice(@Valid @RequestBody CreateInvoiceRequest request) {
        InvoiceResponse response = feeService.createInvoice(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Invoice generated", response));
    }

    @PostMapping("/payments")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'PARENT')")
    @Operation(summary = "Record fee payment and generate printable receipt voucher")
    public ResponseEntity<ApiResponse<ReceiptResponse>> recordPayment(@Valid @RequestBody RecordPaymentRequest request) {
        ReceiptResponse response = feeService.recordPayment(request);
        return ResponseEntity.ok(ApiResponse.ok("Payment recorded successfully", response));
    }
}
