package com.example.school.entity;

import com.example.school.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

@Entity
@Table(name = "subjects")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Subject extends TenantAwareEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 50)
    private String code;

    @Column(length = 30)
    @Builder.Default
    private String type = "THEORY";

    @Column(name = "full_marks")
    @Builder.Default
    private Integer fullMarks = 100;

    @Column(name = "pass_marks")
    @Builder.Default
    private Integer passMarks = 40;
}
