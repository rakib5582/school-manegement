package com.example.school.repository;

import com.example.school.entity.HostelRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface HostelRoomRepository extends JpaRepository<HostelRoom, UUID> {

    @Query("SELECT h FROM HostelRoom h WHERE h.id = :id AND h.tenantId = :tenantId")
    Optional<HostelRoom> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<HostelRoom> findByTenantId(UUID tenantId);
}
