package com.example.school.repository;

import com.example.school.entity.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface StudentRepository extends JpaRepository<Student, UUID> {

    @Query("SELECT s FROM Student s WHERE s.id = :id AND s.tenantId = :tenantId")
    Optional<Student> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    Page<Student> findByTenantId(UUID tenantId, Pageable pageable);

    Page<Student> findByTenantIdAndSchoolClassId(UUID tenantId, UUID classId, Pageable pageable);

    Page<Student> findByTenantIdAndSchoolClassIdAndSectionId(UUID tenantId, UUID classId, UUID sectionId, Pageable pageable);

    Optional<Student> findByTenantIdAndUserId(UUID tenantId, UUID userId);

    Optional<Student> findByTenantIdAndAdmissionNumber(UUID tenantId, String admissionNumber);

    @Query("SELECT s FROM Student s WHERE s.tenantId = :tenantId AND s.parent.id = :parentId")
    java.util.List<Student> findByTenantIdAndParentId(@Param("tenantId") UUID tenantId, @Param("parentId") UUID parentId);

    long countByTenantId(UUID tenantId);

    boolean existsByTenantIdAndAdmissionNumber(UUID tenantId, String admissionNumber);
}
