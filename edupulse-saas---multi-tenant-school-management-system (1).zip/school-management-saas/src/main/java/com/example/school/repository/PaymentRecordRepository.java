package com.example.school.repository;

import com.example.school.entity.PaymentRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PaymentRecordRepository extends JpaRepository<PaymentRecord, UUID> {

    @Query("SELECT p FROM PaymentRecord p WHERE p.id = :id AND p.tenantId = :tenantId")
    Optional<PaymentRecord> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    Page<PaymentRecord> findByTenantId(UUID tenantId, Pageable pageable);

    @Query("SELECT COALESCE(SUM(p.amount), 0) FROM PaymentRecord p WHERE p.tenantId = :tenantId")
    BigDecimal sumAmountByTenantId(@Param("tenantId") UUID tenantId);
}
