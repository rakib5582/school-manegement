package com.example.school.service;

import com.example.school.entity.HostelRoom;
import com.example.school.repository.HostelRoomRepository;
import com.example.school.tenant.TenantContext;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class HostelService {

    private final HostelRoomRepository hostelRoomRepository;

    @Transactional(readOnly = true)
    public List<HostelRoom> getHostels() {
        UUID tenantId = TenantContext.getTenantId();
        return hostelRoomRepository.findByTenantId(tenantId);
    }

    @Transactional
    public HostelRoom addRoom(CreateHostelRequest request) {
        UUID tenantId = TenantContext.getTenantId();

        HostelRoom room = HostelRoom.builder()
                .buildingName(request.getBuildingName())
                .roomNumber(request.getRoomNumber())
                .bedCount(request.getBedCount() != null ? request.getBedCount() : 2)
                .monthlyFee(request.getMonthlyFee() != null ? request.getMonthlyFee() : BigDecimal.ZERO)
                .build();
        room.setTenantId(tenantId);

        return hostelRoomRepository.save(room);
    }

    @Data
    public static class CreateHostelRequest {
        private String buildingName;
        private String roomNumber;
        private Integer bedCount;
        private BigDecimal monthlyFee;
    }
}
