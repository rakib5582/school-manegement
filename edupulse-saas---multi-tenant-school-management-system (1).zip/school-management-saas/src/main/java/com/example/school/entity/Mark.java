package com.example.school.entity;

import com.example.school.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "marks")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Mark extends TenantAwareEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "exam_id", nullable = false)
    private Exam exam;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "student_id", nullable = false)
    private Student student;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subject_id", nullable = false)
    private Subject subject;

    @Column(name = "obtained_marks", nullable = false)
    private BigDecimal obtainedMarks;

    @Column(name = "total_marks", nullable = false)
    @Builder.Default
    private BigDecimal totalMarks = BigDecimal.valueOf(100.00);

    @Column(length = 10)
    private String grade;

    @Column(length = 255)
    private String remarks;
}
