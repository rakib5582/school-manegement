package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.Notice;
import com.example.school.service.NoticeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/notices")
@RequiredArgsConstructor
@Tag(name = "Notices", description = "Endpoints for circular announcements and school bulletins")
public class NoticeController {

    private final NoticeService noticeService;

    @GetMapping
    @Operation(summary = "Get list of notices filtered by audience")
    public ResponseEntity<ApiResponse<List<Notice>>> getNotices(@RequestParam(required = false) String audience) {
        return ResponseEntity.ok(ApiResponse.ok(noticeService.getNotices(audience)));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Publish new circular announcement")
    public ResponseEntity<ApiResponse<Notice>> createNotice(
            @RequestParam String title,
            @RequestParam String content,
            @RequestParam(required = false, defaultValue = "ALL") String audience) {
        Notice n = noticeService.createNotice(title, content, audience);
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Notice published successfully", n));
    }
}
