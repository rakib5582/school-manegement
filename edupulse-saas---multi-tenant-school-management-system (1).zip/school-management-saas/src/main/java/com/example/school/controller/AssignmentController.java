package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.service.AssignmentService;
import com.example.school.service.AssignmentService.AssignmentResponse;
import com.example.school.service.AssignmentService.CreateAssignmentRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/assignments")
@RequiredArgsConstructor
@Tag(name = "Assignments", description = "Endpoints for classroom homework, instructions, and deadlines")
public class AssignmentController {

    private final AssignmentService assignmentService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get list of assignments filtered by class")
    public ResponseEntity<ApiResponse<List<AssignmentResponse>>> getAssignments(@RequestParam(required = false) UUID classId) {
        List<AssignmentResponse> assignments = assignmentService.getAssignments(classId);
        return ResponseEntity.ok(ApiResponse.ok(assignments));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Create and publish new homework assignment")
    public ResponseEntity<ApiResponse<AssignmentResponse>> createAssignment(@RequestBody CreateAssignmentRequest request) {
        AssignmentResponse response = assignmentService.createAssignment(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Assignment published successfully", response));
    }
}
