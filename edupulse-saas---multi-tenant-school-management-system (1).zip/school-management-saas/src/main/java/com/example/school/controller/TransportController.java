package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.TransportRoute;
import com.example.school.service.TransportService;
import com.example.school.service.TransportService.CreateRouteRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/transport")
@RequiredArgsConstructor
@Tag(name = "Transport", description = "Endpoints for school bus routes, verified drivers, and transport fees")
public class TransportController {

    private final TransportService transportService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get list of transport routes")
    public ResponseEntity<ApiResponse<List<TransportRoute>>> getRoutes() {
        List<TransportRoute> routes = transportService.getRoutes();
        return ResponseEntity.ok(ApiResponse.ok(routes));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Register new school bus route and driver")
    public ResponseEntity<ApiResponse<TransportRoute>> addRoute(@RequestBody CreateRouteRequest request) {
        TransportRoute route = transportService.addRoute(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Transport route registered successfully", route));
    }
}
