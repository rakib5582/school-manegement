package com.example.school.entity;

import com.example.school.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "transport_routes")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransportRoute extends TenantAwareEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "route_name", nullable = false, length = 150)
    private String routeName;

    @Column(name = "vehicle_number", nullable = false, length = 50)
    private String vehicleNumber;

    @Column(name = "driver_name", nullable = false, length = 100)
    private String driverName;

    @Column(name = "driver_phone", length = 50)
    private String driverPhone;

    @Column(name = "fare_monthly", precision = 10, scale = 2)
    @Builder.Default
    private BigDecimal fareMonthly = BigDecimal.ZERO;
}
