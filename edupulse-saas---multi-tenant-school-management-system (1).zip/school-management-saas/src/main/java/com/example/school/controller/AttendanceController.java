package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.dto.AttendanceDTOs.*;
import com.example.school.entity.Attendance;
import com.example.school.service.AttendanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/attendance")
@RequiredArgsConstructor
@Tag(name = "Attendance", description = "Endpoints for daily attendance registers, bulk marking, and analytics")
public class AttendanceController {

    private final AttendanceService attendanceService;

    @PostMapping("/bulk")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Submit bulk daily attendance for a class & section")
    public ResponseEntity<ApiResponse<Void>> recordBulkAttendance(@Valid @RequestBody BulkAttendanceRequest request) {
        attendanceService.recordBulkAttendance(request);
        return ResponseEntity.ok(ApiResponse.ok("Attendance recorded successfully", null));
    }

    @GetMapping("/summary")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Get daily attendance summary & percentage for the school")
    public ResponseEntity<ApiResponse<AttendanceSummaryResponse>> getDailySummary(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        AttendanceSummaryResponse response = attendanceService.getDailySummary(date);
        return ResponseEntity.ok(ApiResponse.ok(response));
    }

    @GetMapping("/student/{studentId}")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get attendance history for a student")
    public ResponseEntity<ApiResponse<List<Attendance>>> getStudentAttendance(@PathVariable UUID studentId) {
        List<Attendance> list = attendanceService.getStudentAttendanceHistory(studentId);
        return ResponseEntity.ok(ApiResponse.ok(list));
    }
}
