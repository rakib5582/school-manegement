package com.example.school.service;

import com.example.school.entity.Attendance;
import com.example.school.entity.FeeInvoice;
import com.example.school.repository.AttendanceRepository;
import com.example.school.repository.FeeInvoiceRepository;
import com.example.school.repository.StudentRepository;
import com.example.school.tenant.TenantContext;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ReportService {

    private final StudentRepository studentRepository;
    private final AttendanceRepository attendanceRepository;
    private final FeeInvoiceRepository feeInvoiceRepository;

    @Transactional(readOnly = true)
    public AttendanceReportResponse getAttendanceReport(LocalDate date) {
        UUID tenantId = TenantContext.getTenantId();
        LocalDate targetDate = date != null ? date : LocalDate.now();

        long totalStudents = studentRepository.countByTenantId(tenantId);
        List<Attendance> records = attendanceRepository.findByTenantIdAndAttendanceDate(tenantId, targetDate);

        long present = records.stream().filter(r -> "PRESENT".equalsIgnoreCase(r.getStatus())).count();
        long absent = records.stream().filter(r -> "ABSENT".equalsIgnoreCase(r.getStatus())).count();
        long late = records.stream().filter(r -> "LATE".equalsIgnoreCase(r.getStatus())).count();

        double percentage = totalStudents > 0 ? ((double) present / totalStudents) * 100.0 : 100.0;

        return AttendanceReportResponse.builder()
                .reportDate(targetDate)
                .totalStudents(totalStudents)
                .presentCount(present)
                .absentCount(absent)
                .lateCount(late)
                .attendancePercentage(Math.round(percentage * 10.0) / 10.0)
                .build();
    }

    @Transactional(readOnly = true)
    public FinanceReportResponse getFinanceReport() {
        UUID tenantId = TenantContext.getTenantId();
        List<FeeInvoice> invoices = feeInvoiceRepository.findByTenantId(tenantId);

        BigDecimal totalInvoiced = invoices.stream()
                .map(FeeInvoice::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalPaid = invoices.stream()
                .map(FeeInvoice::getPaidAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal totalDue = totalInvoiced.subtract(totalPaid);

        double collectionRate = totalInvoiced.compareTo(BigDecimal.ZERO) > 0
                ? totalPaid.divide(totalInvoiced, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100)).doubleValue()
                : 100.0;

        return FinanceReportResponse.builder()
                .totalInvoiced(totalInvoiced)
                .totalPaid(totalPaid)
                .totalDue(totalDue)
                .collectionRate(Math.round(collectionRate * 10.0) / 10.0)
                .totalInvoices(invoices.size())
                .build();
    }

    @Data
    @Builder
    public static class AttendanceReportResponse {
        private LocalDate reportDate;
        private long totalStudents;
        private long presentCount;
        private long absentCount;
        private long lateCount;
        private double attendancePercentage;
    }

    @Data
    @Builder
    public static class FinanceReportResponse {
        private BigDecimal totalInvoiced;
        private BigDecimal totalPaid;
        private BigDecimal totalDue;
        private double collectionRate;
        private int totalInvoices;
    }
}
