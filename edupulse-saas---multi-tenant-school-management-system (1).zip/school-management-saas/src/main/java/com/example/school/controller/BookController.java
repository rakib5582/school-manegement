package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.Book;
import com.example.school.service.BookService;
import com.example.school.service.BookService.CreateBookRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/books")
@RequiredArgsConstructor
@Tag(name = "Library", description = "Endpoints for library book catalog, inventory copies, and loan circulation")
public class BookController {

    private final BookService bookService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Search and list library catalog books")
    public ResponseEntity<ApiResponse<List<Book>>> getBooks(@RequestParam(required = false) String query) {
        List<Book> books = bookService.getBooks(query);
        return ResponseEntity.ok(ApiResponse.ok(books));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Catalog new library volume")
    public ResponseEntity<ApiResponse<Book>> addBook(@RequestBody CreateBookRequest request) {
        Book book = bookService.addBook(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Book cataloged successfully", book));
    }

    @PostMapping("/{id}/issue")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Issue a book copy to student")
    public ResponseEntity<ApiResponse<Book>> issueBook(@PathVariable UUID id) {
        Book book = bookService.issueBook(id);
        return ResponseEntity.ok(ApiResponse.ok("Book issued successfully", book));
    }

    @PostMapping("/{id}/return")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Return a book copy to shelf inventory")
    public ResponseEntity<ApiResponse<Book>> returnBook(@PathVariable UUID id) {
        Book book = bookService.returnBook(id);
        return ResponseEntity.ok(ApiResponse.ok("Book returned successfully", book));
    }
}
