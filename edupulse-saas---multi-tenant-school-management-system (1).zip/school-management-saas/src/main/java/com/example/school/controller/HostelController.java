package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.entity.HostelRoom;
import com.example.school.service.HostelService;
import com.example.school.service.HostelService.CreateHostelRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/hostels")
@RequiredArgsConstructor
@Tag(name = "Hostel", description = "Endpoints for boarding dormitory rooms, bed capacity, and monthly accommodation fees")
public class HostelController {

    private final HostelService hostelService;

    @GetMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Get list of hostel rooms")
    public ResponseEntity<ApiResponse<List<HostelRoom>>> getHostels() {
        List<HostelRoom> rooms = hostelService.getHostels();
        return ResponseEntity.ok(ApiResponse.ok(rooms));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Allocate new dormitory room")
    public ResponseEntity<ApiResponse<HostelRoom>> addRoom(@RequestBody CreateHostelRequest request) {
        HostelRoom room = hostelService.addRoom(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Hostel room allocated successfully", room));
    }
}
