package com.example.school.repository;

import com.example.school.entity.Mark;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface MarkRepository extends JpaRepository<Mark, UUID> {

    @Query("SELECT m FROM Mark m WHERE m.id = :id AND m.tenantId = :tenantId")
    Optional<Mark> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Mark> findByTenantIdAndExamId(UUID tenantId, UUID examId);

    List<Mark> findByTenantIdAndExamIdAndStudentId(UUID tenantId, UUID examId, UUID studentId);

    List<Mark> findByTenantIdAndStudentId(UUID tenantId, UUID studentId);

    Optional<Mark> findByTenantIdAndExamIdAndStudentIdAndSubjectId(UUID tenantId, UUID examId, UUID studentId, UUID subjectId);
}
