package com.example.school.entity;

import com.example.school.tenant.TenantAwareEntity;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Entity
@Table(name = "teachers")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Teacher extends TenantAwareEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(name = "employee_id", nullable = false, length = 50)
    private String employeeId;

    @Column(nullable = false, length = 100)
    private String designation;

    @Column(length = 100)
    private String department;

    @Column(length = 255)
    private String qualification;

    @Column(name = "joining_date")
    private LocalDate joiningDate;

    @Column
    @Builder.Default
    private BigDecimal salary = BigDecimal.ZERO;

    @Column(length = 30)
    @Builder.Default
    private String status = "ACTIVE";
}
