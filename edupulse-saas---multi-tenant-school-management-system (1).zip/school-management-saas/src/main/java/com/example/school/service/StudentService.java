package com.example.school.service;

import com.example.school.dto.StudentDTOs.*;
import com.example.school.entity.Parent;
import com.example.school.entity.SchoolClass;
import com.example.school.entity.Section;
import com.example.school.entity.Student;
import com.example.school.entity.User;
import com.example.school.exception.ResourceNotFoundException;
import com.example.school.exception.TenantAccessDeniedException;
import com.example.school.repository.*;
import com.example.school.security.Role;
import com.example.school.tenant.TenantContext;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final UserRepository userRepository;
    private final SchoolClassRepository classRepository;
    private final SectionRepository sectionRepository;
    private final ParentRepository parentRepository;
    private final LimitEnforcementService limitEnforcementService;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    @Transactional(readOnly = true)
    public Page<StudentResponse> getStudents(UUID classId, UUID sectionId, Pageable pageable) {
        UUID tenantId = TenantContext.getTenantId();
        Page<Student> page;
        if (classId != null && sectionId != null) {
            page = studentRepository.findByTenantIdAndSchoolClassIdAndSectionId(tenantId, classId, sectionId, pageable);
        } else if (classId != null) {
            page = studentRepository.findByTenantIdAndSchoolClassId(tenantId, classId, pageable);
        } else {
            page = studentRepository.findByTenantId(tenantId, pageable);
        }
        return page.map(this::mapToResponse);
    }

    @Transactional(readOnly = true)
    public StudentResponse getStudentById(UUID id) {
        UUID currentTenantId = TenantContext.getTenantId();
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with ID: " + id));

        // CRITICAL SAAS SECURITY: Enforce tenant isolation!
        if (!student.getTenantId().equals(currentTenantId)) {
            throw new TenantAccessDeniedException("Cross-tenant access prohibited. Student belongs to tenant: " + student.getTenantId());
        }

        return mapToResponse(student);
    }

    @Transactional
    public StudentResponse createStudent(CreateStudentRequest request, String ipAddress) {
        UUID tenantId = TenantContext.getTenantId();

        // 1. Enforce subscription limits
        limitEnforcementService.validateStudentCreationAllowed(tenantId);

        if (studentRepository.existsByTenantIdAndAdmissionNumber(tenantId, request.getAdmissionNumber())) {
            throw new IllegalArgumentException("Admission number already exists in this school: " + request.getAdmissionNumber());
        }

        SchoolClass schoolClass = classRepository.findByIdAndTenantId(request.getClassId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Class not found for this school: " + request.getClassId()));

        Section section = sectionRepository.findByIdAndTenantId(request.getSectionId(), tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Section not found for this school: " + request.getSectionId()));

        Parent parent = null;
        if (request.getParentId() != null) {
            parent = parentRepository.findByIdAndTenantId(request.getParentId(), tenantId).orElse(null);
        }

        // Create User account for student
        String username = request.getAdmissionNumber().toLowerCase().replace("-", "_");
        User user = User.builder()
                .tenantId(tenantId)
                .username(username)
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode("Student@2026!"))
                .role(Role.STUDENT)
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .phone(request.getPhone())
                .active(true)
                .build();
        user = userRepository.save(user);

        // Create Student entity
        Student student = Student.builder()
                .user(user)
                .parent(parent)
                .admissionNumber(request.getAdmissionNumber())
                .rollNumber(request.getRollNumber())
                .schoolClass(schoolClass)
                .section(section)
                .gender(request.getGender())
                .dateOfBirth(request.getDateOfBirth())
                .bloodGroup(request.getBloodGroup())
                .emergencyContact(request.getEmergencyContact())
                .status("ACTIVE")
                .build();
        student.setTenantId(tenantId);
        student = studentRepository.save(student);

        auditLogService.logAction(user.getId(), user.getEmail(), "CREATE_STUDENT", "Student",
                student.getId().toString(), ipAddress, "Enrolled student " + user.getFullName() + " with admission " + student.getAdmissionNumber());

        return mapToResponse(student);
    }

    private StudentResponse mapToResponse(Student student) {
        return StudentResponse.builder()
                .id(student.getId())
                .tenantId(student.getTenantId())
                .userId(student.getUser().getId())
                .admissionNumber(student.getAdmissionNumber())
                .rollNumber(student.getRollNumber())
                .fullName(student.getUser().getFullName())
                .email(student.getUser().getEmail())
                .phone(student.getUser().getPhone())
                .className(student.getSchoolClass().getName())
                .sectionName(student.getSection().getName())
                .gender(student.getGender())
                .dateOfBirth(student.getDateOfBirth())
                .bloodGroup(student.getBloodGroup())
                .status(student.getStatus())
                .avatarUrl(student.getUser().getAvatarUrl())
                .build();
    }
}
