package com.example.school.repository;

import com.example.school.entity.Book;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface BookRepository extends JpaRepository<Book, UUID> {

    @Query("SELECT b FROM Book b WHERE b.id = :id AND b.tenantId = :tenantId")
    Optional<Book> findByIdAndTenantId(@Param("id") UUID id, @Param("tenantId") UUID tenantId);

    List<Book> findByTenantId(UUID tenantId);

    Page<Book> findByTenantId(UUID tenantId, Pageable pageable);

    @Query("SELECT b FROM Book b WHERE b.tenantId = :tenantId AND (LOWER(b.title) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(b.author) LIKE LOWER(CONCAT('%', :query, '%')) OR LOWER(b.isbn) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<Book> searchBooks(@Param("tenantId") UUID tenantId, @Param("query") String query);
}
