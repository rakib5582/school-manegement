package com.example.school.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

public class TenantDTOs {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TenantDetailResponse {
        private UUID id;
        private String code;
        private String name;
        private String subdomain;
        private String contactEmail;
        private String contactPhone;
        private String address;
        private String status;
        private String planCode;
        private String planName;
        private int maxStudents;
        private int maxTeachers;
        private long currentStudents;
        private long currentTeachers;
        private String primaryColor;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SuperAdminDashboardStats {
        private long totalSchools;
        private long activeSchools;
        private long suspendedSchools;
        private long totalUsers;
        private long totalStudents;
        private long totalTeachers;
        private BigDecimal monthlyRevenueEstimate;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SchoolAdminDashboardStats {
        private String schoolName;
        private String schoolCode;
        private long totalStudents;
        private long totalTeachers;
        private long totalClasses;
        private long totalParents;
        private double todayAttendanceRate;
        private BigDecimal totalFeesCollected;
        private BigDecimal totalFeesDue;
        private long upcomingExamsCount;
        private long pendingInvoicesCount;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UpdateTenantSettingsRequest {
        private String name;
        private String contactEmail;
        private String contactPhone;
        private String address;
        private String primaryColor;
        private String secondaryColor;
        private String timezone;
        private String currency;
        private String academicYearName;
    }
}
