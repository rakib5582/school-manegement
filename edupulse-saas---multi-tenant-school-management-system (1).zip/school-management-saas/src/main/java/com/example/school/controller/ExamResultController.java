package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.dto.ExamDTOs.*;
import com.example.school.service.ExamResultService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Examinations & Transcripts", description = "Endpoints for scheduling exams, entering marks, and generating official transcripts")
public class ExamResultController {

    private final ExamResultService examResultService;

    @PostMapping("/exams/marks")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Submit subject marks for students in an examination")
    public ResponseEntity<ApiResponse<Void>> submitMarks(@Valid @RequestBody SubmitSubjectMarksRequest request) {
        examResultService.submitSubjectMarks(request);
        return ResponseEntity.ok(ApiResponse.ok("Marks saved successfully", null));
    }

    @GetMapping("/results/transcript")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT')")
    @Operation(summary = "Generate official academic transcript / report card with grades and GPA")
    public ResponseEntity<ApiResponse<StudentTranscriptResponse>> getTranscript(
            @RequestParam UUID examId,
            @RequestParam UUID studentId) {
        StudentTranscriptResponse response = examResultService.generateTranscript(examId, studentId);
        return ResponseEntity.ok(ApiResponse.ok(response));
    }
}
