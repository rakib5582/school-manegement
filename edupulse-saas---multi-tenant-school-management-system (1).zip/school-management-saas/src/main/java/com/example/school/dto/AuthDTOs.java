package com.example.school.dto;

import com.example.school.security.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

public class AuthDTOs {

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LoginRequest {
        @NotBlank(message = "Email or username is required")
        private String emailOrUsername;

        @NotBlank(message = "Password is required")
        private String password;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class LoginResponse {
        private String token;
        private String tokenType;
        private UUID userId;
        private UUID tenantId;
        private String tenantCode;
        private String schoolName;
        private String username;
        private String email;
        private String fullName;
        private Role role;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RegisterSchoolRequest {
        @NotBlank(message = "School code is required")
        private String schoolCode;

        @NotBlank(message = "School name is required")
        private String schoolName;

        @NotBlank(message = "Contact email is required")
        @Email(message = "Valid email is required")
        private String contactEmail;

        private String contactPhone;
        private String address;

        @NotBlank(message = "Admin username is required")
        private String adminUsername;

        @NotBlank(message = "Admin password is required")
        private String adminPassword;

        @NotBlank(message = "Admin first name is required")
        private String adminFirstName;

        @NotBlank(message = "Admin last name is required")
        private String adminLastName;

        @NotNull(message = "Subscription plan code is required")
        private String planCode; // FREE, BASIC, PREMIUM
    }
}
