package com.example.school.controller;

import com.example.school.common.ApiResponse;
import com.example.school.service.ReportService;
import com.example.school.service.ReportService.AttendanceReportResponse;
import com.example.school.service.ReportService.FinanceReportResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
@Tag(name = "Reports", description = "Endpoints for institutional audit analytics, daily attendance statistics, and fee collections")
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/attendance")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER')")
    @Operation(summary = "Get institutional daily attendance summary report")
    public ResponseEntity<ApiResponse<AttendanceReportResponse>> getAttendanceReport(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        AttendanceReportResponse report = reportService.getAttendanceReport(date);
        return ResponseEntity.ok(ApiResponse.ok(report));
    }

    @GetMapping("/finance")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN', 'SCHOOL_ADMIN')")
    @Operation(summary = "Get school revenue, collection rates, and outstanding dues report")
    public ResponseEntity<ApiResponse<FinanceReportResponse>> getFinanceReport() {
        FinanceReportResponse report = reportService.getFinanceReport();
        return ResponseEntity.ok(ApiResponse.ok(report));
    }
}
