-- V2__seed_demo_data.sql: Comprehensive Seed Data for Super Admin and Multi-Tenant Demo Schools
-- BCrypt hashed password for all demo accounts: '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6' (Value: DemoPassword@2026!)

-- 1. Subscription Plans
INSERT INTO subscription_plans (id, name, code, description, price_per_month, max_students, max_teachers, max_storage_mb, modules_enabled, is_active)
VALUES
('a0000000-0000-0000-0000-000000000001', 'Starter Trial', 'FREE', 'Free tier for small institutions up to 100 students', 0.00, 100, 10, 512, ARRAY['ACADEMIC','ATTENDANCE','FEES'], TRUE),
('a0000000-0000-0000-0000-000000000002', 'Standard Campus', 'BASIC', 'Standard school operations for up to 500 students', 49.00, 500, 35, 2048, ARRAY['ACADEMIC','ATTENDANCE','FEES','EXAMS','ROUTINE','NOTICES'], TRUE),
('a0000000-0000-0000-0000-000000000003', 'Enterprise Academy', 'PREMIUM', 'Comprehensive multi-branch operations with all modules', 149.00, 2500, 150, 10240, ARRAY['ACADEMIC','ATTENDANCE','FEES','EXAMS','ROUTINE','NOTICES','LIBRARY','TRANSPORT','HOSTEL','AUDIT'], TRUE);

-- 2. Tenants (Schools)
INSERT INTO tenants (id, code, name, subdomain, contact_email, contact_phone, address, primary_color, secondary_color, plan_id, status, subscription_expires_at)
VALUES
('11111111-1111-1111-1111-111111111111', 'GREENWOOD', 'Greenwood International Academy', 'greenwood', 'contact@greenwood.edu', '+1 (555) 234-5678', '450 University Blvd, Cambridge, MA', '#4F46E5', '#06B6D4', 'a0000000-0000-0000-0000-000000000003', 'ACTIVE', CURRENT_TIMESTAMP + INTERVAL '365 days'),
('22222222-2222-2222-2222-222222222222', 'OAKRIDGE', 'Oakridge Science & Arts School', 'oakridge', 'info@oakridge.edu', '+1 (555) 876-5432', '124 Science Park Lane, Austin, TX', '#059669', '#10B981', 'a0000000-0000-0000-0000-000000000002', 'ACTIVE', CURRENT_TIMESTAMP + INTERVAL '365 days');

-- 3. Users
-- 3.1 Super Admin (Global SaaS Controller)
INSERT INTO users (id, tenant_id, username, email, password_hash, role, first_name, last_name, phone, is_active)
VALUES
('99999999-9999-9999-9999-999999999999', NULL, 'superadmin', 'superadmin@saas-edupulse.com', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'SUPER_ADMIN', 'Platform', 'SuperAdmin', '+1 (800) 555-0199', TRUE);

-- 3.2 School 1 (Greenwood) Users
INSERT INTO users (id, tenant_id, username, email, password_hash, role, first_name, last_name, phone, is_active)
VALUES
-- School Admin
('10000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'admin_greenwood', 'admin@greenwood.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'SCHOOL_ADMIN', 'Eleanor', 'Vance', '+1 (555) 234-5601', TRUE),
-- Teacher (Ms. Sarah Jenkins)
('10000000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'teacher_sarah', 'teacher.sarah@greenwood.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'TEACHER', 'Sarah', 'Jenkins', '+1 (555) 234-5602', TRUE),
-- Teacher 2 (Mr. David Miller)
('10000000-0000-0000-0000-000000000003', '11111111-1111-1111-1111-111111111111', 'teacher_david', 'teacher.david@greenwood.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'TEACHER', 'David', 'Miller', '+1 (555) 234-5603', TRUE),
-- Parent (Robert Rivera)
('10000000-0000-0000-0000-000000000004', '11111111-1111-1111-1111-111111111111', 'parent_robert', 'parent.robert@greenwood.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'PARENT', 'Robert', 'Rivera', '+1 (555) 234-5604', TRUE),
-- Student (Alex Rivera)
('10000000-0000-0000-0000-000000000005', '11111111-1111-1111-1111-111111111111', 'student_alex', 'student.alex@greenwood.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'STUDENT', 'Alex', 'Rivera', '+1 (555) 234-5605', TRUE),
-- Student 2 (Sophia Chen)
('10000000-0000-0000-0000-000000000006', '11111111-1111-1111-1111-111111111111', 'student_sophia', 'student.sophia@greenwood.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'STUDENT', 'Sophia', 'Chen', '+1 (555) 234-5606', TRUE);

-- 3.3 School 2 (Oakridge) Users - To Test Tenant Isolation
INSERT INTO users (id, tenant_id, username, email, password_hash, role, first_name, last_name, phone, is_active)
VALUES
('20000000-0000-0000-0000-000000000001', '22222222-2222-2222-2222-222222222222', 'admin_oakridge', 'admin@oakridge.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'SCHOOL_ADMIN', 'Marcus', 'Sterling', '+1 (555) 876-5401', TRUE),
('20000000-0000-0000-0000-000000000002', '22222222-2222-2222-2222-222222222222', 'student_lucas', 'student.lucas@oakridge.edu', '$2a$10$e8Z4kM2/yYwQcflm1n0bce8G8/Kx7h9n3i2c8f0z9o7w5k1r8l8a6', 'STUDENT', 'Lucas', 'Bennett', '+1 (555) 876-5402', TRUE);

-- 4. Academic Years (Greenwood)
INSERT INTO academic_years (id, tenant_id, name, start_date, end_date, is_current)
VALUES
('10100000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-2027 Academic Year', '2026-08-01', '2027-06-30', TRUE);

-- 5. Classes & Sections (Greenwood)
INSERT INTO school_classes (id, tenant_id, name, numeric_grade)
VALUES
('10200000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Grade 10', 10),
('10200000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'Grade 9', 9);

INSERT INTO sections (id, tenant_id, class_id, name, capacity)
VALUES
('10300000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10200000-0000-0000-0000-000000000001', 'Section A', 35),
('10300000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10200000-0000-0000-0000-000000000001', 'Section B', 35);

-- 6. Subjects (Greenwood)
INSERT INTO subjects (id, tenant_id, name, code, full_marks, pass_marks)
VALUES
('10400000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Mathematics', 'MATH-101', 100, 40),
('10400000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'Physics', 'PHY-102', 100, 40),
('10400000-0000-0000-0000-000000000003', '11111111-1111-1111-1111-111111111111', 'English Literature', 'ENG-103', 100, 40),
('10400000-0000-0000-0000-000000000004', '11111111-1111-1111-1111-111111111111', 'Computer Science', 'CS-104', 100, 40);

-- 7. Teachers
INSERT INTO teachers (id, tenant_id, user_id, employee_id, designation, department, qualification, joining_date, salary)
VALUES
('10500000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10000000-0000-0000-0000-000000000002', 'T-GW-001', 'Senior Mathematics Teacher', 'Science & Mathematics', 'M.Sc in Applied Mathematics', '2021-08-15', 5200.00),
('10500000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10000000-0000-0000-0000-000000000003', 'T-GW-002', 'Physics Faculty Lead', 'Science & Mathematics', 'Ph.D in Physics', '2020-07-01', 5800.00);

-- 8. Parents
INSERT INTO parents (id, tenant_id, user_id, occupation, relationship)
VALUES
('10600000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10000000-0000-0000-0000-000000000004', 'Architect', 'Father');

-- 9. Students
INSERT INTO students (id, tenant_id, user_id, parent_id, admission_number, roll_number, class_id, section_id, gender, date_of_birth, blood_group, emergency_contact, admission_date)
VALUES
('10700000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10000000-0000-0000-0000-000000000005', '10600000-0000-0000-0000-000000000001', 'GW-2026-0101', '101', '10200000-0000-0000-0000-000000000001', '10300000-0000-0000-0000-000000000001', 'Male', '2010-04-12', 'O+', '+1 (555) 234-5604', '2024-09-01'),
('10700000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10000000-0000-0000-0000-000000000006', NULL, 'GW-2026-0102', '102', '10200000-0000-0000-0000-000000000001', '10300000-0000-0000-0000-000000000001', 'Female', '2010-08-25', 'A+', '+1 (555) 234-5699', '2024-09-01');

-- 10. Attendance Records
INSERT INTO attendances (id, tenant_id, student_id, attendance_date, status, remarks)
VALUES
('10800000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10700000-0000-0000-0000-000000000001', CURRENT_DATE, 'PRESENT', 'On time'),
('10800000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10700000-0000-0000-0000-000000000002', CURRENT_DATE, 'PRESENT', 'On time');

-- 11. Exams & Marks
INSERT INTO exams (id, tenant_id, name, academic_year_id, start_date, end_date, is_published)
VALUES
('10900000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Mid-Term Examinations 2026', '10100000-0000-0000-0000-000000000001', '2026-10-15', '2026-10-25', TRUE);

INSERT INTO marks (id, tenant_id, exam_id, student_id, subject_id, obtained_marks, total_marks, grade, remarks)
VALUES
('10910000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10900000-0000-0000-0000-000000000001', '10700000-0000-0000-0000-000000000001', '10400000-0000-0000-0000-000000000001', 94.50, 100.00, 'A+', 'Outstanding analytical problem solving'),
('10910000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10900000-0000-0000-0000-000000000001', '10700000-0000-0000-0000-000000000001', '10400000-0000-0000-0000-000000000002', 88.00, 100.00, 'A', 'Strong laboratory and theory performance'),
('10910000-0000-0000-0000-000000000003', '11111111-1111-1111-1111-111111111111', '10900000-0000-0000-0000-000000000001', '10700000-0000-0000-0000-000000000001', '10400000-0000-0000-0000-000000000004', 98.00, 100.00, 'A+', 'Perfect algorithm implementation');

-- 12. Fee Categories, Invoices & Payments
INSERT INTO fee_categories (id, tenant_id, name, description)
VALUES
('11000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Monthly Tuition Fee', 'Regular academic instruction tuition'),
('11000000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'Science & Computer Lab Fee', 'Advanced laboratory equipment and material fee');

INSERT INTO fee_invoices (id, tenant_id, student_id, invoice_number, title, total_amount, paid_amount, due_date, status)
VALUES
('11100000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10700000-0000-0000-0000-000000000001', 'INV-GW-2026-0042', 'October 2026 Tuition & Lab Fee', 450.00, 450.00, CURRENT_DATE + INTERVAL '10 days', 'PAID'),
('11100000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10700000-0000-0000-0000-000000000002', 'INV-GW-2026-0043', 'October 2026 Tuition & Lab Fee', 450.00, 0.00, CURRENT_DATE + INTERVAL '10 days', 'UNPAID');

INSERT INTO payments (id, tenant_id, invoice_id, receipt_number, amount, payment_method, transaction_id)
VALUES
('11200000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '11100000-0000-0000-0000-000000000001', 'REC-GW-90412', 450.00, 'ONLINE', 'TXN_CH_994827101');

-- 13. Routines / Timetable (Grade 10-A)
INSERT INTO routines (id, tenant_id, class_id, section_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number)
VALUES
('11300000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '10200000-0000-0000-0000-000000000001', '10300000-0000-0000-0000-000000000001', '10400000-0000-0000-0000-000000000001', '10500000-0000-0000-0000-000000000001', 'MONDAY', '08:30:00', '09:20:00', 'Room 301'),
('11300000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', '10200000-0000-0000-0000-000000000001', '10300000-0000-0000-0000-000000000001', '10400000-0000-0000-0000-000000000002', '10500000-0000-0000-0000-000000000002', 'MONDAY', '09:30:00', '10:20:00', 'Physics Lab A');

-- 14. Notices
INSERT INTO notices (id, tenant_id, title, content, target_audience, published_date)
VALUES
('11400000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Annual Science Exhibition 2026', 'All grade 9 and 10 students are requested to finalize project proposals by October 20th.', 'ALL', CURRENT_DATE),
('11400000-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'Quarterly Parent-Teacher Conference', 'Parent teacher conference scheduled for upcoming Saturday in the Main Auditorium.', 'PARENTS', CURRENT_DATE);

-- 15. Audit Log Initial Entry
INSERT INTO audit_logs (id, tenant_id, user_email, action, entity_name, entity_id, ip_address, description)
VALUES
('11500000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'admin@greenwood.edu', 'SYSTEM_SEED', 'Tenant', '11111111-1111-1111-1111-111111111111', '127.0.0.1', 'Initial tenant demo dataset loaded successfully');
