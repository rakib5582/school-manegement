package com.example.school;

import com.example.school.entity.Student;
import com.example.school.exception.TenantAccessDeniedException;
import com.example.school.repository.StudentRepository;
import com.example.school.service.StudentService;
import com.example.school.tenant.TenantContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TenantIsolationIntegrationTest {

    @Mock
    private StudentRepository studentRepository;

    @InjectMocks
    private StudentService studentService;

    private final UUID SCHOOL_A_ID = UUID.fromString("11111111-1111-1111-1111-111111111111");
    private final UUID SCHOOL_B_ID = UUID.fromString("22222222-2222-2222-2222-222222222222");
    private final UUID STUDENT_OF_SCHOOL_B = UUID.fromString("20700000-0000-0000-0000-000000000001");

    @BeforeEach
    void setUp() {
        // Authenticated user belongs to School A
        TenantContext.setTenantId(SCHOOL_A_ID);
    }

    @AfterEach
    void tearDown() {
        TenantContext.clear();
    }

    @Test
    @DisplayName("CRITICAL: School A authenticated user must be BLOCKED when attempting to access School B student")
    void testCrossTenantAccessIsForbidden() {
        // Student record in database belongs to School B
        Student schoolBStudent = Student.builder()
                .id(STUDENT_OF_SCHOOL_B)
                .admissionNumber("OAK-2026-99")
                .build();
        schoolBStudent.setTenantId(SCHOOL_B_ID);

        when(studentRepository.findById(STUDENT_OF_SCHOOL_B)).thenReturn(Optional.of(schoolBStudent));

        // Attempt by School A user to access School B student must throw TenantAccessDeniedException
        TenantAccessDeniedException exception = assertThrows(
                TenantAccessDeniedException.class,
                () -> studentService.getStudentById(STUDENT_OF_SCHOOL_B)
        );

        assertTrue(exception.getMessage().contains("Cross-tenant access prohibited"));
    }
}
