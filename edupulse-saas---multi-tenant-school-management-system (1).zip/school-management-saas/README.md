# EduPulse SaaS - Enterprise Multi-Tenant School Management Platform

EduPulse is an enterprise-grade, production-oriented Multi-Tenant Software-as-a-Service (SaaS) platform built with **Java 21 LTS**, **Spring Boot 3.2.4**, **Spring Security**, **Hibernate / Spring Data JPA**, and **PostgreSQL**.

The platform is designed with an API-first architecture, serving both the web application and prepared for dedicated Android/iOS mobile application clients.

---

## 1. System Architecture & Tenant Isolation

### Multi-Tenancy Design
- **Single Database, Shared Schema with Discriminator (`tenant_id`)**: Every tenant-owned record is strictly bound to its `tenant_id`.
- **ThreadLocal Tenant Context**: `TenantContext` provides thread-isolated tenant resolution populated via `TenantFilter` from authenticated JWT claims.
- **Client Header Spoofing Prevention**: Raw `X-Tenant-ID` headers are ignored for standard users; the server-side JWT security principal is the sole authoritative source of truth.
- **Automated Entity Auditing**: `TenantAwareEntity` automatically assigns `tenant_id`, `created_at`, `updated_at`, `created_by`, and `updated_by`.

### Role-Based Access Control (RBAC)
1. **`SUPER_ADMIN`**: Global SaaS control (schools, plans, billing, audit logs, system config).
2. **`SCHOOL_ADMIN`**: School-level tenant control (students, staff, academics, fees, exams).
3. **`TEACHER`**: Classroom registers, attendance marking, mark submission, homework.
4. **`STUDENT`**: Self-service student portal, ID card, routine, transcript, invoice receipts.
5. **`PARENT`**: Multi-child view, attendance tracking, fee payment, report cards.

---

## 2. Technology Stack

- **Runtime**: Java 21 LTS
- **Framework**: Spring Boot 3.2.4 (Spring Web, Spring Security, Spring Data JPA)
- **Database**: PostgreSQL 16
- **Migrations**: Flyway (`V1__init_schema.sql`, `V2__seed_demo_data.sql`)
- **Security**: JWT (io.jsonwebtoken 0.12.5), BCrypt Password Hashing, Stateless Session
- **API Documentation**: SpringDoc OpenAPI 3.0 / Swagger UI (`/swagger-ui.html`)
- **Containerization**: Docker & Docker Compose

---

## 3. Demo Credentials

| Role | Email | Password | Tenant / Scope |
| :--- | :--- | :--- | :--- |
| **Super Admin** | `superadmin@saas-edupulse.com` | `DemoPassword@2026!` | SaaS Platform Global |
| **School Admin** | `admin@greenwood.edu` | `DemoPassword@2026!` | Greenwood International Academy |
| **Teacher** | `teacher.sarah@greenwood.edu` | `DemoPassword@2026!` | Greenwood International Academy |
| **Student** | `student.alex@greenwood.edu` | `DemoPassword@2026!` | Greenwood International Academy |
| **Parent** | `parent.robert@greenwood.edu` | `DemoPassword@2026!` | Greenwood International Academy |
| **Cross-School Admin** | `admin@oakridge.edu` | `DemoPassword@2026!` | Oakridge Science & Arts School |

---

## 4. Quick Start & Docker Execution

### Step 1: Start PostgreSQL Database & Application
```bash
docker-compose up -d
```

### Step 2: Running with Maven directly
```bash
mvn clean package
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

### Step 3: Run Automated Tests
```bash
mvn test
```

---

## 5. REST API & Mobile Integration Guide

All endpoints are versioned under `/api/v1/*` and require standard HTTP Bearer token headers:
`Authorization: Bearer <jwt_token>`

- `POST /api/v1/auth/login`: Authenticate and obtain JWT token with embedded claims.
- `GET /api/v1/super-admin/dashboard`: Global SaaS statistics (Super Admin only).
- `GET /api/v1/school-admin/dashboard`: School performance metrics (School Admin).
- `GET /api/v1/students`: Filtered student list with pagination.
- `POST /api/v1/attendance/bulk`: Record daily classroom attendance.
- `GET /api/v1/results/transcript?examId={id}&studentId={id}`: Official transcript with GPA & grades.
- `POST /api/v1/fees/payments`: Record payment and receive receipt voucher.

OpenAPI Swagger UI is accessible in dev at `http://localhost:8080/swagger-ui.html`.
