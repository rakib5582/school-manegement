import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FileText, Printer, CalendarCheck, CreditCard, Award, Download } from 'lucide-react';

export const ReportsManagement: React.FC = () => {
  const { currentTenant, getTenantStudents, getTenantTeachers, getTenantAttendance, getTenantInvoices, marks } = useApp();

  const students = getTenantStudents();
  const teachers = getTenantTeachers();
  const attendance = getTenantAttendance();
  const invoices = getTenantInvoices();

  const [reportType, setReportType] = useState<'ATTENDANCE' | 'FEES' | 'ACADEMIC'>('ATTENDANCE');

  const presentCount = attendance.filter(a => a.status === 'PRESENT').length;
  const attendancePct = attendance.length > 0 ? Math.round((presentCount / attendance.length) * 100) : 100;

  const totalInvoiced = invoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const totalPaid = invoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalDue = totalInvoiced - totalPaid;

  const handlePrintReport = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 no-print">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            Institutional Audit & Analytics Reports
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Compile formal management reports for school board, parents, and administrative compliance
          </p>
        </div>

        <button
          onClick={handlePrintReport}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Printer className="w-4 h-4" />
          <span>Print Formal Report</span>
        </button>
      </div>

      {/* Report Switcher Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg max-w-fit text-xs no-print">
        <button
          onClick={() => setReportType('ATTENDANCE')}
          className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
            reportType === 'ATTENDANCE' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600'
          }`}
        >
          Attendance Summary
        </button>
        <button
          onClick={() => setReportType('FEES')}
          className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
            reportType === 'FEES' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600'
          }`}
        >
          Financial Collections & Dues
        </button>
        <button
          onClick={() => setReportType('ACADEMIC')}
          className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
            reportType === 'ACADEMIC' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600'
          }`}
        >
          Examination Grade Distribution
        </button>
      </div>

      {/* Printable Report Document Sheet */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 md:p-8 space-y-6 text-xs text-slate-800">
        <div className="text-center border-b border-slate-900 pb-4">
          <h2 className="text-base font-bold uppercase tracking-wider text-slate-950">
            {currentTenant?.name || 'Greenwood International Academy'}
          </h2>
          <div className="text-xs text-slate-500 font-mono mt-0.5">
            REPORT TYPE: {reportType} REPORT · ACADEMIC SESSION {currentTenant?.academicYearName || '2026-2027'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            Generated on: {new Date().toLocaleDateString()} {new Date().toLocaleTimeString()}
          </div>
        </div>

        {reportType === 'ATTENDANCE' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center p-4 bg-slate-50 border border-slate-200 rounded-lg font-mono">
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Total Students</span>
                <span className="text-lg font-bold text-slate-900">{students.length}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Recorded Present</span>
                <span className="text-lg font-bold text-emerald-600">{presentCount}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Overall Attendance</span>
                <span className="text-lg font-bold text-indigo-700">{attendancePct}%</span>
              </div>
            </div>

            <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Grade & Section</th>
                  <th className="py-2.5 px-3 font-mono">Total Roster</th>
                  <th className="py-2.5 px-3 font-mono">Present</th>
                  <th className="py-2.5 px-3 font-mono">Attendance %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-2 px-3 font-mono">{new Date().toISOString().split('T')[0]}</td>
                  <td className="py-2 px-3 font-semibold">Grade 10 · Section A</td>
                  <td className="py-2 px-3 font-mono">{students.length}</td>
                  <td className="py-2 px-3 font-mono text-emerald-600 font-bold">{presentCount}</td>
                  <td className="py-2 px-3 font-mono font-bold text-indigo-700">{attendancePct}%</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {reportType === 'FEES' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4 text-center p-4 bg-slate-50 border border-slate-200 rounded-lg font-mono">
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Gross Invoiced</span>
                <span className="text-lg font-bold text-slate-900">${totalInvoiced.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Realized Collections</span>
                <span className="text-lg font-bold text-emerald-600">${totalPaid.toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase block">Outstanding Receivables</span>
                <span className="text-lg font-bold text-amber-600">${totalDue.toLocaleString()}</span>
              </div>
            </div>

            <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Invoice Number</th>
                  <th className="py-2.5 px-3">Title Description</th>
                  <th className="py-2.5 px-3 font-mono text-right">Invoiced Amount</th>
                  <th className="py-2.5 px-3 font-mono text-right">Paid Amount</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoices.map(inv => (
                  <tr key={inv.id}>
                    <td className="py-2 px-3 font-mono">{inv.invoiceNumber}</td>
                    <td className="py-2 px-3 font-semibold text-slate-900">{inv.title}</td>
                    <td className="py-2 px-3 font-mono text-right text-slate-900 font-bold">${inv.totalAmount}</td>
                    <td className="py-2 px-3 font-mono text-right text-emerald-600 font-bold">${inv.paidAmount}</td>
                    <td className="py-2 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${inv.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {reportType === 'ACADEMIC' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
              <h3 className="font-semibold text-slate-900 mb-1">Mid-Term Examination Grade Distribution</h3>
              <p className="text-slate-500 text-xs">Evaluated across all science and general theory subjects</p>
            </div>

            <table className="w-full text-left border border-slate-200 rounded-lg overflow-hidden">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Grade Band</th>
                  <th className="py-2.5 px-3">Percentage Range</th>
                  <th className="py-2.5 px-3">GPA Equivalent</th>
                  <th className="py-2.5 px-3 font-mono text-right">Students Achieved</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-2 px-3 font-bold text-emerald-700">A+</td>
                  <td className="py-2 px-3">90% - 100%</td>
                  <td className="py-2 px-3 font-mono">4.00</td>
                  <td className="py-2 px-3 font-mono text-right font-bold text-slate-900">2 Students (100%)</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-bold text-indigo-700">A</td>
                  <td className="py-2 px-3">80% - 89%</td>
                  <td className="py-2 px-3 font-mono">3.70</td>
                  <td className="py-2 px-3 font-mono text-right font-bold text-slate-900">0 Students</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-bold text-rose-700">F (Fail)</td>
                  <td className="py-2 px-3">Below 40%</td>
                  <td className="py-2 px-3 font-mono">0.00</td>
                  <td className="py-2 px-3 font-mono text-right font-bold text-slate-900">0 Students</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        <div className="pt-8 border-t border-slate-200 flex justify-between items-end text-xs text-slate-500">
          <div>Report generated automatically by EduPulse SaaS Multi-Tenant Engine</div>
          <div className="text-right font-mono">AUTHORIZED SEAL</div>
        </div>
      </div>
    </div>
  );
};
