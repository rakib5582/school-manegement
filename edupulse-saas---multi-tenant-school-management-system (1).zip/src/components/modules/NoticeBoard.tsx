import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, Plus, Users, Calendar, CheckCircle2 } from 'lucide-react';

export const NoticeBoard: React.FC = () => {
  const { getTenantNotices, createNotice } = useApp();
  const [activeAudience, setActiveAudience] = useState<'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS'>('ALL');
  const [modalOpen, setModalOpen] = useState(false);

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [audience, setAudience] = useState<'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS'>('ALL');
  const [successToast, setSuccessToast] = useState(false);

  const notices = getTenantNotices(activeAudience);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !content) return;

    await createNotice(title, content, audience);
    setTitle('');
    setContent('');
    setModalOpen(false);
    setSuccessToast(true);
    setTimeout(() => setSuccessToast(false), 3500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Bell className="w-5 h-5 text-indigo-600" />
            Notices & Circular Announcements
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Publish broadcast bulletins targeted to faculty, students, or parents
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Publish Circular</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Notice published and dispatched across targeted school channels.</span>
        </div>
      )}

      {/* Audience Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg max-w-fit text-xs">
        {(['ALL', 'TEACHERS', 'STUDENTS', 'PARENTS'] as const).map(aud => (
          <button
            key={aud}
            onClick={() => setActiveAudience(aud)}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
              activeAudience === aud ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {aud === 'ALL' ? 'All Audiences' : aud.charAt(0) + aud.slice(1).toLowerCase()}
          </button>
        ))}
      </div>

      {/* Notices Feed */}
      <div className="grid md:grid-cols-2 gap-4">
        {notices.map(notice => (
          <div key={notice.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span className="font-semibold text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                  Target: {notice.targetAudience}
                </span>
                <span className="font-mono text-[11px]">{notice.publishedDate}</span>
              </div>
              <h2 className="font-bold text-sm text-slate-900">{notice.title}</h2>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed whitespace-pre-line">{notice.content}</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                Valid through academic semester
              </span>
              <span className="text-emerald-600 font-semibold">Active Circular</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Publish Notice */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Publish New Notice</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleCreate} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Winter Holiday Schedule Announcement"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Target Audience</label>
                <select
                  value={audience}
                  onChange={e => setAudience(e.target.value as any)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                >
                  <option value="ALL">All School Community (Everyone)</option>
                  <option value="TEACHERS">Faculty / Teachers Only</option>
                  <option value="STUDENTS">Students Only</option>
                  <option value="PARENTS">Parents Only</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Notice Body / Circular Text *</label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  placeholder="Enter official circular details..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Publish Notice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
