import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Teacher } from '../../types';
import { Users, Plus, Search, Filter, Mail, Phone, Award, DollarSign, CheckCircle2, AlertCircle } from 'lucide-react';

export const TeacherManagement: React.FC = () => {
  const { currentTenant, getTenantTeachers, addTeacher, plans } = useApp();
  const teachers = getTenantTeachers();
  const activePlan = plans.find(p => p.id === currentTenant?.planId);

  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [designation, setDesignation] = useState('');
  const [department, setDepartment] = useState('Science & Mathematics');
  const [qualification, setQualification] = useState('');
  const [salary, setSalary] = useState(5000);

  const departments = ['ALL', 'Science & Mathematics', 'Humanities & Languages', 'Computer Science & ICT', 'Physical Education'];

  const filteredTeachers = teachers.filter(t => {
    const matchesSearch =
      t.employeeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.designation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.department.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDept = departmentFilter === 'ALL' || t.department === departmentFilter;
    return matchesSearch && matchesDept;
  });

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);

    try {
      const result = await addTeacher({
        firstName,
        lastName,
        email,
        employeeId,
        designation,
        department,
        qualification: qualification || 'M.Sc / M.Ed',
        joiningDate: new Date().toISOString().split('T')[0],
        salary: Number(salary),
        status: 'ACTIVE',
      });

      if (!result.success) {
        setErrorMsg(result.error || 'Failed to add teacher');
        return;
      }

      setFirstName('');
      setLastName('');
      setEmail('');
      setEmployeeId('');
      setDesignation('');
      setModalOpen(false);
      setSuccessToast(true);
      setTimeout(() => setSuccessToast(false), 3500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error creating teacher');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600" />
            Faculty & Staff Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage academic instructors, departments, designations, and salary structures
          </p>
        </div>

        <button
          onClick={() => {
            setErrorMsg(null);
            setModalOpen(true);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Faculty Member</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Faculty member successfully appointed and assigned to tenant roster!</span>
        </div>
      )}

      {/* Plan capacity indicator */}
      <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-900">Faculty Quota:</span>
          <span>
            {teachers.length} of {activePlan?.maxTeachers || 10} teachers allocated on the{' '}
            <strong className="text-indigo-600">{activePlan?.name}</strong> plan
          </span>
        </div>
        <div className="w-32 bg-slate-200 rounded-full h-2 overflow-hidden">
          <div
            className="bg-emerald-600 h-full rounded-full"
            style={{ width: `${Math.min(100, (teachers.length / (activePlan?.maxTeachers || 10)) * 100)}%` }}
          />
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by faculty ID, designation, or department..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-md text-xs focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 shrink-0">Department:</span>
          <select
            value={departmentFilter}
            onChange={e => setDepartmentFilter(e.target.value)}
            className="px-2.5 py-1.5 border border-slate-200 rounded-md text-xs bg-white text-slate-700 focus:outline-hidden"
          >
            {departments.map(d => (
              <option key={d} value={d}>{d === 'ALL' ? 'All Departments' : d}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Teachers Directory Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTeachers.map(teacher => {
          const isLead = teacher.employeeId === 'T-GW-001';
          const name = isLead ? 'Ms. Sarah Jenkins' : teacher.employeeId === 'T-GW-002' ? 'Dr. David Miller' : 'Faculty Member';
          const email = isLead ? 'teacher.sarah@greenwood.edu' : teacher.employeeId === 'T-GW-002' ? 'teacher.david@greenwood.edu' : 'faculty@greenwood.edu';

          return (
            <div key={teacher.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-colors">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <span className="font-mono text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                      {teacher.employeeId}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900 mt-1.5">{name}</h3>
                    <p className="text-xs text-slate-500">{teacher.designation}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {teacher.status}
                  </span>
                </div>

                <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center gap-2 text-[11px]">
                    <Award className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{teacher.qualification}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px]">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate font-mono">{email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px]">
                    <DollarSign className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono font-semibold text-slate-800">${teacher.salary?.toLocaleString()}/month</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>Joined {teacher.joiningDate}</span>
                <span className="font-medium text-slate-700">{teacher.department}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Teacher Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Add Faculty Member</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>

            {errorMsg && (
              <div className="m-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                    placeholder="Marcus"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={e => setLastName(e.target.value)}
                    placeholder="Aurelius"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="m.aurelius@greenwood.edu"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Employee ID *</label>
                  <input
                    type="text"
                    required
                    value={employeeId}
                    onChange={e => setEmployeeId(e.target.value.toUpperCase())}
                    placeholder="T-GW-003"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Designation *</label>
                  <input
                    type="text"
                    required
                    value={designation}
                    onChange={e => setDesignation(e.target.value)}
                    placeholder="Biology Teacher"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Department</label>
                  <select
                    value={department}
                    onChange={e => setDepartment(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    <option value="Science & Mathematics">Science & Mathematics</option>
                    <option value="Humanities & Languages">Humanities & Languages</option>
                    <option value="Computer Science & ICT">Computer Science & ICT</option>
                    <option value="Physical Education">Physical Education</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Qualification</label>
                  <input
                    type="text"
                    value={qualification}
                    onChange={e => setQualification(e.target.value)}
                    placeholder="M.Sc in Biology"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Monthly Salary ($)</label>
                  <input
                    type="number"
                    min="1"
                    value={salary}
                    onChange={e => setSalary(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Appoint Faculty
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
