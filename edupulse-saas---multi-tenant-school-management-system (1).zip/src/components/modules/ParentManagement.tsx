import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Users, Plus, Search, Mail, Phone, GraduationCap, CheckCircle2 } from 'lucide-react';

export const ParentManagement: React.FC = () => {
  const { currentTenant, getTenantStudents, getTenantParents, users, addParent } = useApp();
  const students = getTenantStudents();
  const tenantParents = getTenantParents();

  const [searchQuery, setSearchQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  // Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [occupation, setOccupation] = useState('');
  const [relationship, setRelationship] = useState('Father');
  const [selectedStudentId, setSelectedStudentId] = useState(students[0]?.id || '');

  const getStudentFullName = (studentId: string) => {
    const s = students.find(item => item.id === studentId);
    if (!s) return 'Student Dependent';
    const u = users.find(user => user.id === s.userId);
    return u ? `${u.firstName} ${u.lastName}` : `Student #${s.rollNumber}`;
  };

  const filteredParents = tenantParents.filter(parent => {
    const user = users.find(u => u.id === parent.userId);
    const name = user ? `${user.firstName} ${user.lastName}`.toLowerCase() : '';
    const mail = user ? user.email.toLowerCase() : '';
    const q = searchQuery.toLowerCase();
    return name.includes(q) || mail.includes(q) || parent.occupation.toLowerCase().includes(q);
  });

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !email) return;

    try {
      await addParent({
        firstName,
        lastName,
        email,
        phone: phone || '+1 (555) 000-0000',
        occupation: occupation || 'Professional',
        relationship,
        studentId: selectedStudentId || undefined,
      });

      setFirstName('');
      setLastName('');
      setEmail('');
      setPhone('');
      setOccupation('');
      setModalOpen(false);
      setSuccessToast(true);
      setTimeout(() => setSuccessToast(false), 3500);
    } catch (err: any) {
      console.error('Failed to register parent:', err.message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600" />
            Parents & Guardians Directory
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage guardian relations, emergency contacts, and linked student dependents ({currentTenant?.name})
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Register Guardian</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Guardian record registered and linked to student profile!</span>
        </div>
      )}

      {/* Search Input */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search guardians by name, email, or occupation..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-hidden focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Directory Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredParents.map(parent => {
          const user = users.find(u => u.id === parent.userId);
          const parentName = user ? `${user.firstName} ${user.lastName}` : 'Guardian Member';
          const linkedStudents = students.filter(s => s.parentId === parent.id);

          return (
            <div key={parent.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-colors">
              <div>
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">{parentName}</h3>
                    <p className="text-xs text-indigo-600 font-medium">{parent.relationship} · {parent.occupation}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                    Verified
                  </span>
                </div>

                <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center gap-2 text-[11px]">
                    <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate font-mono">{user?.email || 'guardian@school.edu'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px]">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono">{user?.phone || '+1 (555) 234-5604'}</span>
                  </div>
                </div>

                {/* Linked Children */}
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                    Linked Wards / Students
                  </span>
                  <div className="space-y-1">
                    {linkedStudents.length > 0 ? (
                      linkedStudents.map(s => (
                        <div key={s.id} className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 bg-slate-50 p-1.5 rounded border border-slate-100">
                          <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{getStudentFullName(s.id)} (Adm: {s.admissionNumber})</span>
                        </div>
                      ))
                    ) : (
                      <span className="text-[11px] text-slate-400 italic">No student enrolled as primary ward</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Register Guardian Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Register Guardian</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={e => setFirstName(e.target.value)}
                    placeholder="e.g. Maria"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={e => setLastName(e.target.value)}
                    placeholder="e.g. Rivera"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="maria.r@gmail.com"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+1 555-0199"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Occupation</label>
                  <input
                    type="text"
                    value={occupation}
                    onChange={e => setOccupation(e.target.value)}
                    placeholder="Civil Engineer"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Relationship</label>
                  <select
                    value={relationship}
                    onChange={e => setRelationship(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    <option value="Mother">Mother</option>
                    <option value="Father">Father</option>
                    <option value="Legal Guardian">Legal Guardian</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Link to Enrolled Student</label>
                <select
                  value={selectedStudentId}
                  onChange={e => setSelectedStudentId(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                >
                  <option value="">-- None / General Guardian --</option>
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {getStudentFullName(s.id)} (Adm: {s.admissionNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Save Guardian Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
