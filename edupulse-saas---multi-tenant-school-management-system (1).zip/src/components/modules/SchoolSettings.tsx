import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Sliders, Save, CheckCircle2, Building2 } from 'lucide-react';

export const SchoolSettings: React.FC = () => {
  const { currentTenant, plans, updateSchoolSettings } = useApp();
  const activePlan = plans.find(p => p.id === currentTenant?.planId);

  const [name, setName] = useState(currentTenant?.name || 'Greenwood International Academy');
  const [contactEmail, setContactEmail] = useState(currentTenant?.contactEmail || 'contact@greenwood.edu');
  const [contactPhone, setContactPhone] = useState(currentTenant?.contactPhone || '+1 (555) 234-5678');
  const [address, setAddress] = useState(currentTenant?.address || '450 University Blvd, Cambridge, MA');
  const [primaryColor, setPrimaryColor] = useState(currentTenant?.primaryColor || '#4F46E5');
  const [secondaryColor, setSecondaryColor] = useState(currentTenant?.secondaryColor || '#06B6D4');
  const [academicYear, setAcademicYear] = useState(currentTenant?.academicYearName || '2026-2027');
  const [timezone, setTimezone] = useState(currentTenant?.timezone || 'Asia/Dhaka');
  const [currency, setCurrency] = useState(currentTenant?.currency || 'USD');

  const [savedSuccess, setSavedSuccess] = useState(false);

  React.useEffect(() => {
    if (currentTenant) {
      setName(currentTenant.name);
      setContactEmail(currentTenant.contactEmail);
      setContactPhone(currentTenant.contactPhone || '');
      setAddress(currentTenant.address || '');
      setPrimaryColor(currentTenant.primaryColor || '#4F46E5');
      setSecondaryColor(currentTenant.secondaryColor || '#06B6D4');
      setAcademicYear(currentTenant.academicYearName || '2026-2027');
      setTimezone(currentTenant.timezone || 'UTC');
      setCurrency(currentTenant.currency || 'USD');
    }
  }, [currentTenant?.id]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSchoolSettings({
      name,
      contactEmail,
      contactPhone,
      address,
      primaryColor,
      secondaryColor,
      academicYearName: academicYear,
      timezone,
      currency,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-600" />
            School Tenant Profile & System Configuration
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure institutional identity, academic session dates, timezone, and portal theme
          </p>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Tenant configuration updated and cached in application context!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* General Identity */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
          <h2 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2">
            General School Identity & Metadata
          </h2>

          <div className="grid md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">School Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Tenant Code (Immutable)</label>
              <input
                type="text"
                disabled
                value={currentTenant?.code || 'GREENWOOD'}
                className="w-full px-3 py-1.5 border border-slate-200 bg-slate-50 rounded-md font-mono text-slate-500"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Contact Email</label>
              <input
                type="email"
                required
                value={contactEmail}
                onChange={e => setContactEmail(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Official Phone</label>
              <input
                type="tel"
                value={contactPhone}
                onChange={e => setContactPhone(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
              />
            </div>
          </div>

          <div className="text-xs">
            <label className="block font-medium text-slate-700 mb-1">Physical Campus Address</label>
            <input
              type="text"
              value={address}
              onChange={e => setAddress(e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
            />
          </div>
        </div>

        {/* Academic Session & Localization */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
          <h2 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2">
            Academic Session & Regional Settings
          </h2>

          <div className="grid md:grid-cols-3 gap-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Current Academic Session</label>
              <input
                type="text"
                required
                value={academicYear}
                onChange={e => setAcademicYear(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Primary Timezone</label>
              <select
                value={timezone}
                onChange={e => setTimezone(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
              >
                <option value="Asia/Dhaka">Asia/Dhaka (GMT+6)</option>
                <option value="America/New_York">America/New_York (EST)</option>
                <option value="America/Chicago">America/Chicago (CST)</option>
                <option value="Europe/London">Europe/London (GMT)</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Billing Currency</label>
              <select
                value={currency}
                onChange={e => setCurrency(e.target.value)}
                className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="BDT">BDT (৳)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Branding & Visual Identity */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-4">
          <h2 className="text-sm font-semibold text-slate-900 border-b border-slate-100 pb-2">
            Branding & Visual Palette
          </h2>

          <div className="grid md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Primary Brand Accent</label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={e => setPrimaryColor(e.target.value)}
                  className="w-10 h-9 p-0.5 border border-slate-300 rounded cursor-pointer"
                />
                <input
                  type="text"
                  value={primaryColor}
                  onChange={e => setPrimaryColor(e.target.value)}
                  className="px-3 py-1.5 border border-slate-300 rounded-md font-mono text-xs uppercase"
                />
              </div>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Secondary Accent</label>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={secondaryColor}
                  onChange={e => setSecondaryColor(e.target.value)}
                  className="w-10 h-9 p-0.5 border border-slate-300 rounded cursor-pointer"
                />
                <input
                  type="text"
                  value={secondaryColor}
                  onChange={e => setSecondaryColor(e.target.value)}
                  className="px-3 py-1.5 border border-slate-300 rounded-md font-mono text-xs uppercase"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Tenant Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
