import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RoutineSlot } from '../../types';
import { Clock, Plus, AlertCircle, CheckCircle2, User, MapPin } from 'lucide-react';

export const ClassRoutine: React.FC = () => {
  const {
    getTenantRoutines,
    getTenantClasses,
    getTenantSections,
    getTenantSubjects,
    getTenantTeachers,
    createRoutineSlot,
  } = useApp();

  const routines = getTenantRoutines();
  const classes = getTenantClasses();
  const sections = getTenantSections();
  const subjects = getTenantSubjects();
  const teachers = getTenantTeachers();

  const [modalOpen, setModalOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Form State
  const [classId, setClassId] = useState(classes[0]?.id || '');
  const [sectionId, setSectionId] = useState(sections[0]?.id || '');
  const [subjectId, setSubjectId] = useState(subjects[0]?.id || '');
  const [teacherId, setTeacherId] = useState(teachers[0]?.id || '');
  const [dayOfWeek, setDayOfWeek] = useState<'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY'>('MONDAY');
  const [startTime, setStartTime] = useState('11:30');
  const [endTime, setEndTime] = useState('12:20');
  const [roomNumber, setRoomNumber] = useState('Room 302');

  const days: ('MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY')[] = [
    'MONDAY',
    'TUESDAY',
    'WEDNESDAY',
    'THURSDAY',
    'FRIDAY',
  ];

  const handleAddSlot = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const result = await createRoutineSlot({
      classId: classId || classes[0]?.id,
      sectionId: sectionId || sections[0]?.id,
      subjectId: subjectId || subjects[0]?.id,
      teacherId: teacherId || teachers[0]?.id,
      dayOfWeek,
      startTime,
      endTime,
      roomNumber,
    });

    if (!result.success) {
      setErrorMsg(result.error || 'Conflict detected');
      return;
    }

    setModalOpen(false);
    setSuccessToast(`Timetable period successfully scheduled for ${dayOfWeek} at ${roomNumber}`);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-600" />
            Class Routine & Timetable Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Weekly period schedule with automated teacher and room collision prevention
          </p>
        </div>

        <button
          onClick={() => {
            setErrorMsg(null);
            setModalOpen(true);
          }}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Timetable Slot</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Routine Grid by Day */}
      <div className="grid md:grid-cols-5 gap-4">
        {days.map(day => {
          const dayRoutines = routines.filter(r => r.dayOfWeek === day);

          return (
            <div key={day} className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden flex flex-col">
              <div className="px-4 py-2.5 bg-slate-900 text-white text-xs font-semibold uppercase tracking-wider text-center">
                {day}
              </div>

              <div className="p-3 flex-1 space-y-2.5 bg-slate-50/50">
                {dayRoutines.length === 0 ? (
                  <div className="h-32 flex items-center justify-center text-[11px] text-slate-400 text-center">
                    No scheduled periods
                  </div>
                ) : (
                  dayRoutines.map(slot => {
                    const subject = subjects.find(s => s.id === slot.subjectId);
                    const teacher = teachers.find(t => t.id === slot.teacherId);

                    return (
                      <div
                        key={slot.id}
                        className="p-3 bg-white border border-slate-200 rounded-lg shadow-2xs text-xs space-y-1 hover:border-indigo-300 transition-colors"
                      >
                        <div className="flex items-center justify-between font-semibold text-slate-900">
                          <span className="truncate">{subject?.name || 'Class Subject'}</span>
                          <span className="text-[10px] font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                            {slot.startTime}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-500 font-mono">
                          {slot.startTime} - {slot.endTime}
                        </div>

                        <div className="pt-1.5 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-500">
                          <span className="flex items-center gap-1 truncate">
                            <User className="w-3 h-3 text-slate-400" />
                            {teacher?.designation.split(' ')[1] || 'Faculty'}
                          </span>
                          <span className="flex items-center gap-1 font-mono text-slate-700 font-semibold shrink-0">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            {slot.roomNumber}
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Add Timetable Slot */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Schedule Timetable Period</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>

            {errorMsg && (
              <div className="m-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span className="leading-relaxed">{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleAddSlot} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Class Grade</label>
                  <select
                    value={classId}
                    onChange={e => setClassId(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Section</label>
                  <select
                    value={sectionId}
                    onChange={e => setSectionId(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {sections.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Subject</label>
                  <select
                    value={subjectId}
                    onChange={e => setSubjectId(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Teacher</label>
                  <select
                    value={teacherId}
                    onChange={e => setTeacherId(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {teachers.map(t => (
                      <option key={t.id} value={t.id}>{t.employeeId} - {t.designation}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Day</label>
                  <select
                    value={dayOfWeek}
                    onChange={e => setDayOfWeek(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {days.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Start Time</label>
                  <input
                    type="time"
                    required
                    value={startTime}
                    onChange={e => setStartTime(e.target.value)}
                    className="w-full px-2 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">End Time</label>
                  <input
                    type="time"
                    required
                    value={endTime}
                    onChange={e => setEndTime(e.target.value)}
                    className="w-full px-2 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Room / Lab Number</label>
                <input
                  type="text"
                  required
                  value={roomNumber}
                  onChange={e => setRoomNumber(e.target.value)}
                  placeholder="e.g. Room 302 or Physics Lab A"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Verify & Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
