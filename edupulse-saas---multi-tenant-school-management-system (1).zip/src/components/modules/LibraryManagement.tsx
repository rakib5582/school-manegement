import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Book } from '../../types';
import { BookOpen, Plus, Search, CheckCircle2, Bookmark, ArrowRightLeft } from 'lucide-react';

export const LibraryManagement: React.FC = () => {
  const { currentTenant, getTenantBooks, addBook, issueBook, returnBook } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [isbn, setIsbn] = useState('');
  const [totalCopies, setTotalCopies] = useState(10);
  const [rackNumber, setRackNumber] = useState('RACK-SCI-01');

  const tenantBooks = getTenantBooks();

  const filteredBooks = tenantBooks.filter(b =>
    b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    b.isbn.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleIssueBook = async (bookId: string) => {
    const res = await issueBook(bookId);
    setToastMsg(res.message);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleReturnBook = async (bookId: string) => {
    const res = await returnBook(bookId);
    setToastMsg(res.message);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    await addBook({
      title,
      author,
      isbn,
      totalCopies: Number(totalCopies),
      rackNumber,
    });

    setTitle('');
    setAuthor('');
    setIsbn('');
    setModalOpen(false);
    setToastMsg(`Cataloged new book "${title}" into school library.`);
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Library Catalog & Circulation
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage reference volumes, track inventory copies, and issue student loans
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Catalog New Book</span>
        </button>
      </div>

      {toastMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs flex items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by title, author, or ISBN..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-md text-xs focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Books Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Book Title & Author</th>
              <th className="py-3 px-4">ISBN</th>
              <th className="py-3 px-4">Rack Location</th>
              <th className="py-3 px-4">Available / Total</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Circulation Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {filteredBooks.map(b => (
              <tr key={b.id} className="hover:bg-slate-50/70">
                <td className="py-3 px-4">
                  <div className="font-semibold text-slate-900">{b.title}</div>
                  <div className="text-[11px] text-slate-400">By {b.author}</div>
                </td>
                <td className="py-3 px-4 font-mono text-[11px] text-slate-600">{b.isbn}</td>
                <td className="py-3 px-4 font-mono font-bold text-indigo-700">{b.rackNumber}</td>
                <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                  <span className={b.availableCopies > 0 ? 'text-emerald-600' : 'text-rose-600'}>
                    {b.availableCopies}
                  </span>{' '}
                  / {b.totalCopies} copies
                </td>
                <td className="py-3 px-4">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold ${
                    b.availableCopies > 0 ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}>
                    {b.availableCopies > 0 ? 'AVAILABLE' : 'ALL LOANED'}
                  </span>
                </td>
                <td className="py-3 px-4 text-right space-x-2">
                  <button
                    onClick={() => handleIssueBook(b.id)}
                    disabled={b.availableCopies === 0}
                    className="px-2.5 py-1 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-md transition-colors disabled:opacity-40"
                  >
                    Issue
                  </button>
                  <button
                    onClick={() => handleReturnBook(b.id)}
                    disabled={b.availableCopies >= b.totalCopies}
                    className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors disabled:opacity-40"
                  >
                    Return
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal: Catalog Book */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Catalog New Book</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Book Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Modern Operating Systems"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Author *</label>
                <input
                  type="text"
                  required
                  value={author}
                  onChange={e => setAuthor(e.target.value)}
                  placeholder="Andrew S. Tanenbaum"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">ISBN Code *</label>
                  <input
                    type="text"
                    required
                    value={isbn}
                    onChange={e => setIsbn(e.target.value)}
                    placeholder="978-0133591620"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Rack Location</label>
                  <input
                    type="text"
                    value={rackNumber}
                    onChange={e => setRackNumber(e.target.value)}
                    placeholder="RACK-CS-02"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Total Copies</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={totalCopies}
                  onChange={e => setTotalCopies(Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Save to Catalog
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
