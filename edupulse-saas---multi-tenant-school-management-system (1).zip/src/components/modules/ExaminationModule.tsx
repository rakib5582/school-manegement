import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Exam, Student } from '../../types';
import { Award, Plus, Printer, CheckCircle2, Calendar, Edit3 } from 'lucide-react';

interface ExaminationModuleProps {
  onPrintTranscript: (student: Student, exam: Exam) => void;
}

export const ExaminationModule: React.FC<ExaminationModuleProps> = ({ onPrintTranscript }) => {
  const {
    getTenantExams,
    marks,
    users,
    getTenantStudents,
    getTenantSubjects,
    submitMarks,
    createExam,
  } = useApp();

  const exams = getTenantExams();
  const students = getTenantStudents();
  const subjects = getTenantSubjects();

  const [selectedExamId, setSelectedExamId] = useState<string>(() => exams[0]?.id || '');
  const [markEntryModalOpen, setMarkEntryModalOpen] = useState(false);
  const [scheduleModalOpen, setScheduleModalOpen] = useState(false);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>(subjects[0]?.id || '');
  const [marksState, setMarksState] = useState<Record<string, number>>({});
  const [savedSuccess, setSavedSuccess] = useState(false);

  // New Exam Form
  const [newExamName, setNewExamName] = useState('');
  const [startDate, setStartDate] = useState('2026-11-10');
  const [endDate, setEndDate] = useState('2026-11-20');

  const activeExam = exams.find(e => e.id === selectedExamId) || exams[0] || {
    id: 'placeholder',
    tenantId: '',
    name: 'Term Examination',
    startDate: '2026-10-01',
    endDate: '2026-10-15',
    published: true,
  };

  const getStudentFullName = (student: Student) => {
    const user = users.find(u => u.id === student.userId);
    return user ? `${user.firstName} ${user.lastName}` : `Student #${student.rollNumber}`;
  };

  const handleOpenMarkEntry = (subjectId: string) => {
    setSelectedSubjectId(subjectId);
    const initial: Record<string, number> = {};
    students.forEach(s => {
      const match = marks.find(m => m.examId === activeExam.id && m.subjectId === subjectId && m.studentId === s.id);
      initial[s.id] = match ? match.obtainedMarks : 85;
    });
    setMarksState(initial);
    setMarkEntryModalOpen(true);
  };

  const handleSaveMarks = async (e: React.FormEvent) => {
    e.preventDefault();
    const entries = students.map(s => ({
      studentId: s.id,
      obtainedMarks: Number(marksState[s.id] || 0),
    }));

    await submitMarks(activeExam.id, selectedSubjectId, entries);
    setSavedSuccess(true);
    setMarkEntryModalOpen(false);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  const handleScheduleExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExamName) return;

    createExam({
      name: newExamName,
      startDate,
      endDate,
    });

    setNewExamName('');
    setScheduleModalOpen(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Award className="w-5 h-5 text-indigo-600" />
            Examinations, Marks & Academic Transcripts
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure exam schedules, record subject marks, and print official report cards with GPA
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setScheduleModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule New Exam</span>
          </button>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Examination record and academic grades updated successfully!</span>
        </div>
      )}

      {/* Exam Banner Card */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <select
              value={selectedExamId}
              onChange={e => setSelectedExamId(e.target.value)}
              className="text-base font-bold text-slate-900 bg-transparent border-b border-dashed border-slate-400 focus:outline-hidden py-0.5"
            >
              {exams.map(ex => (
                <option key={ex.id} value={ex.id}>{ex.name}</option>
              ))}
            </select>
            <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded">
              {activeExam.published ? 'Published' : 'Draft'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            Duration: {activeExam.startDate} to {activeExam.endDate} · {subjects.length} Subjects Configured
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {subjects.map(sub => (
            <button
              key={sub.id}
              onClick={() => handleOpenMarkEntry(sub.id)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg text-xs transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Enter {sub.name} Marks</span>
            </button>
          ))}
        </div>
      </div>

      {/* Student Transcripts & Results Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">Student Results & Transcript Generator</h3>
            <p className="text-xs text-slate-500">Official transcripts with letter grades, GPA, and principal sign-off</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Roll</th>
                <th className="py-3 px-4">Student Name</th>
                {subjects.slice(0, 3).map(s => (
                  <th key={s.id} className="py-3 px-4">{s.name}</th>
                ))}
                <th className="py-3 px-4">Total & GPA</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Official Document</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {students.map(student => {
                const studentMarks = subjects.slice(0, 3).map(sub => {
                  const m = marks.find(mk => mk.studentId === student.id && mk.subjectId === sub.id && mk.examId === activeExam.id);
                  return m ? m.obtainedMarks : 85;
                });
                const total = studentMarks.reduce((a, b) => a + b, 0);
                const avg = studentMarks.length > 0 ? total / studentMarks.length : 85;
                const gpa = avg >= 90 ? '4.0 (A+)' : avg >= 80 ? '3.7 (A)' : avg >= 70 ? '3.0 (B)' : '2.0 (C)';

                return (
                  <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-indigo-700">
                      #{student.rollNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">
                        {getStudentFullName(student)}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {student.admissionNumber}
                      </div>
                    </td>
                    {studentMarks.map((sc, idx) => (
                      <td key={idx} className="py-3 px-4 font-mono tabular-nums font-semibold text-slate-800">
                        {sc} / 100
                      </td>
                    ))}
                    <td className="py-3 px-4 font-mono tabular-nums font-bold text-indigo-700">
                      {total} pts · {gpa}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        PASSED
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onPrintTranscript(student, activeExam)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Transcript</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Schedule Exam Modal */}
      {scheduleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-400" />
                Schedule Examination Period
              </h3>
              <button onClick={() => setScheduleModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleScheduleExam} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Examination Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mid-Term Examination 2026"
                  value={newExamName}
                  onChange={e => setNewExamName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Start Date *</label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">End Date *</label>
                  <input
                    type="date"
                    required
                    value={endDate}
                    onChange={e => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setScheduleModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Schedule Exam
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mark Entry Modal */}
      {markEntryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">
                Enter Subject Marks ({subjects.find(s => s.id === selectedSubjectId)?.name})
              </h3>
              <button onClick={() => setMarkEntryModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>

            <form onSubmit={handleSaveMarks} className="p-6 space-y-4 text-xs">
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {students.map(student => (
                  <div key={student.id} className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                    <div>
                      <div className="font-semibold text-slate-900">
                        {getStudentFullName(student)}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">Roll #{student.rollNumber}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-slate-500 font-mono">Score:</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        step="0.5"
                        required
                        value={marksState[student.id] ?? 85}
                        onChange={e => setMarksState(prev => ({ ...prev, [student.id]: Number(e.target.value) }))}
                        className="w-20 px-2 py-1 text-xs border border-slate-300 rounded font-mono font-bold text-right"
                      />
                      <span className="text-slate-400">/ 100</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setMarkEntryModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Submit & Save Marks
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
