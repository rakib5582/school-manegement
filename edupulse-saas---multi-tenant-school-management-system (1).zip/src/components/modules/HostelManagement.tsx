import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { HostelRoom } from '../../types';
import { Home, Plus, CheckCircle2 } from 'lucide-react';

export const HostelManagement: React.FC = () => {
  const { currentTenant, getTenantHostels, addHostel } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Form State
  const [buildingName, setBuildingName] = useState('Newton Hall (Senior Boys)');
  const [roomNumber, setRoomNumber] = useState('');
  const [bedCount, setBedCount] = useState(2);
  const [monthlyFee, setMonthlyFee] = useState(220);

  const hostelList = getTenantHostels();

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomNumber) return;

    await addHostel({
      buildingName,
      roomNumber,
      bedCount: Number(bedCount),
      monthlyFee: Number(monthlyFee),
    });

    setRoomNumber('');
    setModalOpen(false);
    setToastMsg(`Allocated room ${roomNumber} in ${buildingName}.`);
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Home className="w-5 h-5 text-indigo-600" />
            Hostel & Boarding Accommodation
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage student dormitory halls, bed inventory, warden contacts, and boarding fees
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Allocate Room</span>
        </button>
      </div>

      {toastMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Hostels Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {hostelList.map(h => (
          <div key={h.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                  Room {h.roomNumber}
                </span>
                <span className="font-mono text-xs font-bold text-slate-900">${h.monthlyFee}/month</span>
              </div>
              <h3 className="font-bold text-sm text-slate-900 mt-2">{h.buildingName}</h3>
              <p className="text-xs text-slate-500 mt-1">{h.bedCount} Bed Allocation per room</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Warden On Duty</span>
              <span className="text-emerald-600 font-semibold">Ready for Occupancy</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Allocate Room */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Allocate Hostel Room</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Building Hall *</label>
                <input
                  type="text"
                  required
                  value={buildingName}
                  onChange={e => setBuildingName(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Room Number *</label>
                  <input
                    type="text"
                    required
                    value={roomNumber}
                    onChange={e => setRoomNumber(e.target.value)}
                    placeholder="e.g. N-205"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Bed Count</label>
                  <input
                    type="number"
                    min="1"
                    max="6"
                    value={bedCount}
                    onChange={e => setBedCount(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Monthly Fee ($)</label>
                <input
                  type="number"
                  min="1"
                  value={monthlyFee}
                  onChange={e => setMonthlyFee(Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Allocate Room
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
