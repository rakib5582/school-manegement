import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TransportRoute } from '../../types';
import { Bus, Plus, Phone, CheckCircle2, DollarSign } from 'lucide-react';

export const TransportManagement: React.FC = () => {
  const { currentTenant, getTenantRoutes, addRoute } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Form State
  const [routeName, setRouteName] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [driverName, setDriverName] = useState('');
  const [driverPhone, setDriverPhone] = useState('');
  const [fareMonthly, setFareMonthly] = useState(70);

  const routeList = getTenantRoutes();

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!routeName || !vehicleNumber) return;

    await addRoute({
      routeName,
      vehicleNumber,
      driverName: driverName || 'Designated Driver',
      driverPhone: driverPhone || '+1 (555) 000-0000',
      fareMonthly: Number(fareMonthly),
    });

    setRouteName('');
    setVehicleNumber('');
    setDriverName('');
    setDriverPhone('');
    setModalOpen(false);
    setToastMsg(`Registered new bus route "${routeName}" with vehicle ${vehicleNumber}.`);
    setTimeout(() => setToastMsg(null), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Bus className="w-5 h-5 text-indigo-600" />
            Transport Fleet & School Bus Routes
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage student pickup routes, verified drivers, fleet vehicles, and transportation fees
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Bus Route</span>
        </button>
      </div>

      {toastMsg && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Routes Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {routeList.map(route => (
          <div key={route.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-colors">
            <div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded">
                  {route.vehicleNumber}
                </span>
                <span className="font-mono text-xs font-bold text-slate-900">${route.fareMonthly}/mo</span>
              </div>
              <h3 className="font-bold text-sm text-slate-900 mt-2">{route.routeName}</h3>

              <div className="mt-4 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400">Driver:</span>
                  <span className="font-semibold text-slate-800">{route.driverName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono text-[11px]">{route.driverPhone}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>GPS Tracking Active</span>
              <span className="text-emerald-600 font-semibold">Route Active</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Add Route */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Add Bus Route</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Route Name *</label>
                <input
                  type="text"
                  required
                  value={routeName}
                  onChange={e => setRouteName(e.target.value)}
                  placeholder="e.g. West Somerville - Porter Sq Route"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Vehicle Plate *</label>
                  <input
                    type="text"
                    required
                    value={vehicleNumber}
                    onChange={e => setVehicleNumber(e.target.value.toUpperCase())}
                    placeholder="BUS-GW-05"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Monthly Fare ($)</label>
                  <input
                    type="number"
                    min="1"
                    value={fareMonthly}
                    onChange={e => setFareMonthly(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Driver Name *</label>
                  <input
                    type="text"
                    required
                    value={driverName}
                    onChange={e => setDriverName(e.target.value)}
                    placeholder="Marcus Bell"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Driver Phone *</label>
                  <input
                    type="tel"
                    required
                    value={driverPhone}
                    onChange={e => setDriverPhone(e.target.value)}
                    placeholder="+1 (555) 789-0123"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Create Route
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
