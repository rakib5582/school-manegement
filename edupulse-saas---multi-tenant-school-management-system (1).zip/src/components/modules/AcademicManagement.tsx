import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BookOpen, Plus, Layers, GraduationCap, CheckCircle2 } from 'lucide-react';

export const AcademicManagement: React.FC = () => {
  const { currentTenant, getTenantClasses, getTenantSections, getTenantSubjects, getTenantStudents, addClass, addSection, addSubject } = useApp();

  const classes = getTenantClasses();
  const sections = getTenantSections();
  const subjects = getTenantSubjects();
  const students = getTenantStudents();

  const [activeTab, setActiveTab] = useState<'CLASSES' | 'SUBJECTS'>('CLASSES');
  const [modalType, setModalType] = useState<'CLASS' | 'SECTION' | 'SUBJECT' | null>(null);

  // Form states
  const [className, setClassName] = useState('');
  const [gradeNumber, setGradeNumber] = useState(11);
  const [sectionName, setSectionName] = useState('');
  const [sectionCapacity, setSectionCapacity] = useState(40);
  const [selectedClassId, setSelectedClassId] = useState(classes[0]?.id || '');
  const [subjectName, setSubjectName] = useState('');
  const [subjectCode, setSubjectCode] = useState('');
  const [subjectType, setSubjectType] = useState<'THEORY' | 'PRACTICAL'>('THEORY');
  const [successToast, setSuccessToast] = useState(false);

  const handleModalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (modalType === 'CLASS') {
      await addClass({ name: className, numericGrade: Number(gradeNumber) });
      setClassName('');
    } else if (modalType === 'SECTION') {
      await addSection({
        classId: selectedClassId || classes[0]?.id,
        name: sectionName,
        capacity: Number(sectionCapacity),
      });
      setSectionName('');
    } else if (modalType === 'SUBJECT') {
      await addSubject({
        name: subjectName,
        code: subjectCode,
        type: subjectType,
        fullMarks: 100,
        passMarks: 40,
      });
      setSubjectName('');
      setSubjectCode('');
    }

    setModalType(null);
    setSuccessToast(true);
    setTimeout(() => setSuccessToast(false), 3500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Academic Structure: Classes, Sections & Subjects
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure grade levels, student capacity limits, and course syllabi
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setModalType('CLASS')}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add Class Grade</span>
          </button>
          <button
            onClick={() => setModalType('SUBJECT')}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-semibold rounded-lg text-xs transition-colors"
          >
            <Plus className="w-4 h-4 text-slate-500" />
            <span>Add Subject</span>
          </button>
        </div>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Academic configuration updated and synced across school timetable!</span>
        </div>
      )}

      {/* Navigation Switcher */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg max-w-fit text-xs">
        <button
          onClick={() => setActiveTab('CLASSES')}
          className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
            activeTab === 'CLASSES' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600'
          }`}
        >
          Classes & Sections ({classes.length})
        </button>
        <button
          onClick={() => setActiveTab('SUBJECTS')}
          className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
            activeTab === 'SUBJECTS' ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600'
          }`}
        >
          Curriculum Subjects ({subjects.length})
        </button>
      </div>

      {activeTab === 'CLASSES' ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {classes.map(c => {
            const classSections = sections.filter(s => s.classId === c.id);
            const classStudents = students.filter(s => s.classId === c.id);

            return (
              <div key={c.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">
                      Grade #{c.numericGrade}
                    </span>
                    <span className="font-mono text-xs text-slate-500">{classStudents.length} Students</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mt-2">{c.name}</h3>

                  <div className="mt-4 space-y-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                      Sections & Classroom Capacity
                    </span>
                    {classSections.map(sec => (
                      <div key={sec.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                        <span className="font-semibold text-slate-800">{sec.name}</span>
                        <span className="font-mono text-slate-500 text-[11px]">Cap: {sec.capacity} seats</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                  <button
                    onClick={() => {
                      setSelectedClassId(c.id);
                      setModalType('SECTION');
                    }}
                    className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold"
                  >
                    + Add Section to {c.name}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Subject Code</th>
                <th className="py-3 px-4">Subject Name</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4">Full Marks</th>
                <th className="py-3 px-4">Pass Threshold</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {subjects.map(s => (
                <tr key={s.id} className="hover:bg-slate-50/70">
                  <td className="py-3 px-4 font-mono font-bold text-indigo-700">{s.code}</td>
                  <td className="py-3 px-4 font-semibold text-slate-900">{s.name}</td>
                  <td className="py-3 px-4 font-mono text-[11px]">{s.type}</td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900">{s.fullMarks} pts</td>
                  <td className="py-3 px-4 font-mono text-slate-600">{s.passMarks} pts (40%)</td>
                  <td className="py-3 px-4">
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      ACTIVE
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal: Add Class / Section / Subject */}
      {modalType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">
                {modalType === 'CLASS' ? 'Add Class Grade' : modalType === 'SECTION' ? 'Add Section' : 'Add Subject'}
              </h3>
              <button onClick={() => setModalType(null)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleModalSubmit} className="p-6 space-y-4 text-xs">
              {modalType === 'CLASS' && (
                <>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Class Name *</label>
                    <input
                      type="text"
                      required
                      value={className}
                      onChange={e => setClassName(e.target.value)}
                      placeholder="e.g. Grade 11 (Senior)"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Numeric Grade (1-12) *</label>
                    <input
                      type="number"
                      min="1"
                      max="12"
                      required
                      value={gradeNumber}
                      onChange={e => setGradeNumber(Number(e.target.value))}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                    />
                  </div>
                </>
              )}

              {modalType === 'SECTION' && (
                <>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Section Name *</label>
                    <input
                      type="text"
                      required
                      value={sectionName}
                      onChange={e => setSectionName(e.target.value)}
                      placeholder="e.g. Section C"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Max Student Capacity</label>
                    <input
                      type="number"
                      min="10"
                      max="60"
                      value={sectionCapacity}
                      onChange={e => setSectionCapacity(Number(e.target.value))}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                    />
                  </div>
                </>
              )}

              {modalType === 'SUBJECT' && (
                <>
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Subject Name *</label>
                    <input
                      type="text"
                      required
                      value={subjectName}
                      onChange={e => setSubjectName(e.target.value)}
                      placeholder="e.g. World History"
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Subject Code *</label>
                      <input
                        type="text"
                        required
                        value={subjectCode}
                        onChange={e => setSubjectCode(e.target.value.toUpperCase())}
                        placeholder="HIST-105"
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono uppercase"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Type</label>
                      <select
                        value={subjectType}
                        onChange={e => setSubjectType(e.target.value as any)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                      >
                        <option value="THEORY">Theory</option>
                        <option value="PRACTICAL">Practical / Lab</option>
                      </select>
                    </div>
                  </div>
                </>
              )}

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalType(null)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Confirm & Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
