import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Role } from '../../types';
import { Shield, School, UserCheck, GraduationCap, Users, Lock, ArrowRight, AlertCircle, Loader2 } from 'lucide-react';

interface LoginViewProps {
  onLoginSuccess: () => void;
}

export const LoginView: React.FC<LoginViewProps> = ({ onLoginSuccess }) => {
  const { login } = useApp();
  const [emailOrUsername, setEmailOrUsername] = useState('admin@greenwood.edu');
  const [password, setPassword] = useState('DemoPassword@2026!');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const demoAccounts: { label: string; email: string; role: Role; desc: string; icon: React.ReactNode }[] = [
    {
      label: 'Super Admin',
      email: 'superadmin@saas-edupulse.com',
      role: 'SUPER_ADMIN',
      desc: 'Global SaaS platform control',
      icon: <Shield className="w-4 h-4 text-amber-600" />,
    },
    {
      label: 'School Admin (Greenwood)',
      email: 'admin@greenwood.edu',
      role: 'SCHOOL_ADMIN',
      desc: 'Full administrative operations',
      icon: <School className="w-4 h-4 text-indigo-600" />,
    },
    {
      label: 'Teacher (Ms. Sarah)',
      email: 'teacher.sarah@greenwood.edu',
      role: 'TEACHER',
      desc: 'Grade 10-A faculty register & marks',
      icon: <UserCheck className="w-4 h-4 text-emerald-600" />,
    },
    {
      label: 'Student (Alex Rivera)',
      email: 'student.alex@greenwood.edu',
      role: 'STUDENT',
      desc: 'Student ID card, timetable & grades',
      icon: <GraduationCap className="w-4 h-4 text-blue-600" />,
    },
    {
      label: 'Parent (Robert Rivera)',
      email: 'parent.robert@greenwood.edu',
      role: 'PARENT',
      desc: 'Child progress & fee clearance',
      icon: <Users className="w-4 h-4 text-purple-600" />,
    },
    {
      label: 'School Admin (Oakridge)',
      email: 'admin@oakridge.edu',
      role: 'SCHOOL_ADMIN',
      desc: 'Cross-tenant boundary test',
      icon: <School className="w-4 h-4 text-emerald-700" />,
    },
  ];

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSubmitting(true);

    try {
      const res = await login(emailOrUsername, password);
      if (!res.success) {
        setErrorMsg(res.error || 'Authentication failed. Please verify your credentials.');
        return;
      }
      onLoginSuccess();
    } catch (err: any) {
      setErrorMsg(err.message || 'Server authentication error.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuickLogin = async (email: string) => {
    setEmailOrUsername(email);
    setPassword('DemoPassword@2026!');
    setErrorMsg(null);
    setSubmitting(true);

    try {
      const res = await login(email, 'DemoPassword@2026!');
      if (!res.success) {
        setErrorMsg(res.error || 'Demo login failed');
        return;
      }
      onLoginSuccess();
    } catch (err: any) {
      setErrorMsg(err.message || 'Demo login failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4">
      <div className="max-w-md w-full space-y-6">
        {/* Brand */}
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl bg-indigo-600 mx-auto flex items-center justify-center text-white font-bold text-lg shadow-lg">
            EP
          </div>
          <h1 className="mt-3 text-xl font-bold text-white tracking-tight">EduPulse SaaS Platform</h1>
          <p className="text-xs text-slate-400 mt-0.5">Enterprise Multi-Tenant School Management REST API Auth</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-xl p-6 border border-slate-200">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-sm font-bold text-slate-900">Sign In to Your Workspace</h2>
            <span className="text-[10px] font-mono bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-semibold">
              POST /api/v1/auth/login
            </span>
          </div>
          <p className="text-xs text-slate-500 mb-4">Enter credentials to generate an authenticated JWT session</p>

          {errorMsg && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Email or Username</label>
              <input
                type="text"
                required
                value={emailOrUsername}
                onChange={e => setEmailOrUsername(e.target.value)}
                placeholder="admin@greenwood.edu"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">Default demo password: DemoPassword@2026!</span>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-semibold rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authenticating JWT...</span>
                </>
              ) : (
                <>
                  <span>Sign In & Authorize Session</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Quick Demo Logins Section */}
          <div className="mt-6 pt-5 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                DEMO EXPERIENCE: 1-Click Verified Accounts
              </span>
              <span className="text-[9px] text-slate-400 font-mono">Backend Verified</span>
            </div>
            <div className="space-y-1.5 max-h-56 overflow-y-auto">
              {demoAccounts.map((acc, i) => (
                <button
                  key={i}
                  type="button"
                  disabled={submitting}
                  onClick={() => handleQuickLogin(acc.email)}
                  className="w-full text-left p-2 rounded-lg border border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/50 flex items-center gap-2.5 transition-colors text-xs disabled:opacity-50 cursor-pointer"
                >
                  <div className="shrink-0">{acc.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-slate-900 truncate">{acc.label}</div>
                    <div className="text-[10px] text-slate-400 truncate">{acc.email}</div>
                  </div>
                  <span className="text-[10px] text-indigo-600 font-semibold uppercase shrink-0">
                    API Login →
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="text-center text-[11px] text-slate-500 font-mono">
          Protected by BCrypt Hashing, Spring Security JWT & TenantContext Filter
        </div>
      </div>
    </div>
  );
};
