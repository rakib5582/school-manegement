import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FeeInvoice, PaymentRecord } from '../../types';
import { CreditCard, Plus, Printer, CheckCircle2, DollarSign, Receipt } from 'lucide-react';

interface FeeManagementProps {
  onPrintReceipt: (payment: PaymentRecord, invoice: FeeInvoice) => void;
}

export const FeeManagement: React.FC<FeeManagementProps> = ({ onPrintReceipt }) => {
  const {
    getTenantStudents,
    getTenantInvoices,
    getTenantPayments,
    createInvoice,
    recordPayment,
  } = useApp();

  const students = getTenantStudents();
  const invoices = getTenantInvoices();
  const payments = getTenantPayments();

  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<FeeInvoice | null>(null);

  // Form states
  const [studentId, setStudentId] = useState(students[0]?.id || '');
  const [invoiceTitle, setInvoiceTitle] = useState('Fall Term Academic & Lab Fee');
  const [invoiceAmount, setInvoiceAmount] = useState(450);
  const [invoiceDueDate, setInvoiceDueDate] = useState('2026-10-31');

  const [payAmount, setPayAmount] = useState(450);
  const [payMethod, setPayMethod] = useState<'CASH' | 'CARD' | 'BANK_TRANSFER' | 'ONLINE'>('ONLINE');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const handleCreateInvoiceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createInvoice(studentId || students[0]?.id, invoiceTitle, Number(invoiceAmount), invoiceDueDate);
    setCreateModalOpen(false);
    setSuccessToast('New fee invoice successfully generated and dispatched to parent ledger.');
    setTimeout(() => setSuccessToast(null), 4000);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;

    const res = await recordPayment(selectedInvoice.id, Number(payAmount), payMethod);
    setPayModalOpen(false);
    setSuccessToast(`Payment of $${payAmount} confirmed! Receipt voucher: ${res.receiptNumber}`);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  const totalInvoiced = invoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const totalPaid = invoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalDue = totalInvoiced - totalPaid;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-indigo-600" />
            School Fees, Invoicing & Receipts
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage tuition structures, collect payments, and issue printable official voucher receipts
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Generate Fee Invoice</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Total Fees Invoiced</span>
            <DollarSign className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            ${totalInvoiced.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">{invoices.length} invoices generated</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Collected Revenue</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-600 mt-2 font-mono tabular-nums">
            ${totalPaid.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Verified bank & cash receipts</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Outstanding Dues</span>
            <Receipt className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-amber-600 mt-2 font-mono tabular-nums">
            ${totalDue.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {invoices.filter(i => i.status !== 'PAID').length} pending collection
          </div>
        </div>
      </div>

      {/* Invoices List */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-slate-900">Student Fee Ledger & Invoices</h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Invoice # & Title</th>
                <th className="py-3 px-4">Student</th>
                <th className="py-3 px-4">Due Date</th>
                <th className="py-3 px-4">Total Amount</th>
                <th className="py-3 px-4">Paid / Due</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {invoices.map(inv => {
                const student = students.find(s => s.id === inv.studentId);
                const paymentMatch = payments.find(p => p.invoiceId === inv.id);

                return (
                  <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{inv.title}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{inv.invoiceNumber}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">
                        {student?.gender === 'Male' ? 'Alex Rivera' : 'Sophia Chen'}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Adm: {student?.admissionNumber} · Roll #{student?.rollNumber}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">{inv.dueDate}</td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                      ${inv.totalAmount}
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums">
                      <span className="text-emerald-600 font-semibold">${inv.paidAmount}</span>
                      <span className="text-slate-400"> / </span>
                      <span className="text-amber-600 font-semibold">${inv.totalAmount - inv.paidAmount}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold ${
                          inv.status === 'PAID'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      {inv.status !== 'PAID' ? (
                        <button
                          onClick={() => {
                            setSelectedInvoice(inv);
                            setPayAmount(inv.totalAmount - inv.paidAmount);
                            setPayModalOpen(true);
                          }}
                          className="px-2.5 py-1 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md transition-colors"
                        >
                          Collect Payment
                        </button>
                      ) : (
                        paymentMatch && (
                          <button
                            onClick={() => onPrintReceipt(paymentMatch, inv)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                            <span>Print Receipt</span>
                          </button>
                        )
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Create Invoice */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Generate Fee Invoice</h3>
              <button onClick={() => setCreateModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleCreateInvoiceSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Student</label>
                <select
                  value={studentId}
                  onChange={e => setStudentId(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                >
                  {students.map(s => (
                    <option key={s.id} value={s.id}>
                      {s.gender === 'Male' ? 'Alex Rivera' : 'Sophia Chen'} ({s.admissionNumber})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Invoice Title</label>
                <input
                  type="text"
                  required
                  value={invoiceTitle}
                  onChange={e => setInvoiceTitle(e.target.value)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Amount ($)</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={invoiceAmount}
                    onChange={e => setInvoiceAmount(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Due Date</label>
                  <input
                    type="date"
                    required
                    value={invoiceDueDate}
                    onChange={e => setInvoiceDueDate(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Generate Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Collect Payment */}
      {payModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Collect Fee Payment</h3>
              <button onClick={() => setPayModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handlePaymentSubmit} className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="font-semibold text-slate-900">{selectedInvoice.title}</div>
                <div className="text-[11px] text-slate-500 font-mono">Invoice: {selectedInvoice.invoiceNumber}</div>
                <div className="mt-1 font-bold text-slate-800">
                  Total: ${selectedInvoice.totalAmount} · Remaining Due: ${selectedInvoice.totalAmount - selectedInvoice.paidAmount}
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Payment Amount ($)</label>
                <input
                  type="number"
                  min="1"
                  max={selectedInvoice.totalAmount - selectedInvoice.paidAmount}
                  required
                  value={payAmount}
                  onChange={e => setPayAmount(Number(e.target.value))}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Payment Method</label>
                <select
                  value={payMethod}
                  onChange={e => setPayMethod(e.target.value as any)}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                >
                  <option value="ONLINE">Online Credit / Debit Card</option>
                  <option value="BANK_TRANSFER">Bank Wire Transfer</option>
                  <option value="CASH">Cash at Accounts Desk</option>
                  <option value="CARD">POS Terminal</option>
                </select>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setPayModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Record Payment & Issue Receipt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
