import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Assignment } from '../../types';
import { BookOpen, Plus, Calendar, CheckCircle2, User, Award } from 'lucide-react';

export const HomeworkManagement: React.FC = () => {
  const { currentTenant, getTenantAssignments, getTenantClasses, getTenantSections, getTenantSubjects, getTenantTeachers, addAssignment } = useApp();
  const classes = getTenantClasses();
  const sections = getTenantSections();
  const subjects = getTenantSubjects();
  const teachers = getTenantTeachers();

  const [modalOpen, setModalOpen] = useState(false);
  const [successToast, setSuccessToast] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedClassId, setSelectedClassId] = useState(classes[0]?.id || '');
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || '');
  const [dueDate, setDueDate] = useState('2026-10-25');
  const [points, setPoints] = useState(50);

  const tenantAssignments = getTenantAssignments();

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    await addAssignment({
      classId: selectedClassId || classes[0]?.id,
      sectionId: sections[0]?.id || 'sec-001',
      subjectId: selectedSubjectId || subjects[0]?.id,
      teacherId: teachers[0]?.id || 'tch-001',
      title,
      description,
      dueDate,
      totalPoints: Number(points),
    });

    setTitle('');
    setDescription('');
    setModalOpen(false);
    setSuccessToast(true);
    setTimeout(() => setSuccessToast(false), 3500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Homework & Classroom Assignments
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Create homework tasks, set grading rubrics, and track student submissions
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Assign New Homework</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Homework task published to class portal and parent dashboard!</span>
        </div>
      )}

      {/* Assignments Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {tenantAssignments.map(asgn => {
          const sub = subjects.find(s => s.id === asgn.subjectId);
          const cls = classes.find(c => c.id === asgn.classId);

          return (
            <div key={asgn.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                  <span className="font-semibold text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-indigo-50 text-indigo-700">
                    {sub?.name || 'Mathematics'} · {cls?.name || 'Grade 10'}
                  </span>
                  <span className="font-mono text-slate-700 font-bold">{asgn.totalPoints} Points</span>
                </div>
                <h3 className="font-bold text-sm text-slate-900">{asgn.title}</h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">{asgn.description}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center gap-1 text-rose-600 font-medium">
                  <Calendar className="w-3.5 h-3.5" />
                  Due: {asgn.dueDate}
                </span>
                <span className="text-emerald-600 font-semibold">Open for Submission</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Assign Homework */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Assign New Homework</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Homework Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Electromagnetic Waves Problem Set"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Class Grade</label>
                  <select
                    value={selectedClassId}
                    onChange={e => setSelectedClassId(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Subject</label>
                  <select
                    value={selectedSubjectId}
                    onChange={e => setSelectedSubjectId(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    {subjects.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Submission Deadline</label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Total Points</label>
                  <input
                    type="number"
                    min="10"
                    max="100"
                    value={points}
                    onChange={e => setPoints(Number(e.target.value))}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Instructions & References</label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Specify problem numbers, requirements, and formatting guidelines..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Publish Assignment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
