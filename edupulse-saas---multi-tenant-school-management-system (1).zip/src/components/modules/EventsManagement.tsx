import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolEvent } from '../../types';
import { Calendar, Plus, Trophy, BookOpen, AlertCircle, CheckCircle2 } from 'lucide-react';

export const EventsManagement: React.FC = () => {
  const { currentTenant, getTenantEvents, addEvent } = useApp();
  const [modalOpen, setModalOpen] = useState(false);
  const [filterType, setFilterType] = useState('ALL');
  const [successToast, setSuccessToast] = useState(false);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [eventDate, setEventDate] = useState('2026-11-15');
  const [eventType, setEventType] = useState<'HOLIDAY' | 'MEETING' | 'EXAM' | 'SPORTS' | 'GENERAL'>('SPORTS');

  const tenantEvents = getTenantEvents();
  const filteredEvents = tenantEvents.filter(e => filterType === 'ALL' || e.eventType === filterType);

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    await addEvent({
      title,
      description,
      eventDate,
      eventType,
    });

    setTitle('');
    setDescription('');
    setModalOpen(false);
    setSuccessToast(true);
    setTimeout(() => setSuccessToast(false), 3500);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Calendar className="w-5 h-5 text-indigo-600" />
            School Calendar & Institutional Events
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Plan term milestones, athletic meets, academic examinations, and parent conferences
          </p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule Event</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Event successfully posted on school public calendar and notifications!</span>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg max-w-fit text-xs">
        {['ALL', 'EXAM', 'SPORTS', 'MEETING', 'HOLIDAY'].map(type => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors ${
              filterType === type ? 'bg-white text-slate-900 shadow-2xs font-semibold' : 'text-slate-600'
            }`}
          >
            {type === 'ALL' ? 'All Events' : type}
          </button>
        ))}
      </div>

      {/* Events Grid */}
      <div className="grid md:grid-cols-2 gap-4">
        {filteredEvents.map(ev => (
          <div key={ev.id} className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                  ev.eventType === 'EXAM' ? 'bg-amber-100 text-amber-800' :
                  ev.eventType === 'SPORTS' ? 'bg-emerald-100 text-emerald-800' :
                  ev.eventType === 'MEETING' ? 'bg-blue-100 text-blue-800' :
                  'bg-purple-100 text-purple-800'
                }`}>
                  {ev.eventType}
                </span>
                <span className="font-mono text-slate-700 font-semibold">{ev.eventDate}</span>
              </div>
              <h3 className="font-bold text-sm text-slate-900">{ev.title}</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">{ev.description}</p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
              <span>Tenant: {currentTenant?.code}</span>
              <span className="text-indigo-600 font-semibold">Calendar Confirmed</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Schedule Event */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Schedule Calendar Event</h3>
              <button onClick={() => setModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Event Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Science Fair & Hackathon 2026"
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Event Date *</label>
                  <input
                    type="date"
                    required
                    value={eventDate}
                    onChange={e => setEventDate(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Event Type</label>
                  <select
                    value={eventType}
                    onChange={e => setEventType(e.target.value as any)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white text-slate-800"
                  >
                    <option value="EXAM">Examination</option>
                    <option value="SPORTS">Athletics / Sports</option>
                    <option value="MEETING">Conference / PTM</option>
                    <option value="HOLIDAY">Official Holiday</option>
                    <option value="GENERAL">General Milestone</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Event Description</label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Provide schedule details, venue and dress code requirements..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-md"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Add to Calendar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
