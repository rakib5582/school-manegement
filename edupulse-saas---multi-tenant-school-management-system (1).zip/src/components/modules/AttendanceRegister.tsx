import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { CalendarCheck, Save, CheckCircle2, UserCheck, AlertTriangle } from 'lucide-react';

export const AttendanceRegister: React.FC = () => {
  const {
    getTenantStudents,
    getTenantClasses,
    getTenantSections,
    getTenantAttendance,
    recordAttendance,
  } = useApp();

  const students = getTenantStudents();
  const classes = getTenantClasses();
  const sections = getTenantSections();

  const [date, setDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [selectedClassId, setSelectedClassId] = useState<string>(() => classes[0]?.id || '');
  const [selectedSectionId, setSelectedSectionId] = useState<string>(() => sections[0]?.id || '');
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Filter students for this class & section
  const classStudents = students.filter(
    s => (!selectedClassId || s.classId === selectedClassId) && (!selectedSectionId || s.sectionId === selectedSectionId)
  );

  // Status map: studentId -> status
  const [statusMap, setStatusMap] = useState<Record<string, 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE'>>({});
  const [remarksMap, setRemarksMap] = useState<Record<string, string>>({});

  // Sync existing attendance records for the selected date
  useEffect(() => {
    const existingRecords = getTenantAttendance(date);
    const initialStatus: Record<string, 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE'> = {};
    const initialRemarks: Record<string, string> = {};

    classStudents.forEach(s => {
      const match = existingRecords.find(r => r.studentId === s.id);
      if (match) {
        initialStatus[s.id] = match.status;
        initialRemarks[s.id] = match.remarks || '';
      } else {
        initialStatus[s.id] = 'PRESENT'; // default to Present
      }
    });

    setStatusMap(initialStatus);
    setRemarksMap(initialRemarks);
  }, [date, selectedClassId, selectedSectionId, students.length]);

  const handleStatusChange = (studentId: string, status: 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE') => {
    setStatusMap(prev => ({ ...prev, [studentId]: status }));
  };

  const handleSave = async () => {
    const records = classStudents.map(s => ({
      studentId: s.id,
      status: statusMap[s.id] || 'PRESENT',
      remarks: remarksMap[s.id] || '',
    }));

    await recordAttendance(date, records);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3500);
  };

  const presentCount = Object.values(statusMap).filter(v => v === 'PRESENT').length;
  const absentCount = Object.values(statusMap).filter(v => v === 'ABSENT').length;
  const lateCount = Object.values(statusMap).filter(v => v === 'LATE').length;
  const attendanceRate = classStudents.length > 0 ? Math.round((presentCount / classStudents.length) * 100) : 100;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-emerald-600" />
            Classroom Daily Attendance Register
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Mark daily student attendance, prevent duplicate logs, and track live percentage
          </p>
        </div>

        <button
          onClick={handleSave}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors shrink-0"
        >
          <Save className="w-4 h-4" />
          <span>Save Register</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Daily attendance records successfully saved! Duplicate records prevented.</span>
        </div>
      )}

      {/* Control Bar & Stats */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div>
            <label className="block text-slate-500 text-[11px] font-medium mb-1">Date</label>
            <input
              type="date"
              value={date}
              onChange={e => setDate(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 rounded-md font-mono text-slate-800"
            />
          </div>

          <div>
            <label className="block text-slate-500 text-[11px] font-medium mb-1">Class Grade</label>
            <select
              value={selectedClassId}
              onChange={e => setSelectedClassId(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-800"
            >
              {classes.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-slate-500 text-[11px] font-medium mb-1">Section</label>
            <select
              value={selectedSectionId}
              onChange={e => setSelectedSectionId(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-200 rounded-md bg-white text-slate-800"
            >
              {sections.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Live Counters */}
        <div className="flex items-center gap-4 text-xs font-mono tabular-nums">
          <div className="text-center">
            <div className="text-slate-400 text-[10px]">TOTAL</div>
            <div className="font-bold text-slate-900 text-sm">{classStudents.length}</div>
          </div>
          <div className="text-center">
            <div className="text-emerald-600 text-[10px]">PRESENT</div>
            <div className="font-bold text-emerald-600 text-sm">{presentCount}</div>
          </div>
          <div className="text-center">
            <div className="text-rose-600 text-[10px]">ABSENT</div>
            <div className="font-bold text-rose-600 text-sm">{absentCount}</div>
          </div>
          <div className="text-center">
            <div className="text-amber-600 text-[10px]">LATE</div>
            <div className="font-bold text-amber-600 text-sm">{lateCount}</div>
          </div>
          <div className="pl-3 border-l border-slate-200 text-center">
            <div className="text-slate-400 text-[10px]">RATE</div>
            <div className="font-bold text-indigo-600 text-sm">{attendanceRate}%</div>
          </div>
        </div>
      </div>

      {/* Attendance Register Sheet */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Roll</th>
                <th className="py-3 px-4">Student & Admission</th>
                <th className="py-3 px-4 text-center">Attendance Status</th>
                <th className="py-3 px-4">Remarks</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {classStudents.map(student => {
                const currentStatus = statusMap[student.id] || 'PRESENT';
                return (
                  <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-indigo-700">
                      #{student.rollNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">
                        {student.gender === 'Male' ? 'Alex Rivera' : 'Sophia Chen'}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {student.admissionNumber}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50">
                        {(['PRESENT', 'ABSENT', 'LATE', 'LEAVE'] as const).map(status => {
                          const isActive = currentStatus === status;
                          const colorMap = {
                            PRESENT: 'bg-emerald-600 text-white',
                            ABSENT: 'bg-rose-600 text-white',
                            LATE: 'bg-amber-500 text-white',
                            LEAVE: 'bg-blue-600 text-white',
                          };
                          return (
                            <button
                              key={status}
                              onClick={() => handleStatusChange(student.id, status)}
                              className={`px-2.5 py-1 text-[11px] font-semibold rounded-md transition-colors ${
                                isActive ? colorMap[status] : 'text-slate-600 hover:text-slate-900'
                              }`}
                            >
                              {status}
                            </button>
                          );
                        })}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <input
                        type="text"
                        value={remarksMap[student.id] || ''}
                        onChange={e => setRemarksMap(prev => ({ ...prev, [student.id]: e.target.value }))}
                        placeholder="Optional remarks..."
                        className="w-full px-2 py-1 text-xs border border-slate-200 rounded-md bg-white focus:outline-hidden"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
