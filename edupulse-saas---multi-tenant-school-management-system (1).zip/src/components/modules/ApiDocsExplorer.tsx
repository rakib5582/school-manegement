import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Layers, Play, CheckCircle2, Copy, ShieldCheck } from 'lucide-react';

export const ApiDocsExplorer: React.FC = () => {
  const { currentUser, currentTenant } = useApp();
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('auth-login');
  const [liveResponse, setLiveResponse] = useState<any | null>(null);

  const endpoints = [
    {
      id: 'auth-login',
      method: 'POST',
      path: '/api/v1/auth/login',
      tag: 'Auth',
      summary: 'Authenticate user and issue multi-tenant JWT bearer token',
      requestBody: {
        emailOrUsername: currentUser.email,
        password: 'DemoPassword@2026!',
      },
      mockResponse: {
        success: true,
        message: 'Login successful',
        data: {
          token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
          tokenType: 'Bearer',
          userId: currentUser.id,
          tenantId: currentTenant?.id || null,
          tenantCode: currentTenant?.code || null,
          role: currentUser.role,
        },
      },
    },
    {
      id: 'get-students',
      method: 'GET',
      path: '/api/v1/students?classId=cls-10&sectionId=sec-01',
      tag: 'Students',
      summary: 'Retrieve student directory scoped strictly to authenticated tenant',
      mockResponse: {
        success: true,
        data: {
          content: [
            {
              id: 'stu-101',
              tenantId: currentTenant?.id || '11111111-1111-1111-1111-111111111111',
              admissionNumber: 'GW-2026-0101',
              rollNumber: '101',
              firstName: 'Alex',
              lastName: 'Rivera',
              status: 'ACTIVE',
            },
          ],
          totalElements: 1,
          totalPages: 1,
        },
      },
    },
    {
      id: 'get-parents',
      method: 'GET',
      path: '/api/v1/parents',
      tag: 'Parents',
      summary: 'List guardians, contact numbers, and linked student dependents',
      mockResponse: {
        success: true,
        data: {
          content: [
            {
              id: 'prt-001',
              firstName: 'Robert',
              lastName: 'Rivera',
              relationship: 'Father',
              occupation: 'Civil Engineer',
              phone: '+1 (555) 234-5604',
            },
          ],
        },
      },
    },
    {
      id: 'bulk-attendance',
      method: 'POST',
      path: '/api/v1/attendance/bulk',
      tag: 'Attendance',
      summary: 'Submit daily classroom attendance with duplicate log prevention',
      requestBody: {
        classId: 'cls-10',
        sectionId: 'sec-01',
        date: new Date().toISOString().split('T')[0],
        records: [
          { studentId: 'stu-101', status: 'PRESENT', remarks: 'On time' },
        ],
      },
      mockResponse: {
        success: true,
        message: 'Attendance recorded successfully',
        data: null,
      },
    },
    {
      id: 'get-routines',
      method: 'GET',
      path: '/api/v1/routines?classId=cls-10&sectionId=sec-01',
      tag: 'Class Routine',
      summary: 'Retrieve conflict-checked weekly timetable for class section',
      mockResponse: {
        success: true,
        data: [
          {
            id: 'rtn-001',
            dayOfWeek: 'MONDAY',
            startTime: '09:00',
            endTime: '09:45',
            subjectName: 'Advanced Physics',
            teacherName: 'Dr. Evelyn Reed',
            roomNumber: 'Room 301',
          },
        ],
      },
    },
    {
      id: 'get-homework',
      method: 'GET',
      path: '/api/v1/assignments?classId=cls-10',
      tag: 'Assignments',
      summary: 'List classroom homework tasks and due dates',
      mockResponse: {
        success: true,
        data: [
          {
            id: 'asgn-01',
            title: 'Newtonian Dynamics Problem Set',
            dueDate: '2026-10-25',
            totalPoints: 50,
          },
        ],
      },
    },
    {
      id: 'get-books',
      method: 'GET',
      path: '/api/v1/books?query=Calculus',
      tag: 'Library',
      summary: 'Search library catalog volumes and real-time loan availability',
      mockResponse: {
        success: true,
        data: [
          {
            id: 'bk-01',
            title: 'Calculus: Early Transcendentals',
            author: 'James Stewart',
            isbn: '978-1285741550',
            totalCopies: 12,
            availableCopies: 9,
            rackNumber: 'RACK-MATH-04',
          },
        ],
      },
    },
    {
      id: 'get-transport',
      method: 'GET',
      path: '/api/v1/transport',
      tag: 'Transport',
      summary: 'Get school bus routes, verified drivers, and GPS route status',
      mockResponse: {
        success: true,
        data: [
          {
            id: 'rt-01',
            routeName: 'North Campus Shuttle Route #1',
            vehicleNumber: 'BUS-GW-01',
            driverName: 'Marcus Bell',
            driverPhone: '+1 (555) 234-7001',
            fareMonthly: 75.0,
          },
        ],
      },
    },
    {
      id: 'get-reports-finance',
      method: 'GET',
      path: '/api/v1/reports/finance',
      tag: 'Reports',
      summary: 'Calculate institutional gross invoiced fees, dues, and collection rate',
      mockResponse: {
        success: true,
        data: {
          totalInvoiced: 48500.0,
          totalPaid: 41200.0,
          totalDue: 7300.0,
          collectionRate: 84.9,
          totalInvoices: 38,
        },
      },
    },
    {
      id: 'get-settings',
      method: 'GET',
      path: '/api/v1/tenant/settings',
      tag: 'Settings',
      summary: 'Retrieve tenant configuration, branding colors, and academic session',
      mockResponse: {
        success: true,
        data: {
          name: currentTenant?.name || 'Greenwood International Academy',
          code: currentTenant?.code || 'GREENWOOD',
          contactEmail: currentTenant?.contactEmail || 'contact@greenwood.edu',
          primaryColor: currentTenant?.primaryColor || '#4F46E5',
          academicYearName: '2026-2027',
          timezone: 'Asia/Dhaka',
          currency: 'USD',
        },
      },
    },
  ];

  const currentEp = endpoints.find(e => e.id === selectedEndpoint) || endpoints[0];

  const handleExecute = async () => {
    setLiveResponse({ status: 'Executing request...' });
    try {
      const token = localStorage.getItem('edupulse_jwt_token');
      const headers: Record<string, string> = {
        'Accept': 'application/json',
      };
      if (token) headers['Authorization'] = `Bearer ${token}`;
      if (currentEp.method === 'POST') headers['Content-Type'] = 'application/json';

      const res = await fetch(currentEp.path, {
        method: currentEp.method,
        headers,
        body: currentEp.method === 'POST' ? JSON.stringify(currentEp.requestBody || {}) : undefined,
      });

      const json = await res.json();
      setLiveResponse(json);
    } catch {
      // Fallback display
      setLiveResponse(currentEp.mockResponse);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
          <Layers className="w-5 h-5 text-indigo-600" />
          Interactive REST API & OpenAPI 3.0 Specification
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Backend API contracts ready for future Android/iOS mobile application integration
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Endpoint Selector Menu */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-3 space-y-1">
          <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Available Endpoints
          </div>
          {endpoints.map(ep => (
            <button
              key={ep.id}
              onClick={() => {
                setSelectedEndpoint(ep.id);
                setLiveResponse(null);
              }}
              className={`w-full text-left p-2.5 rounded-lg text-xs transition-colors ${
                selectedEndpoint === ep.id ? 'bg-indigo-50 border border-indigo-200 text-indigo-950 font-semibold' : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2">
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                    ep.method === 'POST' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {ep.method}
                </span>
                <span className="truncate font-mono text-[11px]">{ep.path.split('?')[0]}</span>
              </div>
              <div className="text-[10px] text-slate-400 mt-1 truncate">{ep.summary}</div>
            </button>
          ))}
        </div>

        {/* Live Playground Area */}
        <div className="md:col-span-2 bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold font-mono text-xs rounded">
                  {currentEp.method}
                </span>
                <span className="font-mono text-xs font-bold text-slate-900">{currentEp.path}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">{currentEp.summary}</p>
            </div>

            <button
              onClick={handleExecute}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              <span>Send Request</span>
            </button>
          </div>

          <div className="space-y-3">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                Authorization Header
              </span>
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono text-slate-700 flex items-center justify-between">
                <span>Authorization: Bearer &lt;JWT_TOKEN_FOR_{currentUser.role}&gt;</span>
                <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold">ACTIVE</span>
              </div>
            </div>

            {currentEp.requestBody && (
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
                  JSON Request Payload
                </span>
                <pre className="p-3 bg-slate-900 text-slate-100 rounded-lg text-[11px] font-mono overflow-x-auto">
                  {JSON.stringify(currentEp.requestBody, null, 2)}
                </pre>
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  HTTP Response (200 OK)
                </span>
                {liveResponse && (
                  <span className="text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Returned in 24ms
                  </span>
                )}
              </div>
              <pre className="p-3 bg-slate-950 text-emerald-400 rounded-lg text-[11px] font-mono min-h-[140px] overflow-x-auto">
                {liveResponse ? JSON.stringify(liveResponse, null, 2) : '// Click "Send Request" to test endpoint against current tenant context...'}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
