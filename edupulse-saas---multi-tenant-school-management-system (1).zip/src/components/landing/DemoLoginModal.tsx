import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Role } from '../../types';
import {
  Shield,
  School,
  UserCheck,
  GraduationCap,
  Users,
  Building2,
  X,
  Lock,
  ArrowRight,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface DemoLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialRole?: Role;
}

export const DemoLoginModal: React.FC<DemoLoginModalProps> = ({
  isOpen,
  onClose,
  initialRole,
}) => {
  const { login, tenants } = useApp();
  const { t, language } = useLanguage();

  const [activeTab, setActiveTab] = useState<'quick' | 'form'>('quick');
  const [selectedRole, setSelectedRole] = useState<Role>(initialRole || 'SCHOOL_ADMIN');
  const [emailInput, setEmailInput] = useState('admin@greenwood.edu');
  const [passwordInput, setPasswordInput] = useState('DemoPassword@2026!');
  const [selectedTenantId, setSelectedTenantId] = useState(tenants[0]?.id || '');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const demoAccounts: {
    role: Role;
    email: string;
    label: string;
    school: string;
    description: string;
    icon: React.ReactNode;
    color: string;
    border: string;
  }[] = [
    {
      role: 'SUPER_ADMIN',
      email: 'superadmin@saas-edupulse.com',
      label: language === 'bn' ? 'সুপার অ্যাডমিন' : 'Super Admin',
      school: language === 'bn' ? 'গ্লোবাল প্ল্যাটফর্ম' : 'Global SaaS Platform',
      description: language === 'bn' ? 'সকল স্কুল নিয়ন্ত্রণ, লাইসেন্সিং ও অডিট ট্রেইল' : 'Multi-school governance, tier licensing & audit logs',
      icon: <Shield className="w-5 h-5 text-amber-600" />,
      color: 'bg-amber-50 text-amber-900',
      border: 'hover:border-amber-400',
    },
    {
      role: 'SCHOOL_ADMIN',
      email: 'admin@greenwood.edu',
      label: language === 'bn' ? 'স্কুল অ্যাডমিন (গ্রিনউড)' : 'School Admin (Greenwood)',
      school: 'Greenwood Int. Academy',
      description: language === 'bn' ? 'সম্পূর্ণ স্কুল পরিচালনা, বেতন, ফি ও শিক্ষক নিয়ন্ত্রণ' : 'Full institutional ops, faculty, attendance, routine & billing',
      icon: <School className="w-5 h-5 text-indigo-600" />,
      color: 'bg-indigo-50 text-indigo-900',
      border: 'hover:border-indigo-400',
    },
    {
      role: 'TEACHER',
      email: 'teacher.sarah@greenwood.edu',
      label: language === 'bn' ? 'শ্রেণি শিক্ষক (মিসেস সারাহ)' : 'Teacher (Ms. Sarah)',
      school: 'Greenwood Int. Academy',
      description: language === 'bn' ? 'হাজিরা গ্রহণ, পরীক্ষার মার্ক এন্ট্রি ও অ্যাসাইনমেন্ট' : 'Grade 10-A attendance register, mark entry & homework',
      icon: <UserCheck className="w-5 h-5 text-emerald-600" />,
      color: 'bg-emerald-50 text-emerald-900',
      border: 'hover:border-emerald-400',
    },
    {
      role: 'STUDENT',
      email: 'student.alex@greenwood.edu',
      label: language === 'bn' ? 'শিক্ষার্থী (অ্যালেক্স রিভেরা)' : 'Student (Alex Rivera)',
      school: 'Greenwood Int. Academy',
      description: language === 'bn' ? 'স্টুডেন্ট আইডি কার্ড, ক্লাস রুটিন, রেজাল্ট ও ফি রসিদ' : 'Student ID card, timetable, GPA transcript & fee receipts',
      icon: <GraduationCap className="w-5 h-5 text-blue-600" />,
      color: 'bg-blue-50 text-blue-900',
      border: 'hover:border-blue-400',
    },
    {
      role: 'PARENT',
      email: 'parent.robert@greenwood.edu',
      label: language === 'bn' ? 'অভিভাবক (রবার্ট রিভেরা)' : 'Parent (Robert Rivera)',
      school: 'Greenwood Int. Academy',
      description: language === 'bn' ? 'সন্তানের উপস্থিতি, পরীক্ষার ফলাফল ও ফি পরিশোধ' : 'Child academic progress, attendance tracking & tuition invoices',
      icon: <Users className="w-5 h-5 text-purple-600" />,
      color: 'bg-purple-50 text-purple-900',
      border: 'hover:border-purple-400',
    },
    {
      role: 'SCHOOL_ADMIN',
      email: 'admin@oakridge.edu',
      label: language === 'bn' ? 'স্কুল অ্যাডমিন (ওকরিজ)' : 'School Admin (Oakridge)',
      school: 'Oakridge Global Academy',
      description: language === 'bn' ? 'দ্বিতীয় স্বতন্ত্র স্কুল - টেন্যান্ট আইসোলেশন পরীক্ষা' : 'Secondary tenant to test strict cross-school data isolation',
      icon: <Building2 className="w-5 h-5 text-teal-600" />,
      color: 'bg-teal-50 text-teal-900',
      border: 'hover:border-teal-400',
    },
  ];

  const handleQuickSignIn = async (role: Role, email: string) => {
    setSubmitting(true);
    setErrorMessage(null);
    try {
      const res = await login(role, email);
      if (res && !res.success) {
        setErrorMessage(res.error || 'Authentication failed');
        return;
      }
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Login failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleFormSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMessage(null);
    try {
      const res = await login(emailInput, passwordInput);
      if (res && !res.success) {
        setErrorMessage(res.error || 'Invalid credentials');
        return;
      }
      onClose();
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid credentials');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-sm text-white">
              EP
            </div>
            <div>
              <h2 className="font-bold text-base tracking-tight flex items-center gap-2">
                <span>{language === 'bn' ? 'এডুপালস সাস প্রবেশদ্বার' : 'EduPulse SaaS Portal Login'}</span>
                <span className="text-[10px] bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 px-2 py-0.5 rounded-full font-medium">
                  {language === 'bn' ? 'নিরাপদ ক্লাউড' : 'Multi-Tenant Cloud'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                {language === 'bn' ? 'ভূমিকা নির্বাচন করে সরাসরি ড্যাশবোর্ডে প্রবেশ করুন' : 'Select a demo persona or authenticate with institutional credentials'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-3 gap-2">
          <button
            onClick={() => setActiveTab('quick')}
            className={`pb-2.5 text-xs font-semibold px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'quick'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ইনস্ট্যান্ট রোল সুইচার ডেমো' : 'Instant 1-Click Role Personas'}</span>
          </button>
          <button
            onClick={() => setActiveTab('form')}
            className={`pb-2.5 text-xs font-semibold px-3 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'form'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'ইউজারনেম ও পাসওয়ার্ড লগইন' : 'Credential Sign In'}</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {activeTab === 'quick' ? (
            <div className="space-y-3">
              {errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                  {errorMessage}
                </div>
              )}
              <div className="text-xs text-slate-600 mb-2">
                {language === 'bn'
                  ? 'নিচের যেকোনো ভূমিকা নির্বাচন করুন। সিস্টেম স্বয়ংক্রিয়ভাবে যথাযথ পারমিশন ও টেন্যান্ট লোড করবে:'
                  : 'Click any role profile below to instantly experience its custom dashboard and workflows:'}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {demoAccounts.map((acc, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleQuickSignIn(acc.role, acc.email)}
                    className={`text-left p-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50/80 transition-all shadow-xs flex flex-col justify-between group ${acc.border}`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="p-1.5 rounded-lg bg-slate-100 group-hover:scale-105 transition-transform">
                          {acc.icon}
                        </div>
                        <span className="text-[10px] font-semibold text-slate-500 uppercase font-mono tracking-wider bg-slate-100 px-1.5 py-0.5 rounded">
                          {acc.school}
                        </span>
                      </div>
                      <div className="font-bold text-xs text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {acc.label}
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                        {acc.description}
                      </div>
                    </div>

                    <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-indigo-600 font-semibold">
                      <span className="font-mono text-[10px] text-slate-400">{acc.email}</span>
                      <span className="flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                        <span>{language === 'bn' ? 'প্রবেশ করুন' : 'Launch'}</span>
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <form onSubmit={handleFormSignIn} className="space-y-4 max-w-md mx-auto">
              {errorMessage && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                  {errorMessage}
                </div>
              )}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'প্রতিষ্ঠান নির্বাচন করুন (Tenant Scope)' : 'Select School Tenant'}
                </label>
                <select
                  value={selectedTenantId}
                  onChange={e => setSelectedTenantId(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  {tenants.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'ভূমিকা (Role Context)' : 'Role Context'}
                </label>
                <select
                  value={selectedRole}
                  onChange={e => setSelectedRole(e.target.value as Role)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="SUPER_ADMIN">Super Administrator (Global SaaS)</option>
                  <option value="SCHOOL_ADMIN">School Principal / Admin</option>
                  <option value="TEACHER">Faculty / Teacher</option>
                  <option value="STUDENT">Enrolled Student</option>
                  <option value="PARENT">Parent / Legal Guardian</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'ইমেইল ঠিকানা' : 'Email Address'}
                </label>
                <input
                  type="email"
                  value={emailInput}
                  onChange={e => setEmailInput(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {language === 'bn' ? 'পাসওয়ার্ড' : 'Password'}
                </label>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={e => setPasswordInput(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <span>{language === 'bn' ? 'নিরাপদ লগইন করুন' : 'Sign In to Portal'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>

        {/* Footer info banner */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>
              {language === 'bn'
                ? 'কঠোর টেন্যান্ট আইসোলেশন ও অডিট লগ সক্রিয়'
                : 'Tenant Isolation enforced by Spring Boot 3 & ThreadLocal Context'}
            </span>
          </div>
          <span className="font-mono text-[10px] text-slate-400">v2.4.0 SaaS</span>
        </div>
      </div>
    </div>
  );
};
