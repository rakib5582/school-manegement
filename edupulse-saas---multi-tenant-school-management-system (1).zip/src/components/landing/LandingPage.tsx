import React, { useState } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { useApp } from '../../context/AppContext';
import { LanguageSelector } from '../common/LanguageSelector';
import { DemoLoginModal } from './DemoLoginModal';
import { Role } from '../../types';
import {
  Shield,
  School,
  GraduationCap,
  Users,
  CalendarCheck,
  Award,
  CreditCard,
  Clock,
  BookOpen,
  Bell,
  Bus,
  Home,
  FileText,
  Sliders,
  ChevronRight,
  Check,
  CheckCircle2,
  Lock,
  Smartphone,
  Layers,
  ArrowRight,
  Sparkles,
  HelpCircle,
  Mail,
  Phone,
  Building,
  Send,
  ExternalLink,
  Laptop,
} from 'lucide-react';

interface LandingPageProps {
  onOpenSecurityLab?: () => void;
  onOpenCodebase?: () => void;
  onOpenApiDocs?: () => void;
  onNavigateTab?: (tab: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = () => {
  const { t, language } = useLanguage();
  const { login, plans } = useApp();

  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [initialRole, setInitialRole] = useState<Role>('SCHOOL_ADMIN');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  // Contact Form State
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    school: '',
    message: '',
  });
  const [contactSuccess, setContactSuccess] = useState(false);

  // Active Role tab in "Role-based Experience"
  const [activeRoleTab, setActiveRoleTab] = useState<Role>('SCHOOL_ADMIN');

  // Interactive Live Product Preview Tab
  const [previewTab, setPreviewTab] = useState<'dashboard' | 'attendance' | 'routine' | 'fees'>('dashboard');

  const handleOpenLogin = (role?: Role) => {
    if (role) setInitialRole(role);
    setLoginModalOpen(true);
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email) return;
    setContactSuccess(true);
    setTimeout(() => {
      setContactSuccess(false);
      setContactForm({ name: '', email: '', phone: '', school: '', message: '' });
    }, 4500);
  };

  // 12 Major Features Data
  const featuresList = [
    {
      icon: <GraduationCap className="w-5 h-5 text-indigo-600" />,
      title: language === 'bn' ? 'শিক্ষার্থী ভর্তি ও আইডি কার্ড' : 'Student Admission & ID Cards',
      desc: language === 'bn' ? 'ভর্তি নম্বর, রোল, শাখা, রক্তের গ্রুপ ও প্রিন্টযোগ্য বারকোডযুক্ত প্রাতিষ্ঠানিক স্টুডেন্ট আইডি কার্ড।' : 'Complete lifecycle tracking, admission numbers, document filing, and printable photo ID cards.',
      badge: 'Core Student',
    },
    {
      icon: <Users className="w-5 h-5 text-blue-600" />,
      title: language === 'bn' ? 'শিক্ষক ও কর্মচারী ব্যবস্থাপনা' : 'Faculty & Staff Dossier',
      desc: language === 'bn' ? 'শিক্ষকদের পদবী, শিক্ষাগত যোগ্যতা, যোগদান তারিখ, বেতন স্কেল এবং শ্রেণি শিক্ষক পদায়ন।' : 'Staff profiles, academic departments, qualifications, joining records, and class teacher allocations.',
      badge: 'HR & Faculty',
    },
    {
      icon: <CalendarCheck className="w-5 h-5 text-emerald-600" />,
      title: language === 'bn' ? 'দৈনিক ডিজিটাল হাজিরা' : 'Daily Attendance Register',
      desc: language === 'bn' ? 'উপস্থিত, অনুপস্থিত, বিলম্ব ও ছুটি চিহ্নিতকরণ; মাসিক উপস্থিতি শতকরা হার ও রিপোর্ট।' : 'Single-click attendance logging, leave approvals, automated absenteeism alerts, and percentage tracking.',
      badge: 'Attendance',
    },
    {
      icon: <Award className="w-5 h-5 text-amber-600" />,
      title: language === 'bn' ? 'পরীক্ষা, গ্রেডিং ও ট্রান্সক্রিপ্ট' : 'Exams, GPA & Transcripts',
      desc: language === 'bn' ? 'পরীক্ষার সময়সূচি, বিষয়ভিত্তিক নম্বর এন্ট্রি, জিপিএ স্কেল এবং প্রিন্টযোগ্য অফিসিয়াল মার্কশিট।' : 'Exam schedules, mark entries, automated GPA/letter grades, publish controls, and formal printable transcripts.',
      badge: 'Academic',
    },
    {
      icon: <CreditCard className="w-5 h-5 text-rose-600" />,
      title: language === 'bn' ? 'ফি ইনভয়েস ও মানি রিসিট' : 'Fee Invoicing & Payments',
      desc: language === 'bn' ? 'মাসিক বেতন, ভর্তি ফি, আংশিক ও পূর্ণ পরিশোধ, বকেয়া হিসাব এবং অফিসিয়াল মানি রিসিট।' : 'Automated fee schedules, partial & full payment receipts, cash/card/bank channels, and due balances.',
      badge: 'Finance',
    },
    {
      icon: <Clock className="w-5 h-5 text-purple-600" />,
      title: language === 'bn' ? 'স্বয়ংক্রিয় রুটিন ও সংঘাত রোধ' : 'Timetable & Conflict Engine',
      desc: language === 'bn' ? 'কক্ষ ও শিক্ষকের সময়সূচির দ্বৈত সংঘাত সনাক্তকরণসহ আধুনিক সাপ্তাহিক ক্লাস রুটিন।' : 'Intelligent scheduling with real-time room and instructor double-booking conflict detection.',
      badge: 'Timetable',
    },
    {
      icon: <BookOpen className="w-5 h-5 text-cyan-600" />,
      title: language === 'bn' ? 'হোমওয়ার্ক ও অ্যাসাইনমেন্ট' : 'Homework & Submissions',
      desc: language === 'bn' ? 'শ্রেণি ও বিষয়ভিত্তিক অ্যাসাইনমেন্ট তৈরি, জমা দেওয়ার শেষ সময় এবং মূল্যায়ন।' : 'Class targeting, submission deadlines, instructions, and student assignment tracking.',
      badge: 'Learning',
    },
    {
      icon: <Users className="w-5 h-5 text-violet-600" />,
      title: language === 'bn' ? 'অভিভাবক পোর্টাল' : 'Parent Engagement Portal',
      desc: language === 'bn' ? 'একাধিক সন্তানের অগ্রগতি নিরীক্ষণ, দৈনিক হাজিরা নোটিফিকেশন এবং অনলাইন ফি ইনভয়েস।' : 'Multi-child oversight, realtime attendance updates, exam progress, and direct school notices.',
      badge: 'Parent Portal',
    },
    {
      icon: <BookOpen className="w-5 h-5 text-teal-600" />,
      title: language === 'bn' ? 'লাইব্রেরি ও বইয়ের ক্যাটালগ' : 'Library & ISBN Catalog',
      desc: language === 'bn' ? 'বই ইস্যু ও রিটার্ন, তাক নম্বর, আইএসবিএন ট্র্যাকিং ও মজুত কপির স্বয়ংক্রিয় হিসাব।' : 'Book categorization, rack placement, automated copy count depreciation, and loan histories.',
      badge: 'Library',
    },
    {
      icon: <Bus className="w-5 h-5 text-amber-600" />,
      title: language === 'bn' ? 'স্কুল বাস ও পরিবহন বহর' : 'Transport Fleet & Routes',
      desc: language === 'bn' ? 'বাসের রুট, গাড়ির নম্বর, ড্রাইভারের তথ্য ও মাসিক পরিবহন ফি ব্যবস্থাপনা।' : 'Fleet tracking, route stops, driver verification, vehicle registration, and student bus fares.',
      badge: 'Transport',
    },
    {
      icon: <Home className="w-5 h-5 text-orange-600" />,
      title: language === 'bn' ? 'ছাত্রাবাস ও হোস্টেল আবাসন' : 'Hostel & Boarding Facilities',
      desc: language === 'bn' ? 'ভবন, রুম নম্বর, বেড ক্যাপাসিটি এবং শিক্ষার্থী সিট বরাদ্দকরণ।' : 'Dormitory buildings, room capacities, bed allocations, and monthly accommodation fees.',
      badge: 'Hostel',
    },
    {
      icon: <FileText className="w-5 h-5 text-slate-700" />,
      title: language === 'bn' ? 'নিরীক্ষা ও প্রাতিষ্ঠানিক রিপোর্ট' : 'Audits & Analytics Reports',
      desc: language === 'bn' ? 'হাজিরা, ফি আদায়, একাডেমিক ফলাফল এবং প্রাতিষ্ঠানিক অডিট রিপোর্ট এক্সপোর্ট।' : 'Institutional attendance percentages, financial collections, grade spreads, and printable audit packs.',
      badge: 'Reporting',
    },
  ];

  // Role Showcase Data
  const roleShowcases: Record<
    Role,
    {
      title: string;
      roleTitle: string;
      desc: string;
      benefits: string[];
      previewEmail: string;
    }
  > = {
    SUPER_ADMIN: {
      title: language === 'bn' ? 'সুপার অ্যাডমিন প্ল্যাটফর্ম গভর্নেন্স' : 'Super Admin Global Governance',
      roleTitle: language === 'bn' ? 'সাস প্ল্যাটফর্ম নিয়ন্ত্রণকারী' : 'Global SaaS Controller',
      desc: language === 'bn'
        ? 'সকল স্কুলের সামগ্রিক নিবন্ধন, সাবস্ক্রিপশন স্তর, টায়ার লিমিট এবং অপরিবর্তনীয় অডিট ট্রেইল পর্যবেক্ষণ।'
        : 'Manage multi-tenant school onboarding, tier plans, active student quotas, and tamper-proof security audit trails.',
      benefits: [
        language === 'bn' ? 'সকল শিক্ষা প্রতিষ্ঠানের কেন্দ্রীয় পর্যবেক্ষণ' : 'Cross-tenant macro health dashboard',
        language === 'bn' ? 'সাবস্ক্রিপশন প্ল্যান ও কোটা নিয়ন্ত্রণ' : 'Tier quota enforcement (students & faculty limits)',
        language === 'bn' ? 'নিরাপত্তা লগ ও অনুপ্রবেশ পর্যবেক্ষণ' : 'Platform security & cross-tenant violation logging',
        language === 'bn' ? 'প্রতিষ্ঠান সক্রিয়করণ ও স্থগিতকরণ' : 'Tenant lifecycle (active/suspended) switches',
      ],
      previewEmail: 'superadmin@saas-edupulse.com',
    },
    SCHOOL_ADMIN: {
      title: language === 'bn' ? 'স্কুল প্রিন্সিপাল ও প্রাতিষ্ঠানিক অ্যাডমিন' : 'School Principal & Administrative Ops',
      roleTitle: language === 'bn' ? 'বিদ্যালয় প্রশাসন' : 'Institutional Admin',
      desc: language === 'bn'
        ? 'শ্রেণি, শাখা, পাঠ্যক্রম, শিক্ষক নিয়োগ, ফি ইনভয়েস, রুটিন তৈরি ও সার্বিক প্রতিষ্ঠানের পূর্ণ নিয়ন্ত্রণ।'
        : 'Total governance over curricula, staff salaries, fee invoicing, student admissions, timetable generation, and reports.',
      benefits: [
        language === 'bn' ? 'শ্রেণি, শাখা ও বিষয় কাঠামো পরিচালনা' : 'Academic structure (Classes, Sections, Subjects)',
        language === 'bn' ? 'শিক্ষক ও কর্মচারী প্রোফাইল ও বেতন' : 'Faculty roster & designations management',
        language === 'bn' ? 'ফি ইনভয়েস তৈরি ও মানি রিসিট প্রদান' : 'Fee invoice issuing & payment collections',
        language === 'bn' ? 'রুটিন সংঘাত রোধ ইঞ্জিন ব্যবহার' : 'Timetable scheduling with conflict auto-detection',
      ],
      previewEmail: 'admin@greenwood.edu',
    },
    TEACHER: {
      title: language === 'bn' ? 'শিক্ষকদের জন্য সমৃদ্ধ একাডেমিক ওয়ার্কস্পেস' : 'Faculty Workspace & Classroom Tools',
      roleTitle: language === 'bn' ? 'শ্রেণি ও বিষয় শিক্ষক' : 'Class & Subject Educator',
      desc: language === 'bn'
        ? 'এক ক্লিকে দৈনিক উপস্থিতি গ্রহণ, পরীক্ষার নম্বর প্রদান, হোমওয়ার্ক বিতরণ ও নিজস্ব ক্লাস রুটিন দেখা।'
        : 'Mark attendance for assigned grades, submit exam marks, create homework assignments, and review daily teaching periods.',
      benefits: [
        language === 'bn' ? 'দ্রুত শ্রেণিভিত্তিক হাজিরা গ্রহণ' : 'Rapid single-click daily roll-call attendance',
        language === 'bn' ? 'পরীক্ষার নম্বর দাখিল ও মার্কশিট অনুমোদন' : 'Subject mark entry with instant GPA calculation',
        language === 'bn' ? 'হোমওয়ার্ক ও অ্যাসাইনমেন্ট প্রকাশ' : 'Homework task publishing with deadlines',
        language === 'bn' ? 'ব্যক্তিগত সময়সূচি ও ক্লাসের তালিকা' : 'Personalized teacher timetable & subject slots',
      ],
      previewEmail: 'teacher.sarah@greenwood.edu',
    },
    STUDENT: {
      title: language === 'bn' ? 'শিক্ষার্থীদের ডিজিটাল স্টুডেন্ট পোর্টাল' : 'Student Academic Hub & Digital ID',
      roleTitle: language === 'bn' ? 'নথিভুক্ত শিক্ষার্থী' : 'Enrolled Student',
      desc: language === 'bn'
        ? 'ডিজিটাল আইডি কার্ড ডাউনলোড, ক্লাস রুটিন, পরীক্ষার ট্রান্সক্রিপ্ট, ফি বকেয়া তথ্য ও হোমওয়ার্ক নোটিশ।'
        : 'Access official student photo ID cards, daily timetable, examination marks, fee receipts, and school library loans.',
      benefits: [
        language === 'bn' ? 'প্রিন্টযোগ্য ডিজিটাল স্টুডেন্ট আইডি কার্ড' : 'Downloadable high-res student identity card',
        language === 'bn' ? 'দৈনিক ক্লাস রুটিন ও সময়সূচি' : 'Timetable breakdown by day and subject',
        language === 'bn' ? 'পরীক্ষার মার্কশিট ও জিপিএ ফলাফল' : 'Formal academic transcripts and grade breakdown',
        language === 'bn' ? 'হোমওয়ার্ক ও প্রাতিষ্ঠানিক বিজ্ঞপ্তি' : 'Homework instructions and noticeboard access',
      ],
      previewEmail: 'student.alex@greenwood.edu',
    },
    PARENT: {
      title: language === 'bn' ? 'অভিভাবকদের জন্য স্বচ্ছ ও নির্ভরযোগ্য পোর্টাল' : 'Guardian Portal & Multi-Child Monitoring',
      roleTitle: language === 'bn' ? 'পিতা/মাতা বা অভিভাবক' : 'Parent / Legal Guardian',
      desc: language === 'bn'
        ? 'সন্তানের দৈনিক উপস্থিতি পর্যবেক্ষণ, পরীক্ষার ফলাফল ও গ্রেড দেখা, এবং স্কুলের নোটিশ তাৎক্ষণিক গ্রহণ।'
        : 'Track child daily attendance records, review academic report cards, inspect tuition invoices, and read school notices.',
      benefits: [
        language === 'bn' ? 'সন্তানের উপস্থিতির লাইভ রেকর্ড' : 'Live attendance tracking and percentage indicators',
        language === 'bn' ? 'একাডেমিক ফলাফল ও পরীক্ষার মার্কশিট' : 'Term exam scores and cumulative GPA view',
        language === 'bn' ? 'টিউশন ফি ইনভয়েস ও অর্থ প্রদানের ইতিহাস' : 'Fee invoice breakdowns and official receipt history',
        language === 'bn' ? 'বিদ্যালয়ের সরাসরি জরুরি নোটিশ' : 'Direct institutional announcements and alerts',
      ],
      previewEmail: 'parent.robert@greenwood.edu',
    },
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans selection:bg-indigo-600 selection:text-white">
      {/* 1. Header / Navbar */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-lg shadow-sm shadow-indigo-200">
              EP
            </div>
            <div>
              <span className="font-extrabold text-lg text-slate-900 tracking-tight flex items-center gap-1.5">
                EduPulse <span className="text-indigo-600">SaaS</span>
              </span>
              <span className="block text-[10px] font-medium text-slate-500 uppercase tracking-widest">
                {language === 'bn' ? 'আধুনিক স্কুল ম্যানেজমেন্ট' : 'Modern School SaaS'}
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-xs font-semibold text-slate-600">
            <a href="#features" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'ফিচারসমূহ' : 'Features'}
            </a>
            <a href="#portals" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'ভূমিকা পোর্টাল' : 'Role Portals'}
            </a>
            <a href="#architecture" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'মাল্টি-টেন্যান্সি' : 'Architecture'}
            </a>
            <a href="#mobile" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'মোবাইল ও এপিআই' : 'Mobile & API'}
            </a>
            <a href="#pricing" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'মূল্য তালিকা' : 'Pricing'}
            </a>
            <a href="#faq" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'প্রশ্নোত্তর' : 'FAQ'}
            </a>
            <a href="#contact" className="hover:text-indigo-600 transition-colors">
              {language === 'bn' ? 'যোগাযোগ' : 'Contact'}
            </a>
          </nav>

          {/* Right Action buttons */}
          <div className="flex items-center gap-3">
            <LanguageSelector variant="light" />

            <button
              onClick={() => handleOpenLogin()}
              className="px-3.5 py-2 text-xs font-bold text-slate-700 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              {language === 'bn' ? 'লগইন' : 'Sign In'}
            </button>

            <button
              onClick={() => handleOpenLogin('SCHOOL_ADMIN')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm shadow-indigo-200 transition-all hover:shadow-indigo-300 flex items-center gap-1.5"
            >
              <span>{language === 'bn' ? 'লাইভ ডেমো দেখুন' : 'Live Demo'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-radial from-indigo-50/70 via-white to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-semibold mb-6 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>{t('heroBadge')}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.15]">
              {t('heroTitle')}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-indigo-700 to-cyan-600">
                {t('heroHighlight')}
              </span>
            </h1>

            {/* Subtitle */}
            <p className="mt-6 text-sm sm:text-base lg:text-lg text-slate-600 max-w-2xl mx-auto leading-relaxed">
              {t('heroSubtitle')}
            </p>

            {/* CTA Group */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={() => handleOpenLogin('SCHOOL_ADMIN')}
                className="w-full sm:w-auto px-6 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-300/40 transition-all hover:-translate-y-0.5 flex items-center justify-center gap-2"
              >
                <span>{t('heroCtaStart')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const el = document.getElementById('contact');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="w-full sm:w-auto px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-800 font-bold text-sm rounded-xl border border-slate-200 shadow-xs transition-all flex items-center justify-center gap-2"
              >
                <span>{t('heroCtaDemo')}</span>
              </button>
            </div>

            {/* Key Metrics Strip */}
            <div className="mt-14 pt-8 border-t border-slate-200/80 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">250+</div>
                <div className="text-xs text-slate-500 font-medium mt-1">{t('statsSchools')}</div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-indigo-600 tracking-tight">120k+</div>
                <div className="text-xs text-slate-500 font-medium mt-1">{t('statsStudents')}</div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">99.98%</div>
                <div className="text-xs text-slate-500 font-medium mt-1">{t('statsUptime')}</div>
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 tracking-tight">100%</div>
                <div className="text-xs text-slate-500 font-medium mt-1">{t('statsSecurity')}</div>
              </div>
            </div>
          </div>

          {/* Interactive Live Product Preview Showcase */}
          <div className="mt-12 bg-slate-900 rounded-2xl shadow-2xl border border-slate-800 p-2 sm:p-4 overflow-hidden">
            {/* Mockup Topbar */}
            <div className="flex items-center justify-between pb-3 px-3 border-b border-slate-800 text-slate-400 text-xs">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500"></div>
                  <div className="w-3 h-3 rounded-full bg-amber-500"></div>
                  <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                </div>
                <span className="font-mono text-[11px] text-slate-400 ml-2">
                  https://app.edupulse.cloud/greenwood/dashboard
                </span>
              </div>

              {/* Tabs for Preview */}
              <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg">
                <button
                  onClick={() => setPreviewTab('dashboard')}
                  className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                    previewTab === 'dashboard' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'bn' ? 'ড্যাশবোর্ড' : 'Executive Overview'}
                </button>
                <button
                  onClick={() => setPreviewTab('attendance')}
                  className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                    previewTab === 'attendance' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'bn' ? 'হাজিরা' : 'Attendance'}
                </button>
                <button
                  onClick={() => setPreviewTab('routine')}
                  className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                    previewTab === 'routine' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'bn' ? 'ক্লাস রুটিন' : 'Routine Engine'}
                </button>
                <button
                  onClick={() => setPreviewTab('fees')}
                  className={`px-2.5 py-1 rounded text-[11px] font-semibold transition-colors ${
                    previewTab === 'fees' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {language === 'bn' ? 'ফি ও ইনভয়েস' : 'Fee Invoicing'}
                </button>
              </div>
            </div>

            {/* Inner Dashboard Mockup Area */}
            <div className="p-4 sm:p-6 bg-slate-950 text-white rounded-xl mt-3 min-h-[340px]">
              {previewTab === 'dashboard' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-2">
                        <School className="w-4 h-4 text-indigo-400" />
                        Greenwood International Academy
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {language === 'bn'
                          ? 'বর্তমান শিক্ষাবর্ষ: ২০২৬-২০২৭ · টেন্যান্ট কোড: GIA · এন্টারপ্রাইজ প্ল্যান'
                          : 'Academic Year: 2026-2027 · Tenant Code: GIA · Enterprise Tier'}
                      </div>
                    </div>
                    <button
                      onClick={() => handleOpenLogin('SCHOOL_ADMIN')}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                    >
                      <span>{language === 'bn' ? 'সরাসরি ড্যাশবোর্ডে প্রবেশ' : 'Launch Full System'}</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <div className="text-[11px] text-slate-400">Total Enrolled</div>
                      <div className="text-xl font-bold text-white mt-1">450 Students</div>
                      <div className="text-[10px] text-emerald-400 mt-0.5">↑ 100% Active</div>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <div className="text-[11px] text-slate-400">Faculty Members</div>
                      <div className="text-xl font-bold text-white mt-1">28 Teachers</div>
                      <div className="text-[10px] text-indigo-400 mt-0.5">9 Departments</div>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <div className="text-[11px] text-slate-400">Fee Collection</div>
                      <div className="text-xl font-bold text-emerald-400 mt-1">$4,820</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">85% Paid on time</div>
                    </div>
                    <div className="p-3 bg-slate-900 border border-slate-800 rounded-lg">
                      <div className="text-[11px] text-slate-400">Attendance Today</div>
                      <div className="text-xl font-bold text-cyan-400 mt-1">94.8%</div>
                      <div className="text-[10px] text-emerald-400 mt-0.5">Above target</div>
                    </div>
                  </div>

                  {/* Sample rows */}
                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-3">
                    <div className="text-xs font-semibold text-slate-300 mb-2">Recent Campus Activities</div>
                    <div className="space-y-2 text-xs">
                      <div className="flex items-center justify-between text-slate-300 py-1 border-b border-slate-800/80">
                        <span className="flex items-center gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          Grade 10-A Mathematics attendance finalized by Ms. Sarah Jenkins
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">10:45 AM</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-300 py-1 border-b border-slate-800/80">
                        <span className="flex items-center gap-2">
                          <CreditCard className="w-3.5 h-3.5 text-indigo-400" />
                          Tuition fee payment recorded for Student Alex Rivera ($450)
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">09:30 AM</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-300 py-1">
                        <span className="flex items-center gap-2">
                          <Lock className="w-3.5 h-3.5 text-teal-400" />
                          ThreadLocal TenantContext verified for request thread
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">Active</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {previewTab === 'attendance' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-semibold text-slate-300">Grade 10-A Daily Roll Call Register</div>
                    <span className="text-[11px] text-emerald-400 font-bold bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded">
                      94% Present Today
                    </span>
                  </div>
                  <div className="space-y-1.5 font-mono text-xs">
                    <div className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span>Alex Rivera (Roll 01)</span>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        PRESENT
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span>Emma Watson (Roll 02)</span>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        PRESENT
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800">
                      <span>Liam Johnson (Roll 03)</span>
                      <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        LATE (15m)
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {previewTab === 'routine' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-semibold text-slate-300">Routine Engine & Timetable Conflict Check</div>
                    <span className="text-[11px] text-indigo-400 font-mono bg-indigo-950/50 border border-indigo-800 px-2 py-0.5 rounded">
                      Zero Conflicts Detected
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                      <div className="font-bold text-indigo-400">09:00 - 09:45 AM</div>
                      <div className="text-white font-semibold mt-1">Mathematics</div>
                      <div className="text-[10px] text-slate-400">Room 301 · Ms. Sarah Jenkins</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                      <div className="font-bold text-cyan-400">10:00 - 10:45 AM</div>
                      <div className="text-white font-semibold mt-1">Physics & Mechanics</div>
                      <div className="text-[10px] text-slate-400">Science Lab 2 · Dr. Marcus Vance</div>
                    </div>
                    <div className="p-2.5 bg-slate-900 border border-slate-800 rounded">
                      <div className="font-bold text-emerald-400">11:00 - 11:45 AM</div>
                      <div className="text-white font-semibold mt-1">English Literature</div>
                      <div className="text-[10px] text-slate-400">Room 204 · Mr. David Ross</div>
                    </div>
                  </div>
                </div>
              )}

              {previewTab === 'fees' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-semibold text-slate-300">Automated Tuition Invoicing & Receipt Ledger</div>
                    <span className="text-[11px] text-emerald-400 font-bold">100% Tax Compliant</span>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex items-center justify-between p-2.5 bg-slate-900 border border-slate-800 rounded">
                      <div>
                        <div className="font-bold text-white">INV-2026-001 · Alex Rivera</div>
                        <div className="text-[10px] text-slate-400">Term 1 Tuition & Laboratory Fee</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-emerald-400">$450.00</div>
                        <div className="text-[10px] text-emerald-300">PAID IN FULL</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-2.5 bg-slate-900 border border-slate-800 rounded">
                      <div>
                        <div className="font-bold text-white">INV-2026-002 · Sophia Chen</div>
                        <div className="text-[10px] text-slate-400">Term 1 Tuition & Transport Route 4</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-amber-400">$520.00</div>
                        <div className="text-[10px] text-amber-300">DUE IN 10 DAYS</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 3. Features Grid Section */}
      <section id="features" className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              {t('featuresBadge')}
            </span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {t('featuresTitle')}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              {t('featuresSubtitle')}
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuresList.map((item, idx) => (
              <div
                key={idx}
                className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all hover:-translate-y-1 group"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2.5 rounded-xl bg-slate-50 group-hover:bg-indigo-50 transition-colors">
                    {item.icon}
                  </div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider font-mono">
                    {item.badge}
                  </span>
                </div>
                <h3 className="font-bold text-base text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {item.title}
                </h3>
                <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Role-based Experience Showcase */}
      <section id="portals" className="py-20 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              {language === 'bn' ? 'ভূমিকাভিত্তিক পোর্টাল' : 'Role-Based Experience'}
            </span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {t('roleExperienceTitle')}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              {t('roleExperienceSubtitle')}
            </p>
          </div>

          {/* Role selection tab buttons */}
          <div className="mt-10 flex flex-wrap justify-center gap-2">
            {(['SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT'] as Role[]).map(r => (
              <button
                key={r}
                onClick={() => setActiveRoleTab(r)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeRoleTab === r
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {r === 'SUPER_ADMIN' && (language === 'bn' ? '১. সুপার অ্যাডমিন' : '1. Super Admin')}
                {r === 'SCHOOL_ADMIN' && (language === 'bn' ? '২. স্কুল অ্যাডমিন' : '2. School Admin')}
                {r === 'TEACHER' && (language === 'bn' ? '৩. শিক্ষক' : '3. Teacher')}
                {r === 'STUDENT' && (language === 'bn' ? '৪. শিক্ষার্থী' : '4. Student')}
                {r === 'PARENT' && (language === 'bn' ? '৫. অভিভাবক' : '5. Parent')}
              </button>
            ))}
          </div>

          {/* Role Showcase Display Card */}
          <div className="mt-8 max-w-4xl mx-auto bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-3xl p-6 sm:p-10 border border-slate-800 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-4 max-w-xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-400/30">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{roleShowcases[activeRoleTab].roleTitle}</span>
                </div>
                <h3 className="text-2xl font-bold text-white tracking-tight">
                  {roleShowcases[activeRoleTab].title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {roleShowcases[activeRoleTab].desc}
                </p>

                <div className="space-y-2 pt-2">
                  {roleShowcases[activeRoleTab].benefits.map((b, i) => (
                    <div key={i} className="flex items-center gap-2.5 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{b}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-800/80 border border-slate-700/80 p-5 rounded-2xl shrink-0 sm:w-72 space-y-4">
                <div className="text-xs font-semibold text-slate-300">
                  {language === 'bn' ? 'ইনস্ট্যান্ট রোল টেস্ট' : 'Launch Instant Session'}
                </div>
                <div className="text-[11px] text-slate-400 font-mono bg-slate-900/90 p-2.5 rounded-lg border border-slate-700/50 break-all">
                  {roleShowcases[activeRoleTab].previewEmail}
                </div>
                <button
                  onClick={() => {
                    login(activeRoleTab, roleShowcases[activeRoleTab].previewEmail);
                  }}
                  className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <span>{language === 'bn' ? 'এই ভূমিকায় প্রবেশ করুন' : 'Test This Role'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. SaaS Architecture & Multi-Tenancy Benefits */}
      <section id="architecture" className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              Enterprise Multi-Tenancy
            </span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {t('saasBenefitsTitle')}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              {t('saasBenefitsSubtitle')}
            </p>
          </div>

          <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600 mb-4">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base text-slate-900">
                {language === 'bn' ? 'কঠোর টেন্যান্ট আইসোলেশন' : 'Strict Tenant Isolation'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'প্রতিটি ডাটাবেস কোয়েরিতে tenant_id কঠোরভাবে ফিল্টার করা হয়। কোনো স্কুল অন্য স্কুলের কোনো রেকর্ড কখনই দেখতে পাবে না।'
                  : 'ThreadLocal TenantContext enforces tenant_id boundaries at the JPA repository, service, and API controller layers with zero leak.'}
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-emerald-600 mb-4">
                <Shield className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base text-slate-900">
                {language === 'bn' ? 'অপরিবর্তনীয় অডিট ট্রেইল' : 'Immutable Audit Trails'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'প্রতিটি সংবেদনশীল পরিবর্তন, ফলাফল প্রকাশ, ফি আদায় ও রোল পরিবর্তনের অডিট লগ সংরক্ষিত হয়।'
                  : 'Every database mutation, login attempt, cross-tenant check, and role assumption is stored in an immutable audit ledger.'}
              </p>
            </div>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-cyan-100 flex items-center justify-center text-cyan-600 mb-4">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-base text-slate-900">
                {language === 'bn' ? 'টায়ার কোটা ও সীমা নিয়ন্ত্রণ' : 'Subscription Quota Limits'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'প্ল্যানের অনুমোদিত শিক্ষার্থী ও শিক্ষকের কোটা অতিক্রম করলে ব্যাকএন্ড স্বয়ংক্রিয়ভাবে সীমা প্রয়োগ করে।'
                  : 'Automatic backend limit enforcement prevents exceeding plan quotas on students, staff, and storage without upgrade.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Mobile & Android Readiness Section */}
      <section id="mobile" className="py-20 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
                {t('mobileBadge')}
              </span>
              <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                {t('mobileTitle')}
              </h2>
              <p className="mt-4 text-sm text-slate-600 leading-relaxed">
                {t('mobileSubtitle')}
              </p>

              <div className="mt-6 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 mt-0.5">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {language === 'bn' ? 'সম্পূর্ণ স্টেটলেস রেস্ট এপিআই (REST API)' : 'Stateless Spring Boot 3 RESTful APIs'}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {language === 'bn'
                        ? 'জেডাব্লিউটি (JWT) টোকেনভিত্তিক অ্যাথেনটিকেশন ও টেন্যান্ট হেডারের মাধ্যমে সহজ মোবাইল ইন্টিগ্রেশন।'
                        : 'Standard Bearer tokens and X-Tenant-ID headers allow seamless Android Retrofit/OkHttp clients.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 mt-0.5">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {language === 'bn' ? 'পুশ নোটিফিকেশন ও অফলাইন প্রস্তুত' : 'Push Notifications & Parent Alerts'}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {language === 'bn'
                        ? 'হাজিরা অনুপস্থিতি, পরীক্ষার গ্রেড ও ফি নোটিশ তাৎক্ষণিকভাবে অভিভাবকদের মোবাইলে প্রেরণ।'
                        : 'Webhooks and notification event endpoints ready for Firebase Cloud Messaging (FCM).'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-600 mt-0.5">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {language === 'bn' ? 'ওপেনএপিআই / সোয়াগার ডকুমেন্টেশন' : 'OpenAPI / Swagger Compliant'}
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      {language === 'bn'
                        ? 'অ্যান্ড্রয়েড ডেভেলপারদের জন্য স্বয়ংক্রিয় মডেল ও কন্ট্রোলার স্কিমা উপলব্ধ।'
                        : 'Easily generate Kotlin / Retrofit data models directly from the backend specification.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Mobile Visual Simulation */}
            <div className="flex justify-center">
              <div className="w-72 bg-slate-950 p-3 rounded-[36px] shadow-2xl border-4 border-slate-800">
                <div className="h-6 w-28 bg-slate-800 mx-auto rounded-full mb-3"></div>
                <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-3">
                  <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800">
                    <span className="font-bold flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
                      EduPulse Mobile
                    </span>
                    <span className="text-[10px] text-slate-400">Student App</span>
                  </div>

                  <div className="p-3 bg-indigo-950/40 border border-indigo-800/60 rounded-xl">
                    <div className="text-[10px] text-indigo-300 uppercase font-semibold">Today's First Period</div>
                    <div className="text-xs font-bold text-white mt-0.5">Mathematics · Room 301</div>
                    <div className="text-[10px] text-slate-400 mt-1">09:00 AM - 09:45 AM</div>
                  </div>

                  <div className="space-y-1.5 text-xs">
                    <div className="text-[11px] font-semibold text-slate-400">Quick Services</div>
                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2 bg-slate-800/80 rounded-lg text-center font-medium">
                        Student ID
                      </div>
                      <div className="p-2 bg-slate-800/80 rounded-lg text-center font-medium">
                        Report Card
                      </div>
                      <div className="p-2 bg-slate-800/80 rounded-lg text-center font-medium">
                        Homework
                      </div>
                      <div className="p-2 bg-slate-800/80 rounded-lg text-center font-medium">
                        Pay Tuition
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Pricing Section */}
      <section id="pricing" className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              {t('pricingTitle')}
            </span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {language === 'bn' ? 'আপনার স্কুলের জন্য মানানসই সাবস্ক্রিপশন প্ল্যান' : 'Predictable Pricing for Growing Institutions'}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              {t('pricingSubtitle')}
            </p>

            {/* Billing cycle switcher */}
            <div className="mt-8 inline-flex items-center p-1 bg-slate-200/80 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-1.5 rounded-lg transition-colors ${
                  billingCycle === 'monthly' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                {t('monthly')}
              </button>
              <button
                onClick={() => setBillingCycle('annual')}
                className={`px-4 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${
                  billingCycle === 'annual' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                <span>{t('annual')}</span>
              </button>
            </div>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map(p => {
              const isPopular = p.code === 'BASIC';
              const price = billingCycle === 'annual' ? Math.round(p.pricePerMonth * 0.8) : p.pricePerMonth;

              return (
                <div
                  key={p.id}
                  className={`bg-white rounded-3xl p-8 border transition-all relative flex flex-col justify-between ${
                    isPopular
                      ? 'border-indigo-600 ring-2 ring-indigo-600/20 shadow-xl'
                      : 'border-slate-200 shadow-xs hover:shadow-md'
                  }`}
                >
                  {isPopular && (
                    <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[11px] font-bold px-3 py-0.5 rounded-full uppercase tracking-wider shadow">
                      {t('popular')}
                    </div>
                  )}

                  <div>
                    <h3 className="text-xl font-bold text-slate-900">{p.name}</h3>
                    <p className="mt-1 text-xs text-slate-500">
                      {p.code === 'FREE' && (language === 'bn' ? 'ছোট স্কুল ও ট্রায়ালের জন্য উপযুক্ত' : 'Free tier for trial & pilot schools')}
                      {p.code === 'BASIC' && (language === 'bn' ? 'মাঝারি স্কুল ও কলেজের পূর্ণাঙ্গ সমাধান' : 'Standard institutional management')}
                      {p.code === 'PREMIUM' && (language === 'bn' ? 'বৃহৎ স্কুল নেটওয়ার্ক ও বিশ্ববিদ্যালয়' : 'Elite multi-branch governance')}
                    </p>

                    <div className="mt-6 flex items-baseline gap-1">
                      <span className="text-4xl font-extrabold text-slate-900">${price}</span>
                      <span className="text-xs text-slate-500">{t('perMonth')}</span>
                    </div>

                    <div className="mt-6 pt-6 border-t border-slate-100 space-y-3 text-xs">
                      <div className="flex items-center gap-2 text-slate-700">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>Up to {p.maxStudents.toLocaleString()} Students</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>Up to {p.maxTeachers} Faculty Staff</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>Attendance, Exams & GPA Reports</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>Fee Invoices & Receipt Printing</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-700">
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span>Timetable Conflict Detection</span>
                      </div>
                      {p.modulesEnabled?.includes('PARENT_PORTAL') && (
                        <div className="flex items-center gap-2 text-slate-700">
                          <Check className="w-4 h-4 text-emerald-600" />
                          <span>Dedicated Parent Portal</span>
                        </div>
                      )}
                      {p.modulesEnabled?.includes('AUDIT_LOGS') && (
                        <div className="flex items-center gap-2 text-slate-700">
                          <Check className="w-4 h-4 text-emerald-600" />
                          <span>Immutable Security Audit Logs</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => handleOpenLogin('SCHOOL_ADMIN')}
                    className={`mt-8 w-full py-3 px-4 rounded-xl text-xs font-bold transition-all shadow-xs ${
                      isPopular
                        ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-900'
                    }`}
                  >
                    {t('selectPlan')}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 8. Institutional Testimonials */}
      <section className="py-20 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              Customer Trust
            </span>
            <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {t('testimonialsTitle')}
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              {t('testimonialsSubtitle')}
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200/80">
              <div className="text-xs text-amber-500 mb-3">★★★★★</div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                {language === 'bn'
                  ? '"এডুপালস আমাদের স্কুলের উপস্থিতি এবং ফি আদায় প্রক্রিয়াকে সম্পূর্ণ বদলে দিয়েছে। রুটিন সংঘাত রোধ ইঞ্জিনটি এক কথায় অসাধারণ!"'
                  : '"EduPulse completely transformed our attendance roll call and tuition collection. The automated routine conflict engine saved us countless hours during semester planning."'}
              </p>
              <div className="mt-4 pt-4 border-t border-slate-200 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                  DR
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Dr. Robert Henderson</div>
                  <div className="text-[10px] text-slate-500">Principal, Cambridge Grammar School</div>
                </div>
              </div>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200/80">
              <div className="text-xs text-amber-500 mb-3">★★★★★</div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                {language === 'bn'
                  ? '"মাল্টি-টেন্যান্ট ডেটা নিরাপত্তা এবং বাংলা ভাষার পূর্ণাঙ্গ সমর্থন আমাদের আন্তর্জাতিক প্রতিষ্ঠানের জন্য সবচেয়ে সুবিধাজনক ছিল।"'
                  : '"The strict multi-tenant isolation and complete bilingual Bangla/English support made this the obvious choice for our bilingual institution."'}
              </p>
              <div className="mt-4 pt-4 border-t border-slate-200 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-xs">
                  MA
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Mahmudul Amin</div>
                  <div className="text-[10px] text-slate-500">Managing Director, South Breeze Academy</div>
                </div>
              </div>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200/80">
              <div className="text-xs text-amber-500 mb-3">★★★★★</div>
              <p className="text-xs text-slate-700 leading-relaxed italic">
                {language === 'bn'
                  ? '"অভিভাবকরা তাদের সন্তানের দৈনিক উপস্থিতি ও পরীক্ষার গ্রেড সরাসরি দেখতে পেয়ে স্কুলের ওপর আস্থা দ্বিগুণ হয়েছে।"'
                  : '"Parents rave about the transparency. Getting their child\'s real-time attendance status and report card GPA directly in the portal improved engagement tenfold."'}
              </p>
              <div className="mt-4 pt-4 border-t border-slate-200 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-cyan-100 text-cyan-700 font-bold flex items-center justify-center text-xs">
                  SL
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Sarah Lin</div>
                  <div className="text-[10px] text-slate-500">Academic Dean, Oakridge Global Academy</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 9. FAQ Section */}
      <section id="faq" className="py-20 bg-slate-50 border-t border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              FAQ
            </span>
            <h2 className="mt-4 text-3xl font-extrabold text-slate-900 tracking-tight">
              {t('faqTitle')}
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              {t('faqSubtitle')}
            </p>
          </div>

          <div className="space-y-4">
            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="font-bold text-sm text-slate-900">
                {language === 'bn'
                  ? 'কীভাবে একাধিক স্কুলের ডেটা পৃথক ও নিরাপদ রাখা হয়?'
                  : 'How does EduPulse guarantee multi-tenant data isolation between schools?'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'আমাদের ব্যাকএন্ড স্প্রিং বুট ৩ থ্রেডলোকাল (ThreadLocal) টেন্যান্ট কন্টেক্সট এবং প্রতিটি ডাটাবেস কোয়েরিতে কঠোর tenant_id প্রয়োগ করে। এক স্কুলের টোকেন দিয়ে অন্য স্কুলের ডেটা অ্যাক্সেসের চেষ্টা করলে সিস্টেম তা সাথে সাথে প্রতিরোধ করে অডিট লগে সংরক্ষণ করে।'
                  : 'Every HTTP request is authenticated and bound to a ThreadLocal TenantContext. All database queries automatically filter by tenant_id. Cross-tenant access is immediately blocked with a 403 status code and recorded in the audit log.'}
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="font-bold text-sm text-slate-900">
                {language === 'bn'
                  ? 'সিস্টেমটি কি বাংলা ও ইংরেজি উভয় ভাষায় কাজ করে?'
                  : 'Does EduPulse fully support both English and Bengali (বাংলা)?'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'হ্যাঁ, নেভিগেশন বার, ড্যাশবোর্ড, স্টুডেন্ট প্রোফাইল, পরীক্ষার মার্কশিট, ফি রসিদ এবং নোটিশ বোর্ড সহ সম্পূর্ণ সিস্টেম ১০০% দ্বিভাষিক (Bilingual)।'
                  : 'Yes! The entire application UI, navigation, forms, receipts, report cards, and notices can be toggled between English and Bangla at any time.'}
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="font-bold text-sm text-slate-900">
                {language === 'bn'
                  ? 'ভবিষ্যতে অ্যান্ড্রয়েড মোবাইল অ্যাপের সাথে এটি সংযুক্ত করা যাবে?'
                  : 'Can this be integrated with future native Android / iOS mobile applications?'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'অবশ্যই। আমাদের ব্যাকএন্ড একটি পিওর রেস্টফুল এপিআই (REST API) আর্কিটেকচার যা মোবাইল ক্লায়েন্টদের জন্য সরাসরি প্রস্তুত।'
                  : 'Absolutely. The platform is designed API-first with stateless Spring Boot 3 endpoints, JWT security, and OpenAPI documentation ready for Kotlin/Android clients.'}
              </p>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-slate-200">
              <h3 className="font-bold text-sm text-slate-900">
                {language === 'bn'
                  ? 'একজন অভিভাবক কি একাধিক সন্তানের অগ্রগতি এক অ্যাকাউন্টে দেখতে পারবেন?'
                  : 'Can parents manage multiple children enrolled in different grades?'}
              </h3>
              <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                {language === 'bn'
                  ? 'হ্যাঁ, অভিভাবক পোর্টালে একই অ্যাকাউন্টের অধীনে একাধিক সন্তানের হাজিরা, রেজাল্ট ও ফি ইনভয়েস ট্র্যাক করা যায়।'
                  : 'Yes. Guardian profiles support multiple children links, allowing parents to switch between children to inspect individual attendance, exams, and tuition fees.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 10. Contact / Institutional Demo Request Section */}
      <section id="contact" className="py-20 bg-white border-t border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-full">
              Get In Touch
            </span>
            <h2 className="mt-4 text-3xl font-extrabold text-slate-900 tracking-tight">
              {t('contactTitle')}
            </h2>
            <p className="mt-3 text-sm text-slate-600">
              {t('contactSubtitle')}
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-8 sm:p-10 rounded-3xl shadow-xs">
            {contactSuccess ? (
              <div className="text-center py-8 space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">{t('contactSent')}</h3>
                <p className="text-xs text-slate-500">
                  {language === 'bn'
                    ? 'আমাদের একজন শিক্ষা টেকনোলজি বিশেষজ্ঞ আপনার দেওয়া ঠিকানায় যোগাযোগ করবেন।'
                    : 'Our education implementation team will review your institution requirements.'}
                </p>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {t('contactName')} *
                    </label>
                    <input
                      type="text"
                      required
                      value={contactForm.name}
                      onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
                      placeholder="e.g. Dr. Arthur Pendelton"
                      className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {t('contactEmail')} *
                    </label>
                    <input
                      type="email"
                      required
                      value={contactForm.email}
                      onChange={e => setContactForm({ ...contactForm, email: e.target.value })}
                      placeholder="principal@academy.edu"
                      className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {t('contactSchool')}
                    </label>
                    <input
                      type="text"
                      value={contactForm.school}
                      onChange={e => setContactForm({ ...contactForm, school: e.target.value })}
                      placeholder="Greenwood Academy"
                      className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {t('contactPhone')}
                    </label>
                    <input
                      type="tel"
                      value={contactForm.phone}
                      onChange={e => setContactForm({ ...contactForm, phone: e.target.value })}
                      placeholder="+1 (555) 234-5678"
                      className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t('contactMessage')}
                  </label>
                  <textarea
                    rows={3}
                    value={contactForm.message}
                    onChange={e => setContactForm({ ...contactForm, message: e.target.value })}
                    placeholder={
                      language === 'bn'
                        ? 'আপনার প্রতিষ্ঠানের মোট শিক্ষার্থী সংখ্যা ও কাঙ্ক্ষিত মডিউল সম্পর্কে লিখুন...'
                        : 'Tell us about your institution, student count, and key modules needed...'
                    }
                    className="w-full text-xs px-3.5 py-2.5 border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 bg-white"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{t('contactSend')}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* 11. SaaS Footer */}
      <footer className="bg-slate-950 text-slate-400 py-14 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 pb-12 border-b border-slate-800/80">
            {/* Brand column */}
            <div className="col-span-2 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm">
                  EP
                </div>
                <span className="text-white font-bold text-base tracking-tight">EduPulse SaaS</span>
              </div>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                {t('taglineDesc')}
              </p>
              <div className="pt-2">
                <LanguageSelector variant="dark" />
              </div>
            </div>

            {/* Column 2: Product */}
            <div className="space-y-3 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">{t('footerProduct')}</div>
              <ul className="space-y-2">
                <li><a href="#features" className="hover:text-white transition-colors">{t('footerFeatures')}</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">{t('footerPricing')}</a></li>
                <li><a href="#portals" className="hover:text-white transition-colors">Role Portals</a></li>
                <li><a href="#mobile" className="hover:text-white transition-colors">Mobile APIs</a></li>
              </ul>
            </div>

            {/* Column 3: Platform */}
            <div className="space-y-3 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Architecture</div>
              <ul className="space-y-2">
                <li><a href="#architecture" className="hover:text-white transition-colors">Multi-Tenancy</a></li>
                <li><a href="#architecture" className="hover:text-white transition-colors">Security Model</a></li>
                <li><a href="#faq" className="hover:text-white transition-colors">{t('footerDocs')}</a></li>
                <li><button onClick={() => handleOpenLogin()} className="hover:text-white transition-colors text-left">Login Portal</button></li>
              </ul>
            </div>

            {/* Column 4: Legal & Contact */}
            <div className="space-y-3 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Compliance</div>
              <ul className="space-y-2">
                <li><a href="#contact" className="hover:text-white transition-colors">{t('footerPrivacy')}</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">{t('footerTerms')}</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">{t('footerContact')}</a></li>
                <li><span className="text-slate-500">ISO 27001 Ready</span></li>
              </ul>
            </div>
          </div>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <div>
              © 2026 EduPulse SaaS. {t('footerRights')}
            </div>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                System Operational (100%)
              </span>
              <span>Java 21 · Spring Boot 3 · PostgreSQL</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Demo Persona Login Modal */}
      <DemoLoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        initialRole={initialRole}
      />
    </div>
  );
};
