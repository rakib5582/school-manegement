import React from 'react';
import { useApp } from '../../context/AppContext';
import { Student } from '../../types';
import { X, Printer, School, ShieldCheck } from 'lucide-react';

interface StudentIdCardModalProps {
  student: Student | null;
  onClose: () => void;
}

export const StudentIdCardModal: React.FC<StudentIdCardModalProps> = ({ student, onClose }) => {
  const { currentTenant, getTenantClasses, getTenantSections } = useApp();

  if (!student) return null;

  const classes = getTenantClasses();
  const sections = getTenantSections();
  const studentClass = classes.find(c => c.id === student.classId);
  const studentSection = sections.find(s => s.id === student.sectionId);

  const studentName = student.gender === 'Male' ? 'Alex Rivera' : student.rollNumber === '102' ? 'Sophia Chen' : 'Liam Johnson';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full border border-slate-200 overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-semibold">Official Student Identity Card</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs">✕</button>
        </div>

        {/* Printable Card Body */}
        <div className="p-6 flex flex-col items-center">
          <div
            id="student-id-card-print-area"
            className="w-full max-w-sm rounded-2xl border-2 border-indigo-900 shadow-md bg-gradient-to-b from-indigo-900 via-indigo-900 to-indigo-950 text-white p-5 flex flex-col justify-between"
            style={{ minHeight: '380px' }}
          >
            {/* Top School Branding */}
            <div className="text-center border-b border-indigo-800 pb-3">
              <div className="flex items-center justify-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block"></span>
                <span className="font-bold text-sm tracking-wide text-white uppercase">{currentTenant?.name || 'Greenwood International Academy'}</span>
              </div>
              <div className="text-[10px] text-indigo-300 font-mono tracking-wider mt-0.5">
                STUDENT IDENTIFICATION CARD · {currentTenant?.academicYearName || '2026-2027'}
              </div>
            </div>

            {/* Photo & Details Section */}
            <div className="my-4 flex gap-4 items-center">
              {/* Photo Box */}
              <div className="w-24 h-28 rounded-lg bg-indigo-800/80 border-2 border-indigo-400/40 flex flex-col items-center justify-center text-center p-1 shrink-0">
                <div className="w-14 h-14 rounded-full bg-indigo-600 text-white font-bold text-lg flex items-center justify-center border-2 border-white/20">
                  {studentName.split(' ')[0][0]}{studentName.split(' ')[1]?.[0] || 'S'}
                </div>
                <span className="text-[9px] text-indigo-200 mt-1 uppercase font-semibold">Photo ID</span>
              </div>

              {/* Personal Meta */}
              <div className="flex-1 space-y-1 text-xs">
                <div>
                  <span className="text-[9px] text-indigo-300 uppercase tracking-wider block">Full Name</span>
                  <span className="font-bold text-sm text-white">{studentName}</span>
                </div>
                <div className="grid grid-cols-2 gap-1 pt-1">
                  <div>
                    <span className="text-[9px] text-indigo-300 uppercase block">Grade</span>
                    <span className="font-semibold text-xs">{studentClass?.name || 'Grade 10'}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-indigo-300 uppercase block">Section</span>
                    <span className="font-semibold text-xs">{studentSection?.name || 'Section A'}</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-1 pt-1">
                  <div>
                    <span className="text-[9px] text-indigo-300 uppercase block">Roll Number</span>
                    <span className="font-mono font-bold text-xs text-amber-300">#{student.rollNumber}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-indigo-300 uppercase block">Blood Group</span>
                    <span className="font-mono font-semibold text-xs text-rose-300">{student.bloodGroup}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Bar: Admission & Barcode */}
            <div className="pt-3 border-t border-indigo-800/80 flex items-end justify-between text-[10px]">
              <div>
                <span className="text-[9px] text-indigo-300 block">Admission Number</span>
                <span className="font-mono font-bold text-xs text-white tracking-wider">{student.admissionNumber}</span>
                <div className="text-[8px] text-indigo-400 font-mono mt-0.5">Emergency: {student.emergencyContact}</div>
              </div>

              <div className="text-right">
                <div className="text-[9px] font-mono tracking-widest text-indigo-300">||||| | |||| ||| ||||</div>
                <div className="text-[8px] text-indigo-300 uppercase font-semibold mt-0.5">Principal Signature</div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-between items-center no-print">
          <span className="text-[11px] text-slate-500 font-mono">Secured with encrypted barcode</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print ID Card</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
