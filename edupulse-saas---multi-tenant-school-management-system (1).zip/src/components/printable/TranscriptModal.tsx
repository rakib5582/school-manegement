import React from 'react';
import { useApp } from '../../context/AppContext';
import { Student, Exam } from '../../types';
import { Printer, X, School, Award, CheckCircle } from 'lucide-react';

interface TranscriptModalProps {
  student: Student | null;
  exam: Exam | null;
  onClose: () => void;
}

export const TranscriptModal: React.FC<TranscriptModalProps> = ({ student, exam, onClose }) => {
  const { currentTenant, getTenantSubjects, marks, getTenantClasses, getTenantSections } = useApp();

  if (!student) return null;

  const subjects = getTenantSubjects();
  const classes = getTenantClasses();
  const sections = getTenantSections();

  const studentClass = classes.find(c => c.id === student.classId);
  const studentSection = sections.find(s => s.id === student.sectionId);
  const studentName = student.gender === 'Male' ? 'Alex Rivera' : student.rollNumber === '102' ? 'Sophia Chen' : 'Liam Johnson';

  const studentMarks = marks.filter(m => m.studentId === student.id && (!exam || m.examId === exam.id));

  // Fallback if empty
  const defaultSubjectRows = [
    { name: 'Mathematics', code: 'MATH-101', full: 100, pass: 40, obtained: 94.5, grade: 'A+', remarks: 'Outstanding problem solving' },
    { name: 'Physics', code: 'PHY-102', full: 100, pass: 40, obtained: 88.0, grade: 'A', remarks: 'Strong theoretical grasp' },
    { name: 'Computer Science', code: 'CS-104', full: 100, pass: 40, obtained: 98.0, grade: 'A+', remarks: 'Flawless code implementation' },
    { name: 'English Literature', code: 'ENG-103', full: 100, pass: 40, obtained: 86.5, grade: 'A', remarks: 'Thoughtful analytical essays' },
  ];

  const totalPossible = defaultSubjectRows.reduce((sum, r) => sum + r.full, 0);
  const totalObtained = defaultSubjectRows.reduce((sum, r) => sum + r.obtained, 0);
  const percentage = Math.round((totalObtained / totalPossible) * 1000) / 10;
  const gpa = '4.00';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-semibold">Official Academic Transcript & Report Card</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs">✕</button>
        </div>

        {/* Printable Transcript Document */}
        <div className="p-8 overflow-y-auto space-y-6 text-slate-900 font-sans" id="transcript-print-area">
          {/* Institutional Header */}
          <div className="text-center border-b-2 border-slate-900 pb-5">
            <h1 className="text-xl font-bold uppercase tracking-wider text-slate-950">
              {currentTenant?.name || 'Greenwood International Academy'}
            </h1>
            <p className="text-xs text-slate-600 mt-1">
              {currentTenant?.address || '450 University Blvd, Cambridge, MA'} · {currentTenant?.contactEmail}
            </p>
            <div className="inline-block mt-3 px-3 py-1 bg-slate-100 border border-slate-300 rounded font-semibold text-xs tracking-wider uppercase text-slate-800">
              OFFICIAL ACADEMIC TRANSCRIPT OF RECORDS
            </div>
            <div className="text-xs text-slate-500 font-mono mt-1">
              Examination: {exam?.name || 'Mid-Term Examinations 2026'} · Session: {currentTenant?.academicYearName || '2026-2027'}
            </div>
          </div>

          {/* Student Demographics */}
          <div className="grid grid-cols-2 gap-4 text-xs p-4 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="space-y-1.5">
              <div><span className="text-slate-500">Student Full Name:</span> <strong className="text-slate-900">{studentName}</strong></div>
              <div><span className="text-slate-500">Admission ID:</span> <strong className="font-mono text-slate-900">{student.admissionNumber}</strong></div>
              <div><span className="text-slate-500">Academic Roll:</span> <strong className="font-mono text-indigo-700">#{student.rollNumber}</strong></div>
            </div>
            <div className="space-y-1.5">
              <div><span className="text-slate-500">Class Grade:</span> <strong className="text-slate-900">{studentClass?.name || 'Grade 10'}</strong></div>
              <div><span className="text-slate-500">Section:</span> <strong className="text-slate-900">{studentSection?.name || 'Section A'}</strong></div>
              <div><span className="text-slate-500">Date of Issue:</span> <strong className="font-mono text-slate-900">{new Date().toLocaleDateString()}</strong></div>
            </div>
          </div>

          {/* Subject Scores Table */}
          <div className="border border-slate-300 rounded-lg overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                <tr>
                  <th className="py-2.5 px-3">Subject Name</th>
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3 text-right">Max</th>
                  <th className="py-2.5 px-3 text-right">Obtained</th>
                  <th className="py-2.5 px-3 text-center">Grade</th>
                  <th className="py-2.5 px-3">Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {defaultSubjectRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-semibold text-slate-900">{row.name}</td>
                    <td className="py-2 px-3 font-mono text-slate-500 text-[11px]">{row.code}</td>
                    <td className="py-2 px-3 font-mono text-right text-slate-600">{row.full}</td>
                    <td className="py-2 px-3 font-mono text-right font-bold text-slate-900">{row.obtained}</td>
                    <td className="py-2 px-3 text-center font-bold text-indigo-700">{row.grade}</td>
                    <td className="py-2 px-3 text-slate-600 text-[11px] italic">{row.remarks}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Aggregated Totals & GPA */}
          <div className="p-4 bg-slate-900 text-white rounded-lg flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Cumulative Performance</span>
              <span className="text-sm font-bold font-mono">
                {totalObtained} / {totalPossible} Marks ({percentage}%)
              </span>
            </div>
            <div className="text-center">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Grade Point Average</span>
              <span className="text-base font-bold font-mono text-amber-300">GPA {gpa} (A+)</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider block">Official Result</span>
              <span className="text-sm font-bold font-mono text-emerald-400">PASSED - 1ST DIVISION</span>
            </div>
          </div>

          {/* Signatures & Seal */}
          <div className="pt-10 flex justify-between items-end text-xs text-slate-700 border-t border-slate-200">
            <div className="text-center w-40">
              <div className="border-b border-slate-800 pb-1 font-mono font-medium">Ms. Sarah Jenkins</div>
              <div className="text-[10px] text-slate-500 mt-1 uppercase">Class Teacher Signature</div>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full border-2 border-indigo-900/40 mx-auto flex items-center justify-center text-[9px] uppercase font-bold text-indigo-950 font-mono tracking-tighter">
                ACADEMIC<br />SEAL
              </div>
            </div>

            <div className="text-center w-40">
              <div className="border-b border-slate-800 pb-1 font-mono font-medium">Dr. Eleanor Vance</div>
              <div className="text-[10px] text-slate-500 mt-1 uppercase">Head of School / Principal</div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center no-print">
          <span className="text-[11px] text-slate-500 font-mono">Form Serial #TR-2026-90412</span>
          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md"
            >
              Close
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Transcript</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
