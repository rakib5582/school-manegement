import React from 'react';
import { useApp } from '../../context/AppContext';
import { PaymentRecord, FeeInvoice } from '../../types';
import { Printer, X, Receipt, CheckCircle } from 'lucide-react';

interface FeeReceiptModalProps {
  payment: PaymentRecord | null;
  invoice: FeeInvoice | null;
  onClose: () => void;
}

export const FeeReceiptModal: React.FC<FeeReceiptModalProps> = ({ payment, invoice, onClose }) => {
  const { currentTenant, getTenantStudents } = useApp();

  if (!payment || !invoice) return null;

  const students = getTenantStudents();
  const student = students.find(s => s.id === invoice.studentId) || students[0];
  const studentName = student?.gender === 'Male' ? 'Alex Rivera' : 'Sophia Chen';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold">Official Fee Payment Receipt Voucher</span>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-xs">✕</button>
        </div>

        {/* Printable Voucher Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-slate-900 text-xs" id="receipt-print-area">
          {/* Institution Header */}
          <div className="text-center border-b border-slate-200 pb-4">
            <h1 className="text-base font-bold text-slate-950 uppercase">
              {currentTenant?.name || 'Greenwood International Academy'}
            </h1>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {currentTenant?.address || 'Cambridge, MA'} · Accounts & Finance Directorate
            </p>
            <div className="inline-block mt-2 px-2.5 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded font-bold text-[11px] font-mono">
              OFFICIAL PAYMENT RECEIPT: {payment.receiptNumber}
            </div>
          </div>

          {/* Meta Grid */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-lg">
            <div className="space-y-1">
              <div><span className="text-slate-500">Student:</span> <strong className="text-slate-900">{studentName}</strong></div>
              <div><span className="text-slate-500">Admission No:</span> <strong className="font-mono text-slate-900">{student?.admissionNumber}</strong></div>
              <div><span className="text-slate-500">Invoice Ref:</span> <span className="font-mono text-slate-700">{invoice.invoiceNumber}</span></div>
            </div>
            <div className="space-y-1">
              <div><span className="text-slate-500">Payment Date:</span> <span className="font-mono text-slate-800">{new Date(payment.paidAt).toLocaleDateString()}</span></div>
              <div><span className="text-slate-500">Payment Method:</span> <strong className="text-slate-900">{payment.paymentMethod}</strong></div>
              <div><span className="text-slate-500">Transaction ID:</span> <span className="font-mono text-slate-600 text-[10px]">{payment.transactionId || 'TXN_DIRECT'}</span></div>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2 px-3">Description</th>
                  <th className="py-2 px-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-2 px-3 font-medium">{invoice.title}</td>
                  <td className="py-2 px-3 font-mono text-right font-bold text-slate-900">${payment.amount}</td>
                </tr>
                <tr>
                  <td className="py-2 px-3 text-slate-500">Late Fine / Penalty</td>
                  <td className="py-2 px-3 font-mono text-right text-slate-500">$0.00</td>
                </tr>
              </tbody>
              <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                <tr>
                  <td className="py-2 px-3 text-slate-900">Total Paid (USD):</td>
                  <td className="py-2 px-3 font-mono text-right text-emerald-700 text-sm">${payment.amount}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Paid Stamp & Signature */}
          <div className="pt-4 flex items-center justify-between">
            <div className="border-2 border-emerald-600 text-emerald-700 rounded-lg px-3 py-1 font-mono font-bold text-xs uppercase tracking-widest inline-flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" />
              PAID IN FULL
            </div>

            <div className="text-center w-36">
              <div className="border-b border-slate-400 pb-1 font-mono text-[11px]">Accounts Desk</div>
              <div className="text-[10px] text-slate-400 uppercase mt-0.5">Authorized Signatory</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center no-print">
          <span className="text-[10px] text-slate-400 font-mono">Computer generated receipt</span>
          <div className="flex gap-2">
            <button onClick={onClose} className="px-3 py-1.5 text-xs text-slate-700 bg-white border border-slate-200 rounded-md">
              Close
            </button>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-md shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Receipt</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
