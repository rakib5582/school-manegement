import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../../i18n/LanguageContext';
import { Globe, ChevronDown, Check } from 'lucide-react';

interface LanguageSelectorProps {
  variant?: 'light' | 'dark' | 'minimal';
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({ variant = 'light' }) => {
  const { language, setLanguage } = useLanguage();
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const buttonStyle = {
    light: 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50',
    dark: 'bg-slate-800 border border-slate-700 text-slate-200 hover:bg-slate-700',
    minimal: 'bg-transparent text-slate-700 hover:text-indigo-600',
  }[variant];

  return (
    <div className="relative inline-block text-left" ref={containerRef}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${buttonStyle}`}
        aria-expanded={open}
        aria-label="Select language"
      >
        <Globe className="w-3.5 h-3.5 text-indigo-500" />
        <span>{language === 'en' ? 'English' : 'বাংলা'}</span>
        <ChevronDown className="w-3 h-3 text-slate-400" />
      </button>

      {open && (
        <div className="absolute right-0 mt-1.5 w-36 bg-white border border-slate-200 rounded-xl shadow-xl py-1.5 z-50 animate-in fade-in zoom-in-95 duration-100">
          <div className="px-3 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Select Language
          </div>
          <button
            onClick={() => {
              setLanguage('en');
              setOpen(false);
            }}
            className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors hover:bg-slate-50 ${
              language === 'en' ? 'font-bold text-indigo-600 bg-indigo-50/50' : 'text-slate-700'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-sm">🇺🇸</span>
              <span>English</span>
            </div>
            {language === 'en' && <Check className="w-3.5 h-3.5 text-indigo-600" />}
          </button>

          <button
            onClick={() => {
              setLanguage('bn');
              setOpen(false);
            }}
            className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition-colors hover:bg-slate-50 ${
              language === 'bn' ? 'font-bold text-indigo-600 bg-indigo-50/50' : 'text-slate-700'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-sm">🇧🇩</span>
              <span className="font-sans">বাংলা</span>
            </div>
            {language === 'bn' && <Check className="w-3.5 h-3.5 text-indigo-600" />}
          </button>
        </div>
      )}
    </div>
  );
};
