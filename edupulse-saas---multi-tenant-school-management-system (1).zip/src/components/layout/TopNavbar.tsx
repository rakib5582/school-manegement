import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { LanguageSelector } from '../common/LanguageSelector';
import { Role } from '../../types';
import {
  Shield,
  School,
  UserCheck,
  GraduationCap,
  Users,
  LogOut,
  ChevronDown,
  Building2,
  Lock,
  Layers,
  Globe,
  Home,
} from 'lucide-react';

interface TopNavbarProps {
  currentTab: string;
  onOpenSecurityLab: () => void;
  onOpenCodebase: () => void;
  onOpenApiDocs: () => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  currentTab,
  onOpenSecurityLab,
  onOpenCodebase,
  onOpenApiDocs,
}) => {
  const { currentUser, currentTenant, tenants, switchRole, switchTenant, logout } = useApp();
  const { t, language } = useLanguage();
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [tenantMenuOpen, setTenantMenuOpen] = useState(false);

  const roleOptions: { role: Role; email: string; label: string; desc: string; icon: React.ReactNode }[] = [
    {
      role: 'SUPER_ADMIN',
      email: 'superadmin@saas-edupulse.com',
      label: language === 'bn' ? 'সুপার অ্যাডমিন' : 'Super Admin',
      desc: language === 'bn' ? 'সকল স্কুল ও প্ল্যাটফর্মের সমন্বিত নিয়ন্ত্রণ' : 'Global SaaS controller across all schools',
      icon: <Shield className="w-4 h-4 text-amber-600" />,
    },
    {
      role: 'SCHOOL_ADMIN',
      email: 'admin@greenwood.edu',
      label: language === 'bn' ? 'স্কুল অ্যাডমিন (গ্রিনউড)' : 'School Admin (Greenwood)',
      desc: language === 'bn' ? 'গ্রিনউড একাডেমির পূর্ণ প্রশাসনিক নিয়ন্ত্রণ' : 'Full administrative control of Greenwood Academy',
      icon: <School className="w-4 h-4 text-indigo-600" />,
    },
    {
      role: 'TEACHER',
      email: 'teacher.sarah@greenwood.edu',
      label: language === 'bn' ? 'শ্রেণি শিক্ষক (মিসেস সারাহ)' : 'Teacher (Ms. Sarah Jenkins)',
      desc: language === 'bn' ? '১০ম শ্রেণি-ক গণিত ও রুটিন দায়িত্ব' : 'Assigned to Grade 10-A (Math & Routine)',
      icon: <UserCheck className="w-4 h-4 text-emerald-600" />,
    },
    {
      role: 'STUDENT',
      email: 'student.alex@greenwood.edu',
      label: language === 'bn' ? 'শিক্ষার্থী (অ্যালেক্স রিভেরা)' : 'Student (Alex Rivera)',
      desc: language === 'bn' ? '১০ম শ্রেণির শিক্ষার্থী পোর্টাল, আইডি কার্ড ও ফলাফল' : 'Grade 10-A student portal with ID card & grades',
      icon: <GraduationCap className="w-4 h-4 text-blue-600" />,
    },
    {
      role: 'PARENT',
      email: 'parent.robert@greenwood.edu',
      label: language === 'bn' ? 'অভিভাবক (রবার্ট রিভেরা)' : 'Parent (Robert Rivera)',
      desc: language === 'bn' ? 'অ্যালেক্সের পিতা (ফি ইনভয়েস ও অগ্রগতি)' : 'Linked father of Alex Rivera (Fees & progress)',
      icon: <Users className="w-4 h-4 text-purple-600" />,
    },
    {
      role: 'SCHOOL_ADMIN',
      email: 'admin@oakridge.edu',
      label: language === 'bn' ? 'স্কুল অ্যাডমিন (ওকরিজ)' : 'School Admin (Oakridge)',
      desc: language === 'bn' ? 'দ্বিতীয় স্কুল - ক্রস-টেন্যান্ট আইসোলেশন পরীক্ষা' : 'Second tenant to test cross-school isolation',
      icon: <Building2 className="w-4 h-4 text-emerald-700" />,
    },
  ];

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 md:px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Zone 1: Brand & Active Context */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-base text-slate-900 tracking-tight flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block"></span>
            EduPulse SaaS
          </span>
          {currentTenant ? (
            <span className="hidden sm:inline-flex items-center gap-1 text-xs text-slate-600 font-medium bg-slate-100 px-2 py-0.5 rounded">
              <School className="w-3 h-3 text-slate-500" />
              {currentTenant.name}
            </span>
          ) : (
            <span className="hidden sm:inline-flex items-center gap-1 text-xs text-amber-700 font-medium bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
              <Shield className="w-3 h-3 text-amber-600" />
              Global SaaS Console
            </span>
          )}
        </div>

        <span className="text-slate-300 hidden md:inline">/</span>

        {/* Breadcrumb current active tab */}
        <span className="text-xs md:text-sm font-medium text-slate-600 capitalize hidden md:inline">
          {currentTab.replace('-', ' ')}
        </span>
      </div>

      {/* Zone 2 & 3: Actions & Role / Tenant Switcher */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Language Selector (English / বাংলা) */}
        <LanguageSelector variant="light" />

        {/* Interactive Tenant Isolation Test Lab Button */}
        <button
          onClick={onOpenSecurityLab}
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md transition-colors"
          title="Verify multi-tenant isolation and security constraints"
        >
          <Lock className="w-3.5 h-3.5" />
          <span className="hidden lg:inline">{language === 'bn' ? 'সিকিউরিটি ল্যাব:' : 'Security Lab:'}</span>
          <span>{language === 'bn' ? 'আইসোলেশন' : 'Isolation'}</span>
        </button>

        {/* Spring Boot Codebase Viewer */}
        <button
          onClick={onOpenCodebase}
          className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
        >
          <Layers className="w-3.5 h-3.5 text-indigo-600" />
          <span>{language === 'bn' ? 'স্প্রিং বুট কোড' : 'Spring Boot 3'}</span>
        </button>

        {/* REST API Explorer */}
        <button
          onClick={onOpenApiDocs}
          className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
        >
          <span>OpenAPI / REST</span>
        </button>

        {/* Tenant Switcher (Available for Super Admin) */}
        {currentUser.role === 'SUPER_ADMIN' && (
          <div className="relative">
            <button
              onClick={() => setTenantMenuOpen(!tenantMenuOpen)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-md transition-colors"
            >
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Scope:</span>
              <span className="font-semibold text-slate-900">{currentTenant ? currentTenant.code : 'All Schools'}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {tenantMenuOpen && (
              <div className="absolute right-0 mt-1 w-64 bg-white border border-slate-200 rounded-lg shadow-lg py-1.5 z-50">
                <div className="px-3 py-1 text-xs font-semibold text-slate-400 uppercase tracking-wider">Select School Scope</div>
                <button
                  onClick={() => {
                    switchRole('SUPER_ADMIN');
                    setTenantMenuOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${!currentTenant ? 'bg-indigo-50 text-indigo-900 font-semibold' : 'text-slate-700'}`}
                >
                  <span>All Schools (Global)</span>
                  <span className="text-[10px] text-slate-400">Platform</span>
                </button>
                {tenants.map(t => (
                  <button
                    key={t.id}
                    onClick={() => {
                      switchTenant(t.id);
                      setTenantMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-50 ${currentTenant?.id === t.id ? 'bg-indigo-50 text-indigo-900 font-semibold' : 'text-slate-700'}`}
                  >
                    <span>{t.name}</span>
                    <span className="text-[10px] text-slate-400">{t.code}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Role Quick-Switcher Menu */}
        <div className="relative">
          <button
            onClick={() => setRoleMenuOpen(!roleMenuOpen)}
            className="flex items-center gap-2 px-2.5 py-1.5 bg-slate-900 text-white rounded-md text-xs font-medium hover:bg-slate-800 transition-colors"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="hidden sm:inline">{language === 'bn' ? 'ভূমিকা:' : 'Role:'}</span>
            <span className="font-semibold">{currentUser.role.replace('_', ' ')}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {roleMenuOpen && (
            <div className="absolute right-0 mt-1.5 w-76 bg-white border border-slate-200 rounded-lg shadow-xl py-2 z-50">
              <div className="px-3 py-1.5 border-b border-slate-100">
                <div className="text-xs font-semibold text-slate-900">
                  {language === 'bn' ? 'ইনস্ট্যান্ট রোল সুইচার' : 'Instant Demo Role Switcher'}
                </div>
                <div className="text-[11px] text-slate-500">
                  {language === 'bn' ? '৫টি ভূমিকা ও ক্রস-টেন্যান্ট নিরাপত্তা পরীক্ষা' : 'Test all 5 roles & cross-tenant security instantly'}
                </div>
              </div>
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-50">
                {roleOptions.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      switchRole(opt.role, opt.email);
                      setRoleMenuOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2.5 hover:bg-slate-50 flex items-start gap-2.5 transition-colors ${
                      currentUser.email === opt.email ? 'bg-indigo-50/70 border-l-2 border-indigo-600' : ''
                    }`}
                  >
                    <div className="mt-0.5">{opt.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-slate-900 flex items-center justify-between">
                        <span>{opt.label}</span>
                        {currentUser.email === opt.email && (
                          <span className="text-[10px] text-indigo-700 font-bold uppercase tracking-wider">
                            {language === 'bn' ? 'সক্রিয়' : 'Active'}
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">{opt.desc}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">{opt.email}</div>
                    </div>
                  </button>
                ))}
              </div>
              <div className="p-2 border-t border-slate-100 bg-slate-50/50 flex justify-between items-center">
                <button
                  onClick={() => {
                    logout();
                    setRoleMenuOpen(false);
                  }}
                  className="flex items-center gap-1.5 text-xs text-slate-600 hover:text-slate-900 font-medium px-2 py-1"
                >
                  <Home className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{language === 'bn' ? 'মূল পাতা (Landing)' : 'Public Landing'}</span>
                </button>
                <button
                  onClick={() => {
                    logout();
                    setRoleMenuOpen(false);
                  }}
                  className="flex items-center gap-1.5 text-xs text-rose-600 hover:text-rose-700 font-medium px-2 py-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'লগআউট' : 'Logout'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
