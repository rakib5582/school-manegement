import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ShieldAlert, CheckCircle2, XCircle, ArrowRight, X, Play, RefreshCw, Lock } from 'lucide-react';

interface TenantSecurityLabModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TenantSecurityLabModal: React.FC<TenantSecurityLabModalProps> = ({ isOpen, onClose }) => {
  const { currentTenant, tenants, testCrossTenantSecurity, auditLogs } = useApp();
  const [testResult, setTestResult] = useState<{
    attempt: string;
    sourceTenant: string;
    targetTenant: string;
    result: 'BLOCKED' | 'ALLOWED';
    statusCode: number;
    message: string;
  } | null>(null);
  const [running, setRunning] = useState(false);

  if (!isOpen) return null;

  const handleRunSecurityTest = () => {
    setRunning(true);
    setTimeout(() => {
      const res = testCrossTenantSecurity();
      setTestResult(res);
      setRunning(false);
    }, 400);
  };

  const otherSchool = tenants.find(t => t.id !== currentTenant?.id) || tenants[1];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-rose-600 flex items-center justify-center text-white">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold">Tenant Isolation Security Lab</h2>
              <p className="text-xs text-slate-400">Section 4 & 40 Verification: Cross-Tenant Breach Penetration Test</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
            <h3 className="font-semibold text-slate-900 mb-1 text-xs">Architectural Invariant</h3>
            <p className="text-slate-600 leading-relaxed">
              In a true enterprise SaaS system, tenant boundaries must be verified server-side. Even if an attacker maliciously modifies request URLs, IDs, headers, or parameters, the backend strictly rejects the cross-tenant operation with a <code className="text-rose-700 font-mono bg-rose-50 px-1 py-0.5 rounded">TenantAccessDeniedException</code> and HTTP 403 Forbidden.
            </p>
          </div>

          {/* Test Scenario setup */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 border border-slate-200 rounded-lg bg-indigo-50/50">
              <span className="text-[10px] uppercase font-bold text-indigo-700 tracking-wider">Source (Authenticated User)</span>
              <div className="font-semibold text-slate-900 mt-1">{currentTenant?.name || 'Greenwood Academy'}</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">tenant_id: {currentTenant?.id || '11111111-1111-1111-1111-111111111111'}</div>
            </div>

            <div className="p-3 border border-slate-200 rounded-lg bg-slate-50">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Target (Victim School)</span>
              <div className="font-semibold text-slate-900 mt-1">{otherSchool.name}</div>
              <div className="text-[11px] text-slate-500 font-mono mt-0.5">tenant_id: {otherSchool.id}</div>
            </div>
          </div>

          {/* Action Button */}
          <div>
            <button
              onClick={handleRunSecurityTest}
              disabled={running}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg shadow-sm transition-colors text-xs disabled:opacity-50"
            >
              {running ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
              <span>Execute Simulated Cross-Tenant Attack & Verify Isolation</span>
            </button>
          </div>

          {/* Results Box */}
          {testResult && (
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 flex items-center justify-between">
                <span className="font-semibold text-slate-900 text-xs">Security Test Outcome</span>
                <span className="inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded text-[11px] bg-emerald-100 text-emerald-800">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  ISOLATION ENFORCED: 403 FORBIDDEN
                </span>
              </div>
              <div className="p-4 space-y-3 bg-white font-mono text-[11px]">
                <div>
                  <span className="text-slate-400"># 1. Incoming Simulated API Request:</span>
                  <div className="p-2 bg-slate-900 text-slate-100 rounded mt-1 overflow-x-auto">
                    {testResult.attempt}
                    <div className="text-slate-400 text-[10px]">Authorization: Bearer jwt_token_from_{testResult.sourceTenant.split(' ')[0]}</div>
                  </div>
                </div>

                <div>
                  <span className="text-slate-400"># 2. Server-Side TenantFilter & Service Resolution:</span>
                  <div className="p-2 bg-slate-50 border border-slate-200 rounded text-slate-800">
                    TenantContext.getTenantId() = {currentTenant?.id || '11111111-1111-1111-1111-111111111111'}<br />
                    Target Entity tenant_id = {otherSchool.id}<br />
                    Assertion: targetEntity.tenantId != TenantContext.tenantId (VIOLATION DETECTED)
                  </div>
                </div>

                <div>
                  <span className="text-slate-400"># 3. HTTP Response & Exception Handler:</span>
                  <div className="p-2 bg-rose-50 border border-rose-200 rounded text-rose-800 leading-relaxed font-sans text-xs">
                    <span className="font-bold font-mono">HTTP 403 Forbidden</span>: {testResult.message}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Real-time Audit Trail Preview */}
          <div>
            <h4 className="font-semibold text-slate-900 text-xs mb-2">Live Security Audit Log (Last 3 Events)</h4>
            <div className="space-y-1.5 font-mono text-[10px]">
              {auditLogs.slice(0, 3).map(log => (
                <div key={log.id} className="p-2 bg-slate-50 border border-slate-200 rounded flex items-center justify-between">
                  <div className="truncate mr-2">
                    <span className="font-bold text-slate-800">[{log.action}]</span> {log.description}
                  </div>
                  <span className="text-slate-400 shrink-0">{new Date(log.createdAt).toLocaleTimeString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-medium rounded-md transition-colors text-xs"
          >
            Close Lab
          </button>
        </div>
      </div>
    </div>
  );
};
