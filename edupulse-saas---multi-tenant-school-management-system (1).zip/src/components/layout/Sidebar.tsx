import React from 'react';
import { useApp } from '../../context/AppContext';
import { useLanguage } from '../../i18n/LanguageContext';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  CalendarCheck,
  Award,
  CreditCard,
  Clock,
  BookOpen,
  Bell,
  Building,
  ShieldAlert,
  Bus,
  Home,
  Sliders,
  FileText,
  BadgeCheck,
  Calendar,
  Layers,
  LogOut,
  Globe,
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  mobileOpen,
  onCloseMobile,
}) => {
  const { activeRole, currentTenant, currentUser, logout } = useApp();
  const { t, language } = useLanguage();

  interface NavItem {
    id: string;
    label: string;
    icon: React.ReactNode;
  }

  const getNavItems = (): NavItem[] => {
    switch (activeRole) {
      case 'SUPER_ADMIN':
        return [
          {
            id: 'dashboard',
            label: language === 'bn' ? 'প্ল্যাটফর্ম সারসংক্ষেপ' : 'Platform Overview',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            id: 'schools',
            label: language === 'bn' ? 'নিবন্ধিত স্কুলসমূহ' : 'Registered Schools',
            icon: <Building className="w-4 h-4" />,
          },
          {
            id: 'subscriptions',
            label: language === 'bn' ? 'সাবস্ক্রিপশন প্ল্যান' : 'SaaS Plans & Billing',
            icon: <CreditCard className="w-4 h-4" />,
          },
          {
            id: 'audit-logs',
            label: language === 'bn' ? 'প্ল্যাটফর্ম অডিট লগ' : 'Platform Audit Trail',
            icon: <ShieldAlert className="w-4 h-4" />,
          },
          {
            id: 'settings',
            label: language === 'bn' ? 'সিস্টেম কনফিগারেশন' : 'System Configuration',
            icon: <Sliders className="w-4 h-4" />,
          },
        ];
      case 'SCHOOL_ADMIN':
        return [
          {
            id: 'dashboard',
            label: language === 'bn' ? 'স্কুল ড্যাশবোর্ড' : 'School Dashboard',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            id: 'academics',
            label: language === 'bn' ? 'শ্রেণি ও বিষয়সমূহ' : 'Classes & Subjects',
            icon: <Layers className="w-4 h-4" />,
          },
          {
            id: 'students',
            label: language === 'bn' ? 'শিক্ষার্থী তালিকা' : 'Students Directory',
            icon: <GraduationCap className="w-4 h-4" />,
          },
          {
            id: 'teachers',
            label: language === 'bn' ? 'শিক্ষক ও কর্মচারী' : 'Faculty & Staff',
            icon: <Users className="w-4 h-4" />,
          },
          {
            id: 'parents',
            label: language === 'bn' ? 'অভিভাবক ডিরেক্টরি' : 'Parents / Guardians',
            icon: <Users className="w-4 h-4" />,
          },
          {
            id: 'attendance',
            label: language === 'bn' ? 'দৈনিক উপস্থিতি' : 'Daily Attendance',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            id: 'exams',
            label: language === 'bn' ? 'পরীক্ষা ও ফলাফল' : 'Exams & Results',
            icon: <Award className="w-4 h-4" />,
          },
          {
            id: 'fees',
            label: language === 'bn' ? 'ফি ও ইনভয়েস' : 'Fees & Invoicing',
            icon: <CreditCard className="w-4 h-4" />,
          },
          {
            id: 'routine',
            label: language === 'bn' ? 'টাইমটেবিল ও রুটিন' : 'Timetable & Routine',
            icon: <Clock className="w-4 h-4" />,
          },
          {
            id: 'homework',
            label: language === 'bn' ? 'হোমওয়ার্ক ও অ্যাসাইনমেন্ট' : 'Homework / Tasks',
            icon: <BookOpen className="w-4 h-4" />,
          },
          {
            id: 'notices',
            label: language === 'bn' ? 'বিজ্ঞপ্তি ও নোটিশ' : 'Notices & Circulars',
            icon: <Bell className="w-4 h-4" />,
          },
          {
            id: 'events',
            label: language === 'bn' ? 'ক্যালেন্ডার ও ইভেন্ট' : 'Calendar & Events',
            icon: <Calendar className="w-4 h-4" />,
          },
          {
            id: 'library',
            label: language === 'bn' ? 'লাইব্রেরি ক্যাটালগ' : 'Library Catalog',
            icon: <BookOpen className="w-4 h-4" />,
          },
          {
            id: 'transport',
            label: language === 'bn' ? 'পরিবহন ও রুট' : 'Transport & Routes',
            icon: <Bus className="w-4 h-4" />,
          },
          {
            id: 'hostel',
            label: language === 'bn' ? 'ছাত্রাবাস আবাসন' : 'Hostel Accommodation',
            icon: <Home className="w-4 h-4" />,
          },
          {
            id: 'reports',
            label: language === 'bn' ? 'নিরীক্ষা ও রিপোর্ট' : 'Formal Reports',
            icon: <FileText className="w-4 h-4" />,
          },
          {
            id: 'settings',
            label: language === 'bn' ? 'বিদ্যালয় সেটিংস' : 'School Settings',
            icon: <Sliders className="w-4 h-4" />,
          },
          {
            id: 'audit-logs',
            label: language === 'bn' ? 'অডিট ট্রেইল লগ' : 'Audit Trail Logs',
            icon: <ShieldAlert className="w-4 h-4" />,
          },
        ];
      case 'TEACHER':
        return [
          {
            id: 'dashboard',
            label: language === 'bn' ? 'শিক্ষক পোর্টাল' : 'Teacher Portal',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            id: 'attendance',
            label: language === 'bn' ? 'হাজিরা গ্রহণ' : 'Mark Attendance',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            id: 'exams',
            label: language === 'bn' ? 'পরীক্ষার নম্বর এন্ট্রি' : 'Enter Exam Marks',
            icon: <Award className="w-4 h-4" />,
          },
          {
            id: 'routine',
            label: language === 'bn' ? 'আমার ক্লাস রুটিন' : 'My Class Routine',
            icon: <Clock className="w-4 h-4" />,
          },
          {
            id: 'homework',
            label: language === 'bn' ? 'হোমওয়ার্ক প্রদান' : 'Assign Homework',
            icon: <BookOpen className="w-4 h-4" />,
          },
          {
            id: 'students',
            label: language === 'bn' ? 'শ্রেণির শিক্ষার্থী' : 'My Class Students',
            icon: <GraduationCap className="w-4 h-4" />,
          },
          {
            id: 'notices',
            label: language === 'bn' ? 'স্কুল নোটিশ' : 'School Notices',
            icon: <Bell className="w-4 h-4" />,
          },
          {
            id: 'events',
            label: language === 'bn' ? 'ইভেন্ট ক্যালেন্ডার' : 'School Calendar',
            icon: <Calendar className="w-4 h-4" />,
          },
        ];
      case 'STUDENT':
        return [
          {
            id: 'dashboard',
            label: language === 'bn' ? 'শিক্ষার্থী ড্যাশবোর্ড' : 'Student Dashboard',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            id: 'id-card',
            label: language === 'bn' ? 'স্টুডেন্ট আইডি কার্ড' : 'My Student ID Card',
            icon: <BadgeCheck className="w-4 h-4" />,
          },
          {
            id: 'attendance',
            label: language === 'bn' ? 'আমার হাজিরা' : 'My Attendance',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            id: 'routine',
            label: language === 'bn' ? 'ক্লাস সময়সূচি' : 'Class Timetable',
            icon: <Clock className="w-4 h-4" />,
          },
          {
            id: 'homework',
            label: language === 'bn' ? 'আমার হোমওয়ার্ক' : 'My Assignments',
            icon: <BookOpen className="w-4 h-4" />,
          },
          {
            id: 'exams',
            label: language === 'bn' ? 'মার্কশিট ও গ্রেড' : 'Report Card / Grades',
            icon: <Award className="w-4 h-4" />,
          },
          {
            id: 'fees',
            label: language === 'bn' ? 'ফি ও রসিদ' : 'My Fees & Receipts',
            icon: <CreditCard className="w-4 h-4" />,
          },
          {
            id: 'notices',
            label: language === 'bn' ? 'ঘোষণা ও নোটিশ' : 'Announcements',
            icon: <Bell className="w-4 h-4" />,
          },
          {
            id: 'events',
            label: language === 'bn' ? 'স্কুল ইভেন্টস' : 'School Events',
            icon: <Calendar className="w-4 h-4" />,
          },
        ];
      case 'PARENT':
        return [
          {
            id: 'dashboard',
            label: language === 'bn' ? 'অভিভাবক পোর্টাল' : 'Parent Portal',
            icon: <LayoutDashboard className="w-4 h-4" />,
          },
          {
            id: 'attendance',
            label: language === 'bn' ? 'সন্তানের হাজিরা' : 'Child Attendance',
            icon: <CalendarCheck className="w-4 h-4" />,
          },
          {
            id: 'exams',
            label: language === 'bn' ? 'একাডেমিক ট্রান্সক্রিপ্ট' : 'Academic Transcript',
            icon: <Award className="w-4 h-4" />,
          },
          {
            id: 'fees',
            label: language === 'bn' ? 'ফি ইনভয়েস ও পরিশোধ' : 'Fee Invoices & Pay',
            icon: <CreditCard className="w-4 h-4" />,
          },
          {
            id: 'routine',
            label: language === 'bn' ? 'ক্লাসের সময়সূচি' : 'Class Schedule',
            icon: <Clock className="w-4 h-4" />,
          },
          {
            id: 'homework',
            label: language === 'bn' ? 'সন্তানের হোমওয়ার্ক' : 'Child Homework',
            icon: <BookOpen className="w-4 h-4" />,
          },
          {
            id: 'notices',
            label: language === 'bn' ? 'স্কুল নোটিশ' : 'School Notices',
            icon: <Bell className="w-4 h-4" />,
          },
          {
            id: 'events',
            label: language === 'bn' ? 'স্কুল ক্যালেন্ডার' : 'School Events',
            icon: <Calendar className="w-4 h-4" />,
          },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();

  return (
    <>
      {/* Mobile backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-slate-900/50 z-40 md:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={`fixed md:sticky top-0 left-0 z-40 h-screen w-64 bg-slate-900 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center px-6 border-b border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow">
              EP
            </div>
            <div>
              <div className="font-semibold text-sm text-white leading-tight">EduPulse SaaS</div>
              <div className="text-[10px] text-slate-400 font-mono tracking-tight">
                {currentTenant ? currentTenant.code : 'GLOBAL SAAS'}
              </div>
            </div>
          </div>
        </div>

        {/* School Profile Mini Box if in Tenant mode */}
        {currentTenant && (
          <div className="px-4 py-3 mx-3 my-3 rounded-lg bg-slate-800/60 border border-slate-700/60">
            <div className="text-[11px] font-semibold text-slate-200 truncate">{currentTenant.name}</div>
            <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>{currentTenant.academicYearName}</span>
              <span>·</span>
              <span className="uppercase text-[9px] font-semibold text-indigo-400">
                {currentTenant.planId.includes('003') ? 'Enterprise' : 'Basic'}
              </span>
            </div>
          </div>
        )}

        {/* Navigation Items */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          <div className="px-3 py-1.5 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
            {activeRole.replace('_', ' ')} MENU
          </div>
          {navItems.map(item => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onSelectTab(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/80'
                }`}
              >
                <span className={isActive ? 'text-white' : 'text-slate-400'}>{item.icon}</span>
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer Account Status & Logout */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/40 space-y-2">
          <div className="flex items-center gap-2.5 px-2 py-1.5">
            <div className="w-7 h-7 rounded-full bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-xs font-semibold text-indigo-300">
              {currentUser.firstName[0]}
              {currentUser.lastName[0]}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-medium text-slate-200 truncate">
                {currentUser.firstName} {currentUser.lastName}
              </div>
              <div className="text-[10px] text-slate-400 truncate">{currentUser.email}</div>
            </div>
          </div>

          <button
            onClick={() => logout()}
            className="w-full flex items-center justify-center gap-2 py-1.5 px-2 bg-slate-800/80 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 rounded-lg text-xs transition-colors border border-slate-700/60"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'লগআউট ও মূল পাতা' : 'Sign Out to Landing'}</span>
          </button>
        </div>
      </aside>
    </>
  );
};
