import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Users,
  GraduationCap,
  CalendarCheck,
  CreditCard,
  Award,
  ArrowRight,
  Printer,
  CheckCircle2,
} from 'lucide-react';

interface ParentDashboardProps {
  onOpenTranscript: () => void;
  onNavigateTab: (tab: string) => void;
}

export const ParentDashboard: React.FC<ParentDashboardProps> = ({ onOpenTranscript, onNavigateTab }) => {
  const { currentUser, currentTenant, getTenantStudents, getTenantInvoices, users, recordPayment } = useApp();

  const students = getTenantStudents();
  // Parent Robert Rivera's children
  const [selectedStudentId, setSelectedStudentId] = useState<string>(() => students[0]?.id || '');

  const activeChild = students.find(s => s.id === selectedStudentId) || students[0];
  const invoices = getTenantInvoices().filter(i => i.studentId === activeChild?.id);

  const getStudentFullName = (student: typeof students[0]) => {
    if (!student) return 'Child Student';
    const u = users.find(user => user.id === student.userId);
    return u ? `${u.firstName} ${u.lastName}` : `Student #${student.rollNumber}`;
  };

  const [paymentSuccess, setPaymentSuccess] = useState<string | null>(null);

  const handlePayInvoice = async (invoiceId: string, amount: number) => {
    const res = await recordPayment(invoiceId, amount, 'ONLINE');
    setPaymentSuccess(`Online payment successful! Official receipt voucher issued: ${res.receiptNumber}`);
    setTimeout(() => setPaymentSuccess(null), 6000);
  };

  return (
    <div className="space-y-6">
      {/* Parent Welcome Banner */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Parent Portal: {currentUser.firstName} {currentUser.lastName}
            </h1>
            <span className="text-[11px] font-semibold bg-purple-50 text-purple-700 border border-purple-200 px-2 py-0.5 rounded">
              Verified Guardian
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Linked children at <span className="font-semibold text-slate-700">{currentTenant?.name}</span>
          </p>
        </div>

        {/* Child Selector */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-500">Active Child:</span>
          <select
            value={selectedStudentId}
            onChange={e => setSelectedStudentId(e.target.value)}
            className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 bg-slate-50 focus:outline-hidden"
          >
            {students.map(s => (
              <option key={s.id} value={s.id}>
                {getStudentFullName(s)} (Roll #{s.rollNumber})
              </option>
            ))}
          </select>
        </div>
      </div>

      {paymentSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{paymentSuccess}</span>
        </div>
      )}

      {/* Child Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Child Attendance</span>
            <CalendarCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">98.5%</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Good standing in all classes</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Exam Result (Mid-Term)</span>
            <Award className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">GPA 4.0 / A+</div>
          <div className="text-[11px] text-slate-500 mt-1">Class Rank: #1 of 35 students</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Outstanding Fees</span>
            <CreditCard className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            ${invoices.filter(i => i.status === 'UNPAID').reduce((sum, i) => sum + i.totalAmount, 0)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Available for online clearance</div>
        </div>
      </div>

      {/* Action Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Child Fee Invoices */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Child's Fee Invoices & Payment</h2>
              <p className="text-xs text-slate-500">Pay tuition fees securely with instant receipt generation</p>
            </div>
          </div>

          <div className="space-y-3">
            {invoices.map(inv => (
              <div key={inv.id} className="p-3.5 border border-slate-200 rounded-lg bg-slate-50/50 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-slate-900">{inv.title}</div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    {inv.invoiceNumber} · Due by {inv.dueDate}
                  </div>
                </div>

                <div className="text-right flex items-center gap-3">
                  <div>
                    <div className="font-bold text-sm text-slate-900 font-mono tabular-nums">${inv.totalAmount}</div>
                    <span className={`text-[10px] font-bold uppercase ${inv.status === 'PAID' ? 'text-emerald-600' : 'text-amber-600'}`}>
                      {inv.status}
                    </span>
                  </div>

                  {inv.status !== 'PAID' && (
                    <button
                      onClick={() => handlePayInvoice(inv.id, inv.totalAmount)}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs transition-colors"
                    >
                      Pay Online
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Academic Transcript Preview */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Official Academic Transcript</h2>
            <p className="text-xs text-slate-500 mb-4">View verified grades, exam marks, and teacher remarks</p>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Exam:</span>
                <span className="font-semibold text-slate-900">Mid-Term Examinations 2026</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mathematics:</span>
                <span className="font-mono font-semibold text-emerald-700">94.5 / 100 (A+)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Physics:</span>
                <span className="font-mono font-semibold text-emerald-700">88.0 / 100 (A)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Computer Science:</span>
                <span className="font-mono font-semibold text-emerald-700">98.0 / 100 (A+)</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
            <button
              onClick={onOpenTranscript}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Official Transcript</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
