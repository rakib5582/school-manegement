import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Building2,
  Users,
  CreditCard,
  TrendingUp,
  ShieldCheck,
  Plus,
  Power,
  ChevronRight,
  ExternalLink,
  Shield,
} from 'lucide-react';

export const SuperAdminDashboard: React.FC = () => {
  const { tenants, plans, users, students, teachers, addSchool, toggleSchoolStatus, switchTenant, auditLogs } = useApp();

  const [newSchoolModalOpen, setNewSchoolModalOpen] = useState(false);
  const [schoolName, setSchoolName] = useState('');
  const [schoolCode, setSchoolCode] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [adminName, setAdminName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [selectedPlanCode, setSelectedPlanCode] = useState<'FREE' | 'BASIC' | 'PREMIUM'>('BASIC');

  const activeSchools = tenants.filter(t => t.status === 'ACTIVE').length;
  const suspendedSchools = tenants.filter(t => t.status === 'SUSPENDED').length;

  const totalMonthlyRevenue = tenants
    .filter(t => t.status === 'ACTIVE')
    .reduce((sum, t) => {
      const plan = plans.find(p => p.id === t.planId);
      return sum + (plan ? plan.pricePerMonth : 0);
    }, 0);

  const handleCreateSchool = (e: React.FormEvent) => {
    e.preventDefault();
    if (!schoolName || !schoolCode || !contactEmail) return;

    addSchool({
      name: schoolName,
      code: schoolCode,
      email: contactEmail,
      phone: contactPhone || '+1 (555) 000-0000',
      planCode: selectedPlanCode,
      adminName: adminName || 'Admin Principal',
      adminEmail: adminEmail || contactEmail,
    });

    setSchoolName('');
    setSchoolCode('');
    setContactEmail('');
    setContactPhone('');
    setAdminName('');
    setAdminEmail('');
    setNewSchoolModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Page Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-600" />
            Global Platform Super Admin Console
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            SaaS multi-tenant infrastructure, tenant lifecycle, plans, and platform revenue
          </p>
        </div>
        <button
          onClick={() => setNewSchoolModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs shadow-sm transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Onboard New School</span>
        </button>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Total Schools</span>
            <Building2 className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{tenants.length}</div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1.5">
            <span className="text-emerald-600 font-semibold">{activeSchools} Active</span>
            <span>·</span>
            <span className="text-rose-500 font-semibold">{suspendedSchools} Suspended</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Platform Users</span>
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{users.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            {students.length} Students · {teachers.length} Faculty
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Monthly Recurring (MRR)</span>
            <TrendingUp className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            ${totalMonthlyRevenue.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">
            +18.4% growth annualized
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>System Health & Isolation</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-600 mt-2">100% OK</div>
          <div className="text-[11px] text-slate-500 mt-1">
            Zero cross-tenant leaks detected
          </div>
        </div>
      </div>

      {/* Schools Directory Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Registered School Tenants</h2>
            <p className="text-xs text-slate-500">Each school is an isolated database tenant with dedicated limits</p>
          </div>
          <span className="text-xs font-medium text-slate-500 font-mono tabular-nums">
            {tenants.length} tenants registered
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">School Name & Code</th>
                <th className="py-3 px-4">Admin Contact</th>
                <th className="py-3 px-4">Subscription Plan</th>
                <th className="py-3 px-4">Usage (Students/Cap)</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {tenants.map(tenant => {
                const plan = plans.find(p => p.id === tenant.planId);
                const schoolStudents = students.filter(s => s.tenantId === tenant.id).length;
                const schoolTeachers = teachers.filter(t => t.tenantId === tenant.id).length;

                return (
                  <tr key={tenant.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{tenant.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        Code: {tenant.code} · subdomain: {tenant.subdomain}.edupulse.io
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div>{tenant.contactEmail}</div>
                      <div className="text-slate-400 text-[11px]">{tenant.contactPhone}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-semibold text-slate-900">{plan?.name}</span>
                      <div className="text-[11px] text-slate-500 font-mono">
                        ${plan?.pricePerMonth}/mo · Max {plan?.maxStudents} students
                      </div>
                    </td>
                    <td className="py-3.5 px-4 font-mono tabular-nums">
                      <div className="text-slate-900">
                        {schoolStudents} / {plan?.maxStudents} students
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        {schoolTeachers} / {plan?.maxTeachers} teachers
                      </div>
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold ${
                          tenant.status === 'ACTIVE'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {tenant.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-2">
                      <button
                        onClick={() => switchTenant(tenant.id)}
                        className="px-2.5 py-1 text-xs font-medium text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded transition-colors"
                        title="Enter school view"
                      >
                        Enter School
                      </button>
                      <button
                        onClick={() => toggleSchoolStatus(tenant.id)}
                        className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                          tenant.status === 'ACTIVE'
                            ? 'text-rose-700 bg-rose-50 hover:bg-rose-100'
                            : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                        }`}
                        title={tenant.status === 'ACTIVE' ? 'Suspend Tenant' : 'Activate Tenant'}
                      >
                        <Power className="w-3.5 h-3.5 inline" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Subscription Plans Matrix */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
        <h2 className="text-sm font-semibold text-slate-900 mb-1">Configured SaaS Subscription Tiers</h2>
        <p className="text-xs text-slate-500 mb-4">Hard limits enforced automatically by LimitEnforcementService</p>

        <div className="grid md:grid-cols-3 gap-4">
          {plans.map(plan => (
            <div key={plan.id} className="p-4 border border-slate-200 rounded-lg bg-slate-50/50 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900">{plan.name}</span>
                  <span className="text-xs font-mono font-bold text-indigo-600">${plan.pricePerMonth}/mo</span>
                </div>
                <p className="text-xs text-slate-500 mt-1">{plan.description}</p>

                <div className="mt-4 space-y-2 text-xs">
                  <div className="flex justify-between border-b border-slate-200 pb-1">
                    <span className="text-slate-500">Max Students</span>
                    <span className="font-mono font-semibold text-slate-900">{plan.maxStudents}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200 pb-1">
                    <span className="text-slate-500">Max Faculty</span>
                    <span className="font-mono font-semibold text-slate-900">{plan.maxTeachers}</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-200 pb-1">
                    <span className="text-slate-500">Storage Cap</span>
                    <span className="font-mono font-semibold text-slate-900">{plan.maxStorageMb} MB</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 text-[11px] text-slate-500">
                <span className="font-semibold text-slate-700">Included Modules: </span>
                {plan.modulesEnabled.join(', ')}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal: Onboard New School */}
      {newSchoolModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="text-sm font-semibold">Onboard New School Tenant</h3>
              <button onClick={() => setNewSchoolModalOpen(false)} className="text-slate-400 hover:text-white text-xs">✕</button>
            </div>
            <form onSubmit={handleCreateSchool} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">School Name *</label>
                  <input
                    type="text"
                    required
                    value={schoolName}
                    onChange={e => setSchoolName(e.target.value)}
                    placeholder="e.g. Apex Horizon School"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">School Code (Unique) *</label>
                  <input
                    type="text"
                    required
                    value={schoolCode}
                    onChange={e => setSchoolCode(e.target.value.toUpperCase())}
                    placeholder="e.g. APEX-01"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md font-mono uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Contact Email *</label>
                  <input
                    type="email"
                    required
                    value={contactEmail}
                    onChange={e => setContactEmail(e.target.value)}
                    placeholder="admin@apexschool.edu"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={contactPhone}
                    onChange={e => setContactPhone(e.target.value)}
                    placeholder="+1 (555) 300-1234"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Principal / Admin Name</label>
                  <input
                    type="text"
                    value={adminName}
                    onChange={e => setAdminName(e.target.value)}
                    placeholder="Dr. Robert Henderson"
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Subscription Plan</label>
                  <select
                    value={selectedPlanCode}
                    onChange={e => setSelectedPlanCode(e.target.value as any)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-md bg-white"
                  >
                    <option value="FREE">Starter Trial (Free - 100 students)</option>
                    <option value="BASIC">Standard Campus ($49/mo - 500 students)</option>
                    <option value="PREMIUM">Enterprise ($149/mo - 2500 students)</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setNewSchoolModalOpen(false)}
                  className="px-3 py-1.5 border border-slate-200 text-slate-700 rounded-md hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-md shadow-xs"
                >
                  Complete Onboarding
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
