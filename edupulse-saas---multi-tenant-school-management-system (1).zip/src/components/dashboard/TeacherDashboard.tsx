import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  CalendarCheck,
  Award,
  Clock,
  BookOpen,
  ArrowRight,
  GraduationCap,
  CheckCircle,
} from 'lucide-react';

interface TeacherDashboardProps {
  onNavigateTab: (tab: string) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({ onNavigateTab }) => {
  const { currentUser, currentTenant, getTenantStudents, getTenantClasses, getTenantRoutines } = useApp();

  const students = getTenantStudents();
  const classes = getTenantClasses();
  const routines = getTenantRoutines();

  return (
    <div className="space-y-6">
      {/* Teacher Profile Banner */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">
              Welcome back, {currentUser.firstName} {currentUser.lastName}
            </h1>
            <span className="text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded">
              Faculty Lead
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Department of Science & Mathematics · {currentTenant?.name} · Class Teacher: <span className="font-semibold text-slate-700">Grade 10-A</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab('attendance')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-lg text-xs shadow-xs transition-colors"
          >
            <CalendarCheck className="w-3.5 h-3.5" />
            <span>Mark 10-A Attendance</span>
          </button>
          <button
            onClick={() => onNavigateTab('exams')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg text-xs shadow-xs transition-colors"
          >
            <Award className="w-3.5 h-3.5" />
            <span>Enter Mid-Term Marks</span>
          </button>
        </div>
      </div>

      {/* Teaching Overview Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>My Assigned Students</span>
            <GraduationCap className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{students.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Grade 10-A Class Register</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Today's Classes</span>
            <Clock className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">3 Periods</div>
          <div className="text-[11px] text-slate-500 mt-1">Math (08:30) · Lab (10:30)</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Exams Evaluation Status</span>
            <Award className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">100% Graded</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Mid-term math marks submitted</div>
        </div>
      </div>

      {/* Routine Slots Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-900">Today's Teaching Schedule</h2>
            <p className="text-xs text-slate-500">Conflict-free timetable synced with master academic registry</p>
          </div>
          <button
            onClick={() => onNavigateTab('routine')}
            className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
          >
            <span>View Full Routine</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-2">
          {routines.slice(0, 3).map((slot, idx) => (
            <div
              key={slot.id}
              className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-700 flex items-center justify-center font-bold text-xs font-mono">
                  0{idx + 1}
                </div>
                <div>
                  <div className="font-semibold text-slate-900 flex items-center gap-2">
                    <span>Grade 10 · Section A</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-indigo-600 font-medium">{slot.roomNumber}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    Time: {slot.startTime} - {slot.endTime} · Day: {slot.dayOfWeek}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  <CheckCircle className="w-3 h-3" />
                  Scheduled
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
