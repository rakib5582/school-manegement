import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  Users,
  CalendarCheck,
  CreditCard,
  Plus,
  ArrowRight,
  TrendingUp,
  Clock,
  Bell,
  CheckCircle2,
} from 'lucide-react';

interface SchoolAdminDashboardProps {
  onNavigateTab: (tab: string) => void;
}

export const SchoolAdminDashboard: React.FC<SchoolAdminDashboardProps> = ({ onNavigateTab }) => {
  const {
    currentTenant,
    getTenantStudents,
    getTenantTeachers,
    getTenantClasses,
    getTenantAttendance,
    getTenantInvoices,
    getTenantPayments,
    getTenantNotices,
    plans,
  } = useApp();

  const students = getTenantStudents();
  const teachers = getTenantTeachers();
  const classes = getTenantClasses();
  const attendanceToday = getTenantAttendance();
  const invoices = getTenantInvoices();
  const payments = getTenantPayments();
  const notices = getTenantNotices();

  const presentToday = attendanceToday.filter(a => a.status === 'PRESENT').length;
  const attendanceRate = attendanceToday.length > 0
    ? Math.round((presentToday / attendanceToday.length) * 100)
    : 100;

  const totalInvoiced = invoices.reduce((sum, i) => sum + i.totalAmount, 0);
  const totalPaid = invoices.reduce((sum, i) => sum + i.paidAmount, 0);
  const totalDue = totalInvoiced - totalPaid;

  const activePlan = plans.find(p => p.id === currentTenant?.planId);

  return (
    <div className="space-y-6">
      {/* Banner / Header */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">{currentTenant?.name}</h1>
            <span className="text-[11px] font-semibold font-mono bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded">
              {currentTenant?.code}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Academic Session: <span className="font-semibold text-slate-700">{currentTenant?.academicYearName}</span> · Plan:{' '}
            <span className="font-semibold text-indigo-600">{activePlan?.name}</span> ({students.length}/{activePlan?.maxStudents} enrolled students)
          </p>
        </div>

        {/* Quick operational shortcuts */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => onNavigateTab('students')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg text-xs shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Enroll Student</span>
          </button>
          <button
            onClick={() => onNavigateTab('attendance')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-medium rounded-lg text-xs transition-colors"
          >
            <CalendarCheck className="w-3.5 h-3.5 text-slate-500" />
            <span>Mark Attendance</span>
          </button>
          <button
            onClick={() => onNavigateTab('fees')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-medium rounded-lg text-xs transition-colors"
          >
            <CreditCard className="w-3.5 h-3.5 text-slate-500" />
            <span>Generate Invoices</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Enrolled Students</span>
            <GraduationCap className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{students.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            Across {classes.length} active class grades
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Faculty & Teachers</span>
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{teachers.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">
            Cap: {activePlan?.maxTeachers} teachers
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Today's Attendance</span>
            <CalendarCheck className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{attendanceRate}%</div>
          <div className="text-[11px] text-slate-500 mt-1">
            {presentToday} of {attendanceToday.length || students.length} present today
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Fees Collected / Due</span>
            <CreditCard className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">
            ${totalPaid.toLocaleString()}
          </div>
          <div className="text-[11px] text-amber-700 font-medium mt-1 font-mono tabular-nums">
            ${totalDue.toLocaleString()} outstanding dues
          </div>
        </div>
      </div>

      {/* Two Column Layout: Recent Payments & Notice Board */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Recent Fee Receipts */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Recent Payment Collections</h2>
              <p className="text-xs text-slate-500">Official fee receipts issued this session</p>
            </div>
            <button
              onClick={() => onNavigateTab('fees')}
              className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-2.5">
            {payments.slice(0, 4).map(p => {
              const inv = invoices.find(i => i.id === p.invoiceId);
              const stu = students.find(s => s.id === inv?.studentId);
              return (
                <div key={p.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                      <span className="font-mono text-indigo-700">{p.receiptNumber}</span>
                      <span>·</span>
                      <span>{stu?.admissionNumber || 'Student'}</span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Method: <span className="font-medium">{p.paymentMethod}</span> · {new Date(p.paidAt).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-sm text-slate-900 font-mono tabular-nums">${p.amount}</span>
                    <div className="text-[10px] text-emerald-600 font-semibold uppercase tracking-wider">Paid</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent School Notices */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Active Circulars & Notices</h2>
              <p className="text-xs text-slate-500">Broadcast announcements to students and parents</p>
            </div>
            <button
              onClick={() => onNavigateTab('notices')}
              className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
            >
              <span>Manage</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {notices.map(n => (
              <div key={n.id} className="p-3 border border-slate-200 rounded-lg hover:border-slate-300 transition-colors">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-900">{n.title}</span>
                  <span className="text-[10px] font-mono text-slate-400">{n.publishedDate}</span>
                </div>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">{n.content}</p>
                <div className="mt-2 flex items-center gap-2 text-[10px] text-slate-400">
                  <span>Audience: <strong className="text-slate-700 font-medium">{n.targetAudience}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
