import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  GraduationCap,
  CalendarCheck,
  Award,
  CreditCard,
  Clock,
  Printer,
  BadgeCheck,
  CheckCircle2,
} from 'lucide-react';

interface StudentDashboardProps {
  onOpenIdCard: () => void;
  onOpenTranscript: () => void;
  onNavigateTab: (tab: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  onOpenIdCard,
  onOpenTranscript,
  onNavigateTab,
}) => {
  const { currentUser, currentTenant, getTenantStudents, getTenantAttendance, getTenantInvoices, getTenantRoutines } = useApp();

  const students = getTenantStudents();
  // Find current student record
  const currentStudent = students.find(s => s.userId === currentUser.id) || students[0];
  const invoices = getTenantInvoices().filter(i => i.studentId === currentStudent?.id);
  const routines = getTenantRoutines();

  return (
    <div className="space-y-6">
      {/* Student Banner */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-blue-600 text-white font-bold text-lg flex items-center justify-center shadow-xs">
            {currentUser.firstName[0]}
            {currentUser.lastName[0]}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 tracking-tight">
                {currentUser.firstName} {currentUser.lastName}
              </h1>
              <span className="text-xs font-mono font-semibold bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded">
                Roll #{currentStudent?.rollNumber}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Admission: <span className="font-mono font-semibold text-slate-700">{currentStudent?.admissionNumber}</span> · Grade 10-A · {currentTenant?.name}
            </p>
          </div>
        </div>

        {/* Action Buttons: ID Card & Transcript */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onOpenIdCard}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors"
          >
            <BadgeCheck className="w-4 h-4" />
            <span>Print Student ID Card</span>
          </button>
          <button
            onClick={onOpenTranscript}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs shadow-xs transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Official Grade Transcript</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Overall Attendance</span>
            <CalendarCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">98.5%</div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Present on all recorded days</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Academic Performance</span>
            <Award className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">GPA 4.0 / A+</div>
          <div className="text-[11px] text-slate-500 mt-1">Mid-Term Examinations</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Tuition Status</span>
            <CreditCard className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-emerald-600 mt-2">PAID</div>
          <div className="text-[11px] text-slate-500 mt-1">Receipt: REC-GW-90412</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Class Timetable</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-2 font-mono tabular-nums">{routines.length} Slots</div>
          <div className="text-[11px] text-slate-500 mt-1">Next: Math (Room 301)</div>
        </div>
      </div>

      {/* Two Column Section */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Weekly Routine */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-1">My Weekly Timetable</h2>
          <p className="text-xs text-slate-500 mb-3">Room locations and assigned faculty</p>

          <div className="space-y-2">
            {routines.map((r, i) => (
              <div key={r.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-slate-900">Period 0{i + 1} · {r.roomNumber}</div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    {r.startTime} - {r.endTime} · {r.dayOfWeek}
                  </div>
                </div>
                <span className="text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  Confirmed
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Invoices and Payments */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-1">Fee Invoices & Receipts</h2>
          <p className="text-xs text-slate-500 mb-3">Official billing record with voucher receipts</p>

          <div className="space-y-2.5">
            {invoices.map(inv => (
              <div key={inv.id} className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-slate-900">{inv.title}</div>
                  <div className="text-[11px] text-slate-500 font-mono">
                    {inv.invoiceNumber} · Due: {inv.dueDate}
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-bold font-mono tabular-nums text-slate-900">${inv.totalAmount}</span>
                  <div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded uppercase">
                      {inv.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
