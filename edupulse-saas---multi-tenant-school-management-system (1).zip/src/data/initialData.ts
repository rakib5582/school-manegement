import {
  SubscriptionPlan,
  Tenant,
  User,
  SchoolClass,
  Section,
  Subject,
  Teacher,
  Parent,
  Student,
  AttendanceRecord,
  Exam,
  Mark,
  FeeInvoice,
  PaymentRecord,
  RoutineSlot,
  Assignment,
  Notice,
  SchoolEvent,
  Book,
  TransportRoute,
  HostelRoom,
  AuditLog,
} from '../types';

export const INITIAL_PLANS: SubscriptionPlan[] = [
  {
    id: 'a0000000-0000-0000-0000-000000000001',
    name: 'Starter Trial',
    code: 'FREE',
    description: 'Free tier for small learning centers up to 100 students',
    pricePerMonth: 0,
    maxStudents: 100,
    maxTeachers: 10,
    maxStorageMb: 512,
    modulesEnabled: ['ACADEMIC', 'ATTENDANCE', 'FEES'],
  },
  {
    id: 'a0000000-0000-0000-0000-000000000002',
    name: 'Standard Campus',
    code: 'BASIC',
    description: 'Core school operations for up to 500 students',
    pricePerMonth: 49,
    maxStudents: 500,
    maxTeachers: 35,
    maxStorageMb: 2048,
    modulesEnabled: ['ACADEMIC', 'ATTENDANCE', 'FEES', 'EXAMS', 'ROUTINE', 'NOTICES'],
  },
  {
    id: 'a0000000-0000-0000-0000-000000000003',
    name: 'Enterprise Academy',
    code: 'PREMIUM',
    description: 'Full-featured enterprise SaaS tier with all modules and priority support',
    pricePerMonth: 149,
    maxStudents: 2500,
    maxTeachers: 150,
    maxStorageMb: 10240,
    modulesEnabled: ['ACADEMIC', 'ATTENDANCE', 'FEES', 'EXAMS', 'ROUTINE', 'NOTICES', 'LIBRARY', 'TRANSPORT', 'HOSTEL', 'AUDIT'],
  },
];

export const INITIAL_TENANTS: Tenant[] = [
  {
    id: '11111111-1111-1111-1111-111111111111',
    code: 'GREENWOOD',
    name: 'Greenwood International Academy',
    subdomain: 'greenwood',
    contactEmail: 'contact@greenwood.edu',
    contactPhone: '+1 (555) 234-5678',
    address: '450 University Blvd, Cambridge, MA',
    primaryColor: '#4F46E5',
    secondaryColor: '#06B6D4',
    timezone: 'Asia/Dhaka',
    currency: 'USD',
    academicYearName: '2026-2027',
    planId: 'a0000000-0000-0000-0000-000000000003',
    status: 'ACTIVE',
    subscriptionExpiresAt: '2027-10-01T00:00:00Z',
  },
  {
    id: '22222222-2222-2222-2222-222222222222',
    code: 'OAKRIDGE',
    name: 'Oakridge Science & Arts School',
    subdomain: 'oakridge',
    contactEmail: 'info@oakridge.edu',
    contactPhone: '+1 (555) 876-5432',
    address: '124 Science Park Lane, Austin, TX',
    primaryColor: '#059669',
    secondaryColor: '#10B981',
    timezone: 'America/Chicago',
    currency: 'USD',
    academicYearName: '2026-2027',
    planId: 'a0000000-0000-0000-0000-000000000002',
    status: 'ACTIVE',
    subscriptionExpiresAt: '2027-10-01T00:00:00Z',
  },
];

export const INITIAL_USERS: User[] = [
  // Super Admin
  {
    id: '99999999-9999-9999-9999-999999999999',
    tenantId: null,
    username: 'superadmin',
    email: 'superadmin@saas-edupulse.com',
    role: 'SUPER_ADMIN',
    firstName: 'Platform',
    lastName: 'SuperAdmin',
    phone: '+1 (800) 555-0199',
    active: true,
  },
  // School 1 (Greenwood) Admin
  {
    id: '10000000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'admin_greenwood',
    email: 'admin@greenwood.edu',
    role: 'SCHOOL_ADMIN',
    firstName: 'Eleanor',
    lastName: 'Vance',
    phone: '+1 (555) 234-5601',
    active: true,
  },
  // School 1 Teacher (Ms. Sarah Jenkins)
  {
    id: '10000000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'teacher_sarah',
    email: 'teacher.sarah@greenwood.edu',
    role: 'TEACHER',
    firstName: 'Sarah',
    lastName: 'Jenkins',
    phone: '+1 (555) 234-5602',
    active: true,
  },
  // School 1 Teacher 2 (Mr. David Miller)
  {
    id: '10000000-0000-0000-0000-000000000003',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'teacher_david',
    email: 'teacher.david@greenwood.edu',
    role: 'TEACHER',
    firstName: 'David',
    lastName: 'Miller',
    phone: '+1 (555) 234-5603',
    active: true,
  },
  // School 1 Parent (Robert Rivera)
  {
    id: '10000000-0000-0000-0000-000000000004',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'parent_robert',
    email: 'parent.robert@greenwood.edu',
    role: 'PARENT',
    firstName: 'Robert',
    lastName: 'Rivera',
    phone: '+1 (555) 234-5604',
    active: true,
  },
  // School 1 Student (Alex Rivera)
  {
    id: '10000000-0000-0000-0000-000000000005',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'student_alex',
    email: 'student.alex@greenwood.edu',
    role: 'STUDENT',
    firstName: 'Alex',
    lastName: 'Rivera',
    phone: '+1 (555) 234-5605',
    active: true,
  },
  // School 1 Student 2 (Sophia Chen)
  {
    id: '10000000-0000-0000-0000-000000000006',
    tenantId: '11111111-1111-1111-1111-111111111111',
    username: 'student_sophia',
    email: 'student.sophia@greenwood.edu',
    role: 'STUDENT',
    firstName: 'Sophia',
    lastName: 'Chen',
    phone: '+1 (555) 234-5606',
    active: true,
  },
  // School 2 (Oakridge) Admin
  {
    id: '20000000-0000-0000-0000-000000000001',
    tenantId: '22222222-2222-2222-2222-222222222222',
    username: 'admin_oakridge',
    email: 'admin@oakridge.edu',
    role: 'SCHOOL_ADMIN',
    firstName: 'Marcus',
    lastName: 'Sterling',
    phone: '+1 (555) 876-5401',
    active: true,
  },
  // School 2 Student
  {
    id: '20000000-0000-0000-0000-000000000002',
    tenantId: '22222222-2222-2222-2222-222222222222',
    username: 'student_lucas',
    email: 'student.lucas@oakridge.edu',
    role: 'STUDENT',
    firstName: 'Lucas',
    lastName: 'Bennett',
    phone: '+1 (555) 876-5402',
    active: true,
  },
];

export const INITIAL_CLASSES: SchoolClass[] = [
  { id: '10200000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Grade 10', numericGrade: 10 },
  { id: '10200000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Grade 9', numericGrade: 9 },
  { id: '20200000-0000-0000-0000-000000000001', tenantId: '22222222-2222-2222-2222-222222222222', name: 'Science Class X', numericGrade: 10 },
];

export const INITIAL_SECTIONS: Section[] = [
  { id: '10300000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', classId: '10200000-0000-0000-0000-000000000001', name: 'Section A', capacity: 35 },
  { id: '10300000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', classId: '10200000-0000-0000-0000-000000000001', name: 'Section B', capacity: 35 },
  { id: '20300000-0000-0000-0000-000000000001', tenantId: '22222222-2222-2222-2222-222222222222', classId: '20200000-0000-0000-0000-000000000001', name: 'Section Alpha', capacity: 30 },
];

export const INITIAL_SUBJECTS: Subject[] = [
  { id: '10400000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Mathematics', code: 'MATH-101', type: 'THEORY', fullMarks: 100, passMarks: 40 },
  { id: '10400000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Physics', code: 'PHY-102', type: 'THEORY', fullMarks: 100, passMarks: 40 },
  { id: '10400000-0000-0000-0000-000000000003', tenantId: '11111111-1111-1111-1111-111111111111', name: 'English Literature', code: 'ENG-103', type: 'THEORY', fullMarks: 100, passMarks: 40 },
  { id: '10400000-0000-0000-0000-000000000004', tenantId: '11111111-1111-1111-1111-111111111111', name: 'Computer Science', code: 'CS-104', type: 'PRACTICAL', fullMarks: 100, passMarks: 40 },
  { id: '20400000-0000-0000-0000-000000000001', tenantId: '22222222-2222-2222-2222-222222222222', name: 'Advanced Chemistry', code: 'OAK-CHEM', type: 'THEORY', fullMarks: 100, passMarks: 40 },
];

export const INITIAL_TEACHERS: Teacher[] = [
  {
    id: '10500000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000002',
    employeeId: 'T-GW-001',
    designation: 'Senior Mathematics Teacher',
    department: 'Science & Mathematics',
    qualification: 'M.Sc in Applied Mathematics',
    joiningDate: '2021-08-15',
    salary: 5200,
    status: 'ACTIVE',
  },
  {
    id: '10500000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000003',
    employeeId: 'T-GW-002',
    designation: 'Physics Faculty Lead',
    department: 'Science & Mathematics',
    qualification: 'Ph.D in Physics',
    joiningDate: '2020-07-01',
    salary: 5800,
    status: 'ACTIVE',
  },
];

export const INITIAL_PARENTS: Parent[] = [
  {
    id: '10600000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000004',
    occupation: 'Lead Architect',
    relationship: 'Father',
  },
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: '10700000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000005',
    parentId: '10600000-0000-0000-0000-000000000001',
    admissionNumber: 'GW-2026-0101',
    rollNumber: '101',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    gender: 'Male',
    dateOfBirth: '2010-04-12',
    bloodGroup: 'O+',
    emergencyContact: '+1 (555) 234-5604',
    admissionDate: '2024-09-01',
    status: 'ACTIVE',
  },
  {
    id: '10700000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000006',
    parentId: null,
    admissionNumber: 'GW-2026-0102',
    rollNumber: '102',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    gender: 'Female',
    dateOfBirth: '2010-08-25',
    bloodGroup: 'A+',
    emergencyContact: '+1 (555) 234-5699',
    admissionDate: '2024-09-01',
    status: 'ACTIVE',
  },
  {
    id: '20700000-0000-0000-0000-000000000001',
    tenantId: '22222222-2222-2222-2222-222222222222',
    userId: '20000000-0000-0000-0000-000000000002',
    parentId: null,
    admissionNumber: 'OAK-2026-0099',
    rollNumber: '99',
    classId: '20200000-0000-0000-0000-000000000001',
    sectionId: '20300000-0000-0000-0000-000000000001',
    gender: 'Male',
    dateOfBirth: '2010-03-15',
    bloodGroup: 'B+',
    emergencyContact: '+1 (555) 876-5401',
    admissionDate: '2025-01-10',
    status: 'ACTIVE',
  },
];

const todayStr = new Date().toISOString().split('T')[0];

export const INITIAL_ATTENDANCE: AttendanceRecord[] = [
  {
    id: '10800000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000001',
    attendanceDate: todayStr,
    status: 'PRESENT',
    remarks: 'On time',
  },
  {
    id: '10800000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000002',
    attendanceDate: todayStr,
    status: 'PRESENT',
    remarks: 'On time',
  },
];

export const INITIAL_EXAMS: Exam[] = [
  {
    id: '10900000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    name: 'Mid-Term Examinations 2026',
    startDate: '2026-10-15',
    endDate: '2026-10-25',
    published: true,
  },
];

export const INITIAL_MARKS: Mark[] = [
  {
    id: '10910000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    examId: '10900000-0000-0000-0000-000000000001',
    studentId: '10700000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000001',
    obtainedMarks: 94.5,
    totalMarks: 100,
    grade: 'A+',
    remarks: 'Outstanding analytical problem solving',
  },
  {
    id: '10910000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    examId: '10900000-0000-0000-0000-000000000001',
    studentId: '10700000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000002',
    obtainedMarks: 88,
    totalMarks: 100,
    grade: 'A',
    remarks: 'Strong laboratory and theory understanding',
  },
  {
    id: '10910000-0000-0000-0000-000000000003',
    tenantId: '11111111-1111-1111-1111-111111111111',
    examId: '10900000-0000-0000-0000-000000000001',
    studentId: '10700000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000004',
    obtainedMarks: 98,
    totalMarks: 100,
    grade: 'A+',
    remarks: 'Perfect algorithm implementation',
  },
];

export const INITIAL_INVOICES: FeeInvoice[] = [
  {
    id: '11100000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000001',
    invoiceNumber: 'INV-GW-2026-0042',
    title: 'October 2026 Tuition & Science Lab Fee',
    totalAmount: 450,
    paidAmount: 450,
    dueDate: '2026-10-20',
    status: 'PAID',
  },
  {
    id: '11100000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    studentId: '10700000-0000-0000-0000-000000000002',
    invoiceNumber: 'INV-GW-2026-0043',
    title: 'October 2026 Tuition & Science Lab Fee',
    totalAmount: 450,
    paidAmount: 0,
    dueDate: '2026-10-20',
    status: 'UNPAID',
  },
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: '11200000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    invoiceId: '11100000-0000-0000-0000-000000000001',
    receiptNumber: 'REC-GW-90412',
    amount: 450,
    paymentMethod: 'ONLINE',
    transactionId: 'TXN_CH_994827101',
    paidAt: new Date().toISOString(),
  },
];

export const INITIAL_ROUTINES: RoutineSlot[] = [
  {
    id: '11300000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000001',
    teacherId: '10500000-0000-0000-0000-000000000001',
    dayOfWeek: 'MONDAY',
    startTime: '08:30',
    endTime: '09:20',
    roomNumber: 'Room 301',
  },
  {
    id: '11300000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000002',
    teacherId: '10500000-0000-0000-0000-000000000002',
    dayOfWeek: 'MONDAY',
    startTime: '09:30',
    endTime: '10:20',
    roomNumber: 'Physics Lab A',
  },
  {
    id: '11300000-0000-0000-0000-000000000003',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000004',
    teacherId: '10500000-0000-0000-0000-000000000001',
    dayOfWeek: 'TUESDAY',
    startTime: '10:30',
    endTime: '11:20',
    roomNumber: 'Computer Lab 2',
  },
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: '11400000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    classId: '10200000-0000-0000-0000-000000000001',
    sectionId: '10300000-0000-0000-0000-000000000001',
    subjectId: '10400000-0000-0000-0000-000000000001',
    teacherId: '10500000-0000-0000-0000-000000000001',
    title: 'Quadratic Equations & Polynomial Proofs',
    description: 'Solve exercises 4.1 through 4.5 from chapter 4. Show comprehensive step-by-step proofs.',
    dueDate: '2026-10-18',
    totalPoints: 50,
  },
];

export const INITIAL_NOTICES: Notice[] = [
  {
    id: '11500000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Annual Science & Robotics Exhibition 2026',
    content: 'All Grade 9 and Grade 10 students must submit their project proposals to their respective department heads by October 25th.',
    targetAudience: 'ALL',
    publishedDate: todayStr,
  },
  {
    id: '11500000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Quarterly Parent-Teacher Conference',
    content: 'The first quarterly conference will take place in the Main Auditorium this Saturday from 9:00 AM to 1:00 PM.',
    targetAudience: 'PARENTS',
    publishedDate: todayStr,
  },
];

export const INITIAL_EVENTS: SchoolEvent[] = [
  {
    id: '11600000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Fall Semester Mid-Term Examinations',
    description: 'Comprehensive mid-term exams across all secondary grade divisions.',
    eventDate: '2026-10-15',
    eventType: 'EXAM',
  },
  {
    id: '11600000-0000-0000-0000-000000000002',
    tenantId: '11111111-1111-1111-1111-111111111111',
    title: 'Inter-House Athletics Championship',
    description: 'Track and field events, relay race, and high jump competitions.',
    eventDate: '2026-11-04',
    eventType: 'SPORTS',
  },
];

export const INITIAL_BOOKS: Book[] = [
  { id: '11700000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', title: 'Calculus: Early Transcendentals', author: 'James Stewart', isbn: '978-1305272378', totalCopies: 15, availableCopies: 12, rackNumber: 'RACK-MATH-03' },
  { id: '11700000-0000-0000-0000-000000000002', tenantId: '11111111-1111-1111-1111-111111111111', title: 'Principles of Modern Physics', author: 'Halliday & Resnick', isbn: '978-0470556535', totalCopies: 20, availableCopies: 18, rackNumber: 'RACK-PHY-01' },
];

export const INITIAL_ROUTES: TransportRoute[] = [
  { id: '11800000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', routeName: 'North Cambridge - Harvard Sq Loop', vehicleNumber: 'BUS-GW-04', driverName: 'Thomas Anderson', driverPhone: '+1 (555) 901-2345', fareMonthly: 65 },
];

export const INITIAL_HOSTELS: HostelRoom[] = [
  { id: '11900000-0000-0000-0000-000000000001', tenantId: '11111111-1111-1111-1111-111111111111', buildingName: 'Newton Hall (Senior Boys)', roomNumber: 'N-204', bedCount: 2, monthlyFee: 220 },
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: '12000000-0000-0000-0000-000000000001',
    tenantId: '11111111-1111-1111-1111-111111111111',
    userId: '10000000-0000-0000-0000-000000000001',
    userEmail: 'admin@greenwood.edu',
    action: 'TENANT_BOOTSTRAP',
    entityName: 'Tenant',
    entityId: '11111111-1111-1111-1111-111111111111',
    ipAddress: '127.0.0.1',
    description: 'Initial school configuration verified and active',
    createdAt: new Date().toISOString(),
  },
];
