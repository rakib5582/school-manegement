export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  timestamp?: string;
}

export interface PageResponse<T> {
  content: T[];
  pageNumber: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  isLast: boolean;
}

export interface PaginationParams {
  page?: number;
  size?: number;
  sort?: string;
  [key: string]: any;
}

// Auth DTOs
export interface LoginRequest {
  emailOrUsername: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  tokenType: string;
  userId: string;
  tenantId: string | null;
  tenantCode: string | null;
  schoolName: string | null;
  username: string;
  email: string;
  fullName: string;
  role: 'SUPER_ADMIN' | 'SCHOOL_ADMIN' | 'TEACHER' | 'STUDENT' | 'PARENT';
}

export interface RegisterSchoolRequest {
  schoolCode: string;
  schoolName: string;
  contactEmail: string;
  contactPhone?: string;
  address?: string;
  adminUsername: string;
  adminPassword: string;
  adminFirstName: string;
  adminLastName: string;
  planCode: 'FREE' | 'BASIC' | 'PREMIUM';
}

// Student DTOs
export interface CreateStudentRequest {
  firstName: string;
  lastName: string;
  email: string;
  admissionNumber: string;
  rollNumber?: string;
  classId: string;
  sectionId: string;
  gender?: string;
  dateOfBirth?: string;
  bloodGroup?: string;
  phone?: string;
  emergencyContact?: string;
  parentId?: string;
}

export interface StudentResponse {
  id: string;
  tenantId: string;
  userId: string;
  admissionNumber: string;
  rollNumber: string;
  fullName: string;
  email: string;
  phone?: string;
  className: string;
  sectionName: string;
  gender?: string;
  dateOfBirth?: string;
  bloodGroup?: string;
  status: string;
  avatarUrl?: string;
}

// Teacher DTOs
export interface CreateTeacherRequest {
  firstName: string;
  lastName: string;
  email: string;
  employeeId: string;
  designation: string;
  department?: string;
  qualification?: string;
  joiningDate?: string;
  salary?: number;
  phone?: string;
}

export interface TeacherResponse {
  id: string;
  tenantId: string;
  userId: string;
  employeeId: string;
  fullName: string;
  email: string;
  phone?: string;
  designation: string;
  department?: string;
  qualification?: string;
  joiningDate?: string;
  salary?: number;
  status: string;
}

// Parent DTOs
export interface CreateParentRequest {
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  occupation: string;
  relationship: string;
  studentId?: string;
}

export interface ParentResponse {
  id: string;
  tenantId: string;
  userId: string;
  fullName: string;
  email: string;
  phone?: string;
  occupation: string;
  relationship: string;
  wardCount: number;
}

// Academic DTOs
export interface SchoolClassDTO {
  id: string;
  tenantId: string;
  name: string;
  numericGrade: number;
}

export interface SectionDTO {
  id: string;
  tenantId: string;
  classId: string;
  name: string;
  capacity?: number;
}

export interface SubjectDTO {
  id: string;
  tenantId: string;
  name: string;
  code: string;
  type: string;
  fullMarks?: number;
  passMarks?: number;
}

// Attendance DTOs
export interface MarkStudentAttendanceRequest {
  studentId: string;
  status: 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE';
  remarks?: string;
}

export interface BulkAttendanceRequest {
  classId: string;
  sectionId: string;
  date: string;
  records: MarkStudentAttendanceRequest[];
}

export interface AttendanceSummaryResponse {
  date: string;
  totalStudents: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  attendancePercentage: number;
}

// Exam & Result DTOs
export interface CreateExamRequest {
  name: string;
  startDate: string;
  endDate: string;
}

export interface EntryMarkItem {
  studentId: string;
  obtainedMarks: number;
  totalMarks?: number;
  remarks?: string;
}

export interface SubmitSubjectMarksRequest {
  examId: string;
  subjectId: string;
  entries: EntryMarkItem[];
}

export interface SubjectMarkDetail {
  subjectName: string;
  subjectCode: string;
  obtainedMarks: number;
  totalMarks: number;
  grade: string;
  remarks?: string;
}

export interface StudentTranscriptResponse {
  studentId: string;
  studentName: string;
  admissionNumber: string;
  className: string;
  sectionName: string;
  examName: string;
  subjectMarks: SubjectMarkDetail[];
  totalObtained: number;
  totalPossible: number;
  percentage: number;
  overallGrade: string;
  gpa: number;
  passFailStatus: string;
}

// Fee DTOs
export interface CreateInvoiceRequest {
  studentId: string;
  title: string;
  totalAmount: number;
  dueDate: string;
}

export interface RecordPaymentRequest {
  invoiceId: string;
  amount: number;
  paymentMethod: 'CASH' | 'CARD' | 'BANK_TRANSFER' | 'ONLINE';
  transactionId?: string;
}

export interface InvoiceResponse {
  id: string;
  studentId: string;
  studentName?: string;
  invoiceNumber: string;
  title: string;
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  dueDate: string;
  status: string;
}

export interface ReceiptResponse {
  paymentId: string;
  receiptNumber: string;
  invoiceNumber: string;
  studentName: string;
  amountPaid: number;
  paymentMethod: string;
  transactionId?: string;
  paidAt: string;
}

// Routine DTOs
export interface CreateRoutineRequest {
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  dayOfWeek: string;
  startTime: string; // HH:mm:ss or HH:mm
  endTime: string;   // HH:mm:ss or HH:mm
  roomNumber: string;
}

export interface RoutineResponse {
  id: string;
  tenantId: string;
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  roomNumber: string;
}

// Assignment DTOs
export interface CreateAssignmentRequest {
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  title: string;
  description: string;
  dueDate: string;
  totalPoints: number;
}

export interface AssignmentResponse {
  id: string;
  tenantId: string;
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  title: string;
  description: string;
  dueDate: string;
  totalPoints: number;
  className?: string;
  sectionName?: string;
  subjectName?: string;
}

// Notice DTOs
export interface NoticeResponse {
  id: string;
  tenantId: string;
  title: string;
  content: string;
  targetAudience: string;
  publishedDate: string;
}

// School Event DTOs
export interface CreateEventRequest {
  title: string;
  description: string;
  eventDate: string;
  eventType: string;
}

export interface SchoolEventResponse {
  id: string;
  tenantId: string;
  title: string;
  description: string;
  eventDate: string;
  eventType: string;
}

// Library DTOs
export interface CreateBookRequest {
  title: string;
  author: string;
  isbn: string;
  totalCopies: number;
  rackNumber: string;
}

export interface BookResponse {
  id: string;
  tenantId: string;
  title: string;
  author: string;
  isbn: string;
  totalCopies: number;
  availableCopies: number;
  rackNumber: string;
}

// Transport DTOs
export interface CreateRouteRequest {
  routeName: string;
  vehicleNumber: string;
  driverName: string;
  driverPhone: string;
  fareMonthly: number;
}

export interface TransportRouteResponse {
  id: string;
  tenantId: string;
  routeName: string;
  vehicleNumber: string;
  driverName: string;
  driverPhone: string;
  fareMonthly: number;
}

// Hostel DTOs
export interface CreateHostelRequest {
  buildingName: string;
  roomNumber: string;
  bedCount: number;
  monthlyFee: number;
}

export interface HostelResponse {
  id: string;
  tenantId: string;
  buildingName: string;
  roomNumber: string;
  bedCount: number;
  monthlyFee: number;
}

// Report DTOs
export interface AttendanceReportResponse {
  date: string;
  totalEnrollment: number;
  presentCount: number;
  absentCount: number;
  lateCount: number;
  attendancePercentage: number;
}

export interface FinanceReportResponse {
  totalInvoiced: number;
  totalCollected: number;
  totalOutstanding: number;
  collectionRatePercentage: number;
}

// Tenant & Dashboard DTOs
export interface TenantDetailResponse {
  id: string;
  code: string;
  name: string;
  subdomain: string;
  contactEmail: string;
  contactPhone?: string;
  address?: string;
  status: string;
  planCode: string;
  planName: string;
  maxStudents: number;
  maxTeachers: number;
  currentStudents: number;
  currentTeachers: number;
  primaryColor?: string;
}

export interface SuperAdminDashboardStats {
  totalSchools: number;
  activeSchools: number;
  suspendedSchools: number;
  totalUsers: number;
  totalStudents: number;
  totalTeachers: number;
  monthlyRevenueEstimate: number;
}

export interface SchoolAdminDashboardStats {
  schoolName: string;
  schoolCode: string;
  totalStudents: number;
  totalTeachers: number;
  totalClasses: number;
  totalParents: number;
  todayAttendanceRate: number;
  totalFeesCollected: number;
  totalFeesDue: number;
  upcomingExamsCount: number;
  pendingInvoicesCount: number;
}

export interface UpdateTenantSettingsRequest {
  name?: string;
  contactEmail?: string;
  contactPhone?: string;
  address?: string;
  primaryColor?: string;
  secondaryColor?: string;
  timezone?: string;
  currency?: string;
  academicYearName?: string;
}
