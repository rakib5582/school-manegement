import { apiClient } from '../client';
import {
  SuperAdminDashboardStats,
  TenantDetailResponse,
  SchoolAdminDashboardStats,
  UpdateTenantSettingsRequest,
  PageResponse,
  PaginationParams,
} from '../types';

export const tenantService = {
  async getSuperAdminDashboard(): Promise<SuperAdminDashboardStats> {
    return apiClient.get<SuperAdminDashboardStats>('/super-admin/dashboard');
  },

  async getAllTenants(params?: PaginationParams): Promise<PageResponse<TenantDetailResponse>> {
    return apiClient.get<PageResponse<TenantDetailResponse>>('/super-admin/tenants', params);
  },

  async updateTenantStatus(id: string, status: string): Promise<void> {
    return apiClient.patch<void>(`/super-admin/tenants/${id}/status`, null, {
      params: { status },
    });
  },

  async getSchoolAdminDashboard(): Promise<SchoolAdminDashboardStats> {
    return apiClient.get<SchoolAdminDashboardStats>('/school-admin/dashboard');
  },

  async getTenantSettings(): Promise<TenantDetailResponse> {
    return apiClient.get<TenantDetailResponse>('/tenant/settings');
  },

  async updateTenantSettings(payload: UpdateTenantSettingsRequest): Promise<TenantDetailResponse> {
    return apiClient.put<TenantDetailResponse>('/tenant/settings', payload);
  },
};
