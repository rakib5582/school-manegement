import { apiClient } from '../client';
import { CreateEventRequest, SchoolEventResponse } from '../types';

export const eventService = {
  async getEvents(type?: string): Promise<SchoolEventResponse[]> {
    return apiClient.get<SchoolEventResponse[]>('/events', type ? { type } : undefined);
  },

  async addEvent(payload: CreateEventRequest): Promise<SchoolEventResponse> {
    return apiClient.post<SchoolEventResponse>('/events', payload);
  },
};
