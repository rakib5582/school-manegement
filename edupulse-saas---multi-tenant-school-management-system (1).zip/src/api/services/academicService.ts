import { apiClient } from '../client';
import { SchoolClassDTO, SectionDTO, SubjectDTO } from '../types';

export const academicService = {
  async getClasses(): Promise<SchoolClassDTO[]> {
    return apiClient.get<SchoolClassDTO[]>('/academics/classes');
  },

  async createClass(name: string, numericGrade: number): Promise<SchoolClassDTO> {
    return apiClient.post<SchoolClassDTO>('/academics/classes', null, {
      params: { name, numericGrade },
    });
  },

  async getSections(classId?: string): Promise<SectionDTO[]> {
    return apiClient.get<SectionDTO[]>('/academics/sections', classId ? { classId } : undefined);
  },

  async createSection(classId: string, name: string, capacity?: number): Promise<SectionDTO> {
    return apiClient.post<SectionDTO>('/academics/sections', null, {
      params: { classId, name, capacity },
    });
  },

  async getSubjects(): Promise<SubjectDTO[]> {
    return apiClient.get<SubjectDTO[]>('/academics/subjects');
  },

  async createSubject(params: {
    name: string;
    code: string;
    type?: string;
    fullMarks?: number;
    passMarks?: number;
  }): Promise<SubjectDTO> {
    return apiClient.post<SubjectDTO>('/academics/subjects', null, { params });
  },
};
