import { apiClient } from '../client';
import { CreateRouteRequest, TransportRouteResponse } from '../types';

export const transportService = {
  async getRoutes(): Promise<TransportRouteResponse[]> {
    return apiClient.get<TransportRouteResponse[]>('/transport');
  },

  async addRoute(payload: CreateRouteRequest): Promise<TransportRouteResponse> {
    return apiClient.post<TransportRouteResponse>('/transport', payload);
  },
};
