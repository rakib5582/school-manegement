import { apiClient } from '../client';
import { CreateTeacherRequest, TeacherResponse, PageResponse, PaginationParams } from '../types';

export const teacherService = {
  async getTeachers(params?: PaginationParams): Promise<PageResponse<TeacherResponse>> {
    return apiClient.get<PageResponse<TeacherResponse>>('/teachers', params);
  },

  async getTeacherById(id: string): Promise<TeacherResponse> {
    return apiClient.get<TeacherResponse>(`/teachers/${id}`);
  },

  async createTeacher(payload: CreateTeacherRequest): Promise<TeacherResponse> {
    return apiClient.post<TeacherResponse>('/teachers', payload);
  },
};
