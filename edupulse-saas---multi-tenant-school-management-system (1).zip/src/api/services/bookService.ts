import { apiClient } from '../client';
import { CreateBookRequest, BookResponse } from '../types';

export const bookService = {
  async getBooks(query?: string): Promise<BookResponse[]> {
    return apiClient.get<BookResponse[]>('/books', query ? { query } : undefined);
  },

  async addBook(payload: CreateBookRequest): Promise<BookResponse> {
    return apiClient.post<BookResponse>('/books', payload);
  },

  async issueBook(id: string): Promise<BookResponse> {
    return apiClient.post<BookResponse>(`/books/${id}/issue`);
  },

  async returnBook(id: string): Promise<BookResponse> {
    return apiClient.post<BookResponse>(`/books/${id}/return`);
  },
};
