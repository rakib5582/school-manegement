import { apiClient } from '../client';
import { CreateRoutineRequest, RoutineResponse } from '../types';

export const routineService = {
  async getClassRoutine(classId: string, sectionId: string): Promise<RoutineResponse[]> {
    return apiClient.get<RoutineResponse[]>('/routines', { classId, sectionId });
  },

  async createRoutineSlot(payload: CreateRoutineRequest): Promise<RoutineResponse> {
    return apiClient.post<RoutineResponse>('/routines', payload);
  },
};
