import { apiClient } from '../client';
import { CreateParentRequest, ParentResponse, PageResponse, PaginationParams } from '../types';

export const parentService = {
  async getParents(params?: PaginationParams): Promise<PageResponse<ParentResponse>> {
    return apiClient.get<PageResponse<ParentResponse>>('/parents', params);
  },

  async getParentById(id: string): Promise<ParentResponse> {
    return apiClient.get<ParentResponse>(`/parents/${id}`);
  },

  async getParentWards(id: string): Promise<any[]> {
    return apiClient.get<any[]>(`/parents/${id}/wards`);
  },

  async registerParent(payload: CreateParentRequest): Promise<ParentResponse> {
    return apiClient.post<ParentResponse>('/parents', payload);
  },
};
