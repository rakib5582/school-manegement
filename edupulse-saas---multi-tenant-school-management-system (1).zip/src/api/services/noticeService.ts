import { apiClient } from '../client';
import { NoticeResponse } from '../types';

export const noticeService = {
  async getNotices(audience?: string): Promise<NoticeResponse[]> {
    return apiClient.get<NoticeResponse[]>('/notices', audience ? { audience } : undefined);
  },

  async createNotice(title: string, content: string, audience: string = 'ALL'): Promise<NoticeResponse> {
    return apiClient.post<NoticeResponse>('/notices', null, {
      params: { title, content, audience },
    });
  },
};
