import { apiClient } from '../client';
import { BulkAttendanceRequest, AttendanceSummaryResponse } from '../types';

export const attendanceService = {
  async recordBulkAttendance(payload: BulkAttendanceRequest): Promise<void> {
    return apiClient.post<void>('/attendance/bulk', payload);
  },

  async getDailySummary(date?: string): Promise<AttendanceSummaryResponse> {
    return apiClient.get<AttendanceSummaryResponse>('/attendance/summary', date ? { date } : undefined);
  },

  async getStudentAttendance(studentId: string): Promise<any[]> {
    return apiClient.get<any[]>(`/attendance/student/${studentId}`);
  },
};
