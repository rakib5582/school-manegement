import { apiClient } from '../client';
import { CreateStudentRequest, StudentResponse, PageResponse, PaginationParams } from '../types';

export const studentService = {
  async getStudents(params?: PaginationParams & { classId?: string; sectionId?: string }): Promise<PageResponse<StudentResponse>> {
    return apiClient.get<PageResponse<StudentResponse>>('/students', params);
  },

  async getStudentById(id: string): Promise<StudentResponse> {
    return apiClient.get<StudentResponse>(`/students/${id}`);
  },

  async createStudent(payload: CreateStudentRequest): Promise<StudentResponse> {
    return apiClient.post<StudentResponse>('/students', payload);
  },
};
