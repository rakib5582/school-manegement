import { apiClient } from '../client';
import {
  CreateInvoiceRequest,
  RecordPaymentRequest,
  InvoiceResponse,
  ReceiptResponse,
  PageResponse,
  PaginationParams,
} from '../types';

export const feeService = {
  async getInvoices(params?: PaginationParams): Promise<PageResponse<InvoiceResponse>> {
    return apiClient.get<PageResponse<InvoiceResponse>>('/fees/invoices', params);
  },

  async createInvoice(payload: CreateInvoiceRequest): Promise<InvoiceResponse> {
    return apiClient.post<InvoiceResponse>('/fees/invoices', payload);
  },

  async recordPayment(payload: RecordPaymentRequest): Promise<ReceiptResponse> {
    return apiClient.post<ReceiptResponse>('/fees/payments', payload);
  },
};
