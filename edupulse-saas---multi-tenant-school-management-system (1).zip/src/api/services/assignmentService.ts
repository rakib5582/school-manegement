import { apiClient } from '../client';
import { CreateAssignmentRequest, AssignmentResponse } from '../types';

export const assignmentService = {
  async getAssignments(classId?: string): Promise<AssignmentResponse[]> {
    return apiClient.get<AssignmentResponse[]>('/assignments', classId ? { classId } : undefined);
  },

  async createAssignment(payload: CreateAssignmentRequest): Promise<AssignmentResponse> {
    return apiClient.post<AssignmentResponse>('/assignments', payload);
  },
};
