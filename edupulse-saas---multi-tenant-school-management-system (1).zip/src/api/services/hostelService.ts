import { apiClient } from '../client';
import { CreateHostelRequest, HostelResponse } from '../types';

export const hostelService = {
  async getHostels(): Promise<HostelResponse[]> {
    return apiClient.get<HostelResponse[]>('/hostels');
  },

  async addRoom(payload: CreateHostelRequest): Promise<HostelResponse> {
    return apiClient.post<HostelResponse>('/hostels', payload);
  },
};
