import { apiClient } from '../client';
import { AttendanceReportResponse, FinanceReportResponse } from '../types';

export const reportService = {
  async getAttendanceReport(date?: string): Promise<AttendanceReportResponse> {
    return apiClient.get<AttendanceReportResponse>('/reports/attendance', date ? { date } : undefined);
  },

  async getFinanceReport(): Promise<FinanceReportResponse> {
    return apiClient.get<FinanceReportResponse>('/reports/finance');
  },
};
