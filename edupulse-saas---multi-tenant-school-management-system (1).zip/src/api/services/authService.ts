import { apiClient, tokenStorage } from '../client';
import { LoginRequest, LoginResponse, RegisterSchoolRequest } from '../types';

export const authService = {
  async login(credentials: LoginRequest): Promise<LoginResponse> {
    const response = await apiClient.post<LoginResponse>('/auth/login', credentials, { skipAuth: true });
    if (response && response.token) {
      tokenStorage.setToken(response.token);
      tokenStorage.setSession(response);
      localStorage.setItem('edupulse_auth', 'true');
    }
    return response;
  },

  async registerSchool(data: RegisterSchoolRequest): Promise<LoginResponse> {
    const response = await apiClient.post<LoginResponse>('/auth/register-school', data, { skipAuth: true });
    if (response && response.token) {
      tokenStorage.setToken(response.token);
      tokenStorage.setSession(response);
      localStorage.setItem('edupulse_auth', 'true');
    }
    return response;
  },

  logout(): void {
    tokenStorage.clearAll();
  },

  getCurrentSession(): LoginResponse | null {
    return tokenStorage.getSession();
  },

  isAuthenticated(): boolean {
    return !!tokenStorage.getToken();
  },
};
