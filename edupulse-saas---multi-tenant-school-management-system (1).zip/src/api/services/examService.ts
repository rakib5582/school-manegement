import { apiClient } from '../client';
import { SubmitSubjectMarksRequest, StudentTranscriptResponse } from '../types';

export const examService = {
  async submitMarks(payload: SubmitSubjectMarksRequest): Promise<void> {
    return apiClient.post<void>('/exams/marks', payload);
  },

  async getTranscript(examId: string, studentId: string): Promise<StudentTranscriptResponse> {
    return apiClient.get<StudentTranscriptResponse>('/results/transcript', { examId, studentId });
  },
};
