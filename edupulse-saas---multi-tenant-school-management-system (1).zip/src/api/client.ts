import { ApiResponse, PageResponse } from './types';

export class ApiError extends Error {
  status: number;
  data?: any;
  validationErrors?: Record<string, string>;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
    if (data && typeof data === 'object' && data.errors) {
      this.validationErrors = data.errors;
    }
  }
}

// Token storage helpers
const TOKEN_KEY = 'edupulse_jwt_token';
const SESSION_KEY = 'edupulse_auth_session';

export const tokenStorage = {
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  },
  setToken(token: string) {
    localStorage.setItem(TOKEN_KEY, token);
  },
  removeToken() {
    localStorage.removeItem(TOKEN_KEY);
  },
  getSession(): any | null {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },
  setSession(session: any) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  },
  removeSession() {
    localStorage.removeItem(SESSION_KEY);
  },
  clearAll() {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(SESSION_KEY);
    localStorage.setItem('edupulse_auth', 'false');
  },
};

// Base URL configuration
const getBaseUrl = (): string => {
  const envUrl = import.meta.env.VITE_API_BASE_URL;
  if (envUrl && typeof envUrl === 'string' && envUrl.trim() !== '') {
    return envUrl.replace(/\/+$/, '');
  }
  return '';
};

export interface RequestOptions extends RequestInit {
  params?: Record<string, any>;
  skipAuth?: boolean;
}

class ApiClient {
  private baseUrl: string;

  constructor() {
    this.baseUrl = getBaseUrl();
  }

  public setBaseUrl(url: string) {
    this.baseUrl = url.replace(/\/+$/, '');
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  private buildUrl(path: string, params?: Record<string, any>): string {
    let cleanPath = path;
    if (!cleanPath.startsWith('/')) {
      cleanPath = '/' + cleanPath;
    }
    if (!cleanPath.startsWith('/api/v1')) {
      cleanPath = '/api/v1' + cleanPath;
    }

    const fullUrl = this.baseUrl ? `${this.baseUrl}${cleanPath}` : cleanPath;

    if (!params || Object.keys(params).length === 0) {
      return fullUrl;
    }

    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        query.append(key, String(value));
      }
    });

    const queryString = query.toString();
    return queryString ? `${fullUrl}?${queryString}` : fullUrl;
  }

  public async request<T = any>(path: string, options: RequestOptions = {}): Promise<T> {
    const { params, skipAuth = false, headers = {}, ...customConfig } = options;
    const url = this.buildUrl(path, params);

    const reqHeaders: Record<string, string> = {
      Accept: 'application/json',
      ...((headers as Record<string, string>) || {}),
    };

    if (!(customConfig.body instanceof FormData)) {
      reqHeaders['Content-Type'] = 'application/json';
    }

    if (!skipAuth) {
      const token = tokenStorage.getToken();
      if (token) {
        reqHeaders['Authorization'] = `Bearer ${token}`;
      }
    }

    let response: Response;
    try {
      response = await fetch(url, {
        ...customConfig,
        headers: reqHeaders,
      });
    } catch (networkError: any) {
      throw new ApiError(
        networkError.message || 'Network connection failed. Please check your internet or backend server.',
        0,
        networkError
      );
    }

    // Handle 401 Unauthorized
    if (response.status === 401) {
      tokenStorage.clearAll();
      window.dispatchEvent(new CustomEvent('edupulse:unauthorized'));
      throw new ApiError('Session expired or unauthorized. Please sign in again.', 401);
    }

    // Handle 403 Forbidden
    if (response.status === 403) {
      throw new ApiError('Access forbidden: You do not have permission for this resource.', 403);
    }

    // Handle 404 Not Found
    if (response.status === 404) {
      throw new ApiError('Requested resource was not found.', 404);
    }

    // Parse JSON
    let parsed: any = null;
    const contentType = response.headers.get('content-type');
    if (contentType && contentType.includes('application/json')) {
      try {
        parsed = await response.json();
      } catch {
        parsed = null;
      }
    } else {
      const text = await response.text();
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }

    // Handle 400/422 validation errors or 500 server errors
    if (!response.ok) {
      let message = 'Server operation failed';
      if (parsed && typeof parsed === 'object') {
        if (parsed.message) {
          message = parsed.message;
        } else if (parsed.error) {
          message = parsed.error;
        } else if (Array.isArray(parsed.errors)) {
          message = parsed.errors.map((e: any) => e.defaultMessage || e.message || String(e)).join(', ');
        }
      }
      throw new ApiError(message, response.status, parsed);
    }

    // If response matches ApiResponse envelope { success, message, data }
    if (parsed && typeof parsed === 'object' && 'success' in parsed && 'data' in parsed) {
      if (parsed.success === false) {
        throw new ApiError(parsed.message || 'Operation failed', response.status, parsed);
      }
      return parsed.data as T;
    }

    return parsed as T;
  }

  public get<T = any>(path: string, params?: Record<string, any>, options: RequestOptions = {}): Promise<T> {
    return this.request<T>(path, { ...options, method: 'GET', params });
  }

  public post<T = any>(path: string, body?: any, options: RequestOptions = {}): Promise<T> {
    return this.request<T>(path, {
      ...options,
      method: 'POST',
      body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined,
    });
  }

  public put<T = any>(path: string, body?: any, options: RequestOptions = {}): Promise<T> {
    return this.request<T>(path, {
      ...options,
      method: 'PUT',
      body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined,
    });
  }

  public patch<T = any>(path: string, body?: any, options: RequestOptions = {}): Promise<T> {
    return this.request<T>(path, {
      ...options,
      method: 'PATCH',
      body: body instanceof FormData ? body : body !== undefined ? JSON.stringify(body) : undefined,
    });
  }

  public delete<T = any>(path: string, options: RequestOptions = {}): Promise<T> {
    return this.request<T>(path, { ...options, method: 'DELETE' });
  }
}

export const apiClient = new ApiClient();
