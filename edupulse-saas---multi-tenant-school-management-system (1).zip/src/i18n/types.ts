export type Language = 'en' | 'bn';

export interface TranslationDictionary {
  // Brand & Common
  appName: string;
  tagline: string;
  taglineDesc: string;
  login: string;
  logout: string;
  signIn: string;
  signUp: string;
  search: string;
  filter: string;
  save: string;
  cancel: string;
  create: string;
  add: string;
  edit: string;
  delete: string;
  view: string;
  print: string;
  export: string;
  status: string;
  active: string;
  inactive: string;
  suspended: string;
  actions: string;
  all: string;
  back: string;
  submit: string;
  success: string;
  error: string;
  loading: string;
  noData: string;
  language: string;
  english: string;
  bangla: string;
  role: string;
  tenant: string;
  switchTenant: string;
  switchRole: string;
  demoSwitcher: string;
  securityLab: string;
  springBootCode: string;
  apiDocs: string;
  getStarted: string;
  requestDemo: string;
  dashboard: string;
  academics: string;
  students: string;
  teachers: string;
  parents: string;
  attendance: string;
  examinations: string;
  fees: string;
  timetable: string;
  homework: string;
  noticeBoard: string;
  events: string;
  library: string;
  transport: string;
  hostel: string;
  reports: string;
  settings: string;
  auditLogs: string;
  schools: string;
  subscriptions: string;

  // Roles
  superAdmin: string;
  schoolAdmin: string;
  teacher: string;
  student: string;
  parent: string;

  // Landing Page
  heroTitle: string;
  heroHighlight: string;
  heroSubtitle: string;
  heroCtaStart: string;
  heroCtaDemo: string;
  heroBadge: string;
  statsSchools: string;
  statsStudents: string;
  statsUptime: string;
  statsSecurity: string;

  featuresTitle: string;
  featuresSubtitle: string;
  featuresBadge: string;

  roleExperienceTitle: string;
  roleExperienceSubtitle: string;

  saasBenefitsTitle: string;
  saasBenefitsSubtitle: string;

  mobileTitle: string;
  mobileSubtitle: string;
  mobileBadge: string;

  securityTitle: string;
  securitySubtitle: string;

  pricingTitle: string;
  pricingSubtitle: string;
  monthly: string;
  annual: string;
  perMonth: string;
  currentPlan: string;
  selectPlan: string;
  popular: string;

  testimonialsTitle: string;
  testimonialsSubtitle: string;

  faqTitle: string;
  faqSubtitle: string;

  contactTitle: string;
  contactSubtitle: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  contactSchool: string;
  contactMessage: string;
  contactSend: string;
  contactSent: string;

  footerProduct: string;
  footerFeatures: string;
  footerPricing: string;
  footerDocs: string;
  footerContact: string;
  footerPrivacy: string;
  footerTerms: string;
  footerRights: string;

  // Academic & Student
  classesCount: string;
  sectionsCount: string;
  subjectsCount: string;
  admissionNo: string;
  rollNo: string;
  studentName: string;
  fatherName: string;
  motherName: string;
  guardian: string;
  dob: string;
  gender: string;
  bloodGroup: string;
  emergencyContact: string;
  printIdCard: string;
  studentProfile: string;
  enrollNewStudent: string;

  // Teacher & Staff
  employeeId: string;
  designation: string;
  department: string;
  qualification: string;
  salary: string;
  joiningDate: string;
  addTeacher: string;

  // Attendance
  present: string;
  absent: string;
  late: string;
  excused: string;
  attendanceRate: string;
  markAttendance: string;
  selectDate: string;

  // Exams & Marks
  examName: string;
  examType: string;
  maxMarks: string;
  marksObtained: string;
  grade: string;
  gpa: string;
  transcript: string;
  generateReportCard: string;
  scheduleExam: string;
  publishResult: string;

  // Fees
  invoiceNo: string;
  amount: string;
  paidAmount: string;
  dueAmount: string;
  dueDate: string;
  paymentMethod: string;
  createInvoice: string;
  collectPayment: string;
  feeReceipt: string;

  // Timetable & Homework
  dayOfWeek: string;
  timeSlot: string;
  roomNo: string;
  subject: string;
  conflictWarning: string;
  dueDateHomework: string;
  submissionCount: string;
  createAssignment: string;

  // Library, Transport, Hostel
  bookTitle: string;
  author: string;
  isbn: string;
  copiesAvailable: string;
  issueBook: string;
  returnBook: string;
  routeName: string;
  vehicleNo: string;
  driverName: string;
  driverPhone: string;
  hostelBuilding: string;
  roomNumber: string;
  bedCount: string;

  // Settings & System
  schoolName: string;
  schoolEmail: string;
  schoolPhone: string;
  schoolAddress: string;
  academicYear: string;
  timezone: string;
  currency: string;
  saveChanges: string;
  settingsSaved: string;
}
