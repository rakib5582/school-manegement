export type Role = 'SUPER_ADMIN' | 'SCHOOL_ADMIN' | 'TEACHER' | 'STUDENT' | 'PARENT';

export interface SubscriptionPlan {
  id: string;
  name: string;
  code: 'FREE' | 'BASIC' | 'PREMIUM';
  description: string;
  pricePerMonth: number;
  maxStudents: number;
  maxTeachers: number;
  maxStorageMb: number;
  modulesEnabled: string[];
}

export interface Tenant {
  id: string;
  code: string;
  name: string;
  subdomain: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  primaryColor: string;
  secondaryColor: string;
  timezone: string;
  currency: string;
  academicYearName: string;
  planId: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'TRIAL';
  subscriptionExpiresAt: string;
}

export interface User {
  id: string;
  tenantId?: string | null;
  username: string;
  email: string;
  role: Role;
  firstName: string;
  lastName: string;
  phone?: string;
  avatarUrl?: string;
  active: boolean;
  lastLoginAt?: string;
}

export interface SchoolClass {
  id: string;
  tenantId: string;
  name: string;
  numericGrade: number;
}

export interface Section {
  id: string;
  tenantId: string;
  classId: string;
  name: string;
  capacity: number;
}

export interface Subject {
  id: string;
  tenantId: string;
  name: string;
  code: string;
  type: 'THEORY' | 'PRACTICAL';
  fullMarks: number;
  passMarks: number;
}

export interface Teacher {
  id: string;
  tenantId: string;
  userId: string;
  employeeId: string;
  designation: string;
  department: string;
  qualification: string;
  joiningDate: string;
  salary: number;
  status: 'ACTIVE' | 'ON_LEAVE' | 'TERMINATED';
}

export interface Parent {
  id: string;
  tenantId: string;
  userId: string;
  occupation: string;
  relationship: string;
}

export interface Student {
  id: string;
  tenantId: string;
  userId: string;
  parentId?: string | null;
  admissionNumber: string;
  rollNumber: string;
  classId: string;
  sectionId: string;
  fullName?: string;
  email?: string;
  gender: 'Male' | 'Female' | 'Other';
  dateOfBirth: string;
  bloodGroup: string;
  emergencyContact: string;
  admissionDate: string;
  status: 'ACTIVE' | 'GRADUATED' | 'SUSPENDED';
}

export interface AttendanceRecord {
  id: string;
  tenantId: string;
  studentId: string;
  attendanceDate: string; // YYYY-MM-DD
  status: 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE';
  remarks?: string;
}

export interface Exam {
  id: string;
  tenantId: string;
  name: string;
  startDate: string;
  endDate: string;
  published: boolean;
}

export interface Mark {
  id: string;
  tenantId: string;
  examId: string;
  studentId: string;
  subjectId: string;
  obtainedMarks: number;
  totalMarks: number;
  grade: string;
  remarks?: string;
}

export interface FeeInvoice {
  id: string;
  tenantId: string;
  studentId: string;
  invoiceNumber: string;
  title: string;
  totalAmount: number;
  paidAmount: number;
  dueDate: string;
  status: 'UNPAID' | 'PARTIAL' | 'PAID' | 'OVERDUE';
}

export interface PaymentRecord {
  id: string;
  tenantId: string;
  invoiceId: string;
  receiptNumber: string;
  amount: number;
  paymentMethod: 'CASH' | 'CARD' | 'BANK_TRANSFER' | 'ONLINE';
  transactionId?: string;
  paidAt: string;
}

export interface RoutineSlot {
  id: string;
  tenantId: string;
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  dayOfWeek: 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY';
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  roomNumber: string;
}

export interface Assignment {
  id: string;
  tenantId: string;
  classId: string;
  sectionId: string;
  subjectId: string;
  teacherId: string;
  title: string;
  description: string;
  dueDate: string;
  totalPoints: number;
}

export interface Notice {
  id: string;
  tenantId: string;
  title: string;
  content: string;
  targetAudience: 'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS';
  publishedDate: string;
  expiryDate?: string;
}

export interface SchoolEvent {
  id: string;
  tenantId: string;
  title: string;
  description: string;
  eventDate: string;
  eventType: 'HOLIDAY' | 'MEETING' | 'EXAM' | 'SPORTS' | 'GENERAL';
}

export interface Book {
  id: string;
  tenantId: string;
  title: string;
  author: string;
  isbn: string;
  totalCopies: number;
  availableCopies: number;
  rackNumber: string;
}

export interface TransportRoute {
  id: string;
  tenantId: string;
  routeName: string;
  vehicleNumber: string;
  driverName: string;
  driverPhone: string;
  fareMonthly: number;
}

export interface HostelRoom {
  id: string;
  tenantId: string;
  buildingName: string;
  roomNumber: string;
  bedCount: number;
  monthlyFee: number;
}

export interface AuditLog {
  id: string;
  tenantId?: string | null;
  userId?: string | null;
  userEmail: string;
  action: string;
  entityName: string;
  entityId: string;
  ipAddress: string;
  description: string;
  createdAt: string;
}
