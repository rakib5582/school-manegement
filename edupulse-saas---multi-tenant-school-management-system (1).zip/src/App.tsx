import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LanguageProvider } from './i18n/LanguageContext';
import { LandingPage } from './components/landing/LandingPage';
import { TopNavbar } from './components/layout/TopNavbar';
import { Sidebar } from './components/layout/Sidebar';
import { TenantSecurityLabModal } from './components/layout/TenantSecurityLabModal';

import { SuperAdminDashboard } from './components/dashboard/SuperAdminDashboard';
import { SchoolAdminDashboard } from './components/dashboard/SchoolAdminDashboard';
import { TeacherDashboard } from './components/dashboard/TeacherDashboard';
import { StudentDashboard } from './components/dashboard/StudentDashboard';
import { ParentDashboard } from './components/dashboard/ParentDashboard';

import { StudentManagement } from './components/modules/StudentManagement';
import { TeacherManagement } from './components/modules/TeacherManagement';
import { ParentManagement } from './components/modules/ParentManagement';
import { AcademicManagement } from './components/modules/AcademicManagement';
import { AttendanceRegister } from './components/modules/AttendanceRegister';
import { ExaminationModule } from './components/modules/ExaminationModule';
import { FeeManagement } from './components/modules/FeeManagement';
import { ClassRoutine } from './components/modules/ClassRoutine';
import { HomeworkManagement } from './components/modules/HomeworkManagement';
import { NoticeBoard } from './components/modules/NoticeBoard';
import { EventsManagement } from './components/modules/EventsManagement';
import { LibraryManagement } from './components/modules/LibraryManagement';
import { TransportManagement } from './components/modules/TransportManagement';
import { HostelManagement } from './components/modules/HostelManagement';
import { ReportsManagement } from './components/modules/ReportsManagement';
import { SchoolSettings } from './components/modules/SchoolSettings';
import { ApiDocsExplorer } from './components/modules/ApiDocsExplorer';
import { CodebaseViewer } from './components/modules/CodebaseViewer';

import { StudentIdCardModal } from './components/printable/StudentIdCardModal';
import { TranscriptModal } from './components/printable/TranscriptModal';
import { FeeReceiptModal } from './components/printable/FeeReceiptModal';

import { Student, Exam, FeeInvoice, PaymentRecord } from './types';
import { Menu, ShieldAlert } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { activeRole, currentUser, auditLogs, getTenantStudents, getTenantExams } = useApp();

  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);

  // Modals state
  const [securityLabOpen, setSecurityLabOpen] = useState<boolean>(false);
  const [idCardStudent, setIdCardStudent] = useState<Student | null>(null);
  const [transcriptData, setTranscriptData] = useState<{ student: Student | null; exam: Exam | null }>({
    student: null,
    exam: null,
  });
  const [receiptData, setReceiptData] = useState<{ payment: PaymentRecord | null; invoice: FeeInvoice | null }>({
    payment: null,
    invoice: null,
  });

  const students = getTenantStudents();
  const exams = getTenantExams();
  const currentStudent = students.find(s => s.userId === currentUser.id) || students[0];
  const currentExam = exams[0];

  const renderContent = () => {
    switch (currentTab) {
      case 'dashboard':
        switch (activeRole) {
          case 'SUPER_ADMIN':
            return <SuperAdminDashboard />;
          case 'SCHOOL_ADMIN':
            return <SchoolAdminDashboard onNavigateTab={setCurrentTab} />;
          case 'TEACHER':
            return <TeacherDashboard onNavigateTab={setCurrentTab} />;
          case 'STUDENT':
            return (
              <StudentDashboard
                onOpenIdCard={() => setIdCardStudent(currentStudent)}
                onOpenTranscript={() => setTranscriptData({ student: currentStudent, exam: currentExam })}
                onNavigateTab={setCurrentTab}
              />
            );
          case 'PARENT':
            return (
              <ParentDashboard
                onOpenTranscript={() => setTranscriptData({ student: currentStudent, exam: currentExam })}
                onNavigateTab={setCurrentTab}
              />
            );
          default:
            return <SuperAdminDashboard />;
        }

      case 'academics':
        return <AcademicManagement />;

      case 'students':
        return <StudentManagement onPrintIdCard={s => setIdCardStudent(s)} />;

      case 'teachers':
        return <TeacherManagement />;

      case 'parents':
        return <ParentManagement />;

      case 'attendance':
        return <AttendanceRegister />;

      case 'exams':
        return <ExaminationModule onPrintTranscript={(s, e) => setTranscriptData({ student: s, exam: e })} />;

      case 'fees':
        return <FeeManagement onPrintReceipt={(p, i) => setReceiptData({ payment: p, invoice: i })} />;

      case 'routine':
        return <ClassRoutine />;

      case 'homework':
        return <HomeworkManagement />;

      case 'notices':
        return <NoticeBoard />;

      case 'events':
        return <EventsManagement />;

      case 'library':
        return <LibraryManagement />;

      case 'transport':
        return <TransportManagement />;

      case 'hostel':
        return <HostelManagement />;

      case 'reports':
        return <ReportsManagement />;

      case 'settings':
        return <SchoolSettings />;

      case 'api-docs':
        return <ApiDocsExplorer />;

      case 'codebase':
        return <CodebaseViewer />;

      case 'schools':
      case 'subscriptions':
        return <SuperAdminDashboard />;

      case 'id-card':
        return <StudentManagement onPrintIdCard={s => setIdCardStudent(s)} />;

      case 'audit-logs':
        return (
          <div className="space-y-5">
            <div>
              <h1 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-indigo-600" />
                Immutable Audit Trail & Activity Logs
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                Every sensitive database mutation, authentication event, and cross-tenant access is recorded
              </p>
            </div>

            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4">Action</th>
                    <th className="py-3 px-4">User Email</th>
                    <th className="py-3 px-4">Entity</th>
                    <th className="py-3 px-4">IP Address</th>
                    <th className="py-3 px-4">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-slate-700 font-mono text-[11px]">
                  {auditLogs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-4 text-slate-500 whitespace-nowrap">
                        {new Date(log.createdAt).toLocaleString()}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-indigo-700">{log.action}</td>
                      <td className="py-2.5 px-4 text-slate-900">{log.userEmail}</td>
                      <td className="py-2.5 px-4 text-slate-600">{log.entityName}</td>
                      <td className="py-2.5 px-4 text-slate-400">{log.ipAddress}</td>
                      <td className="py-2.5 px-4 font-sans text-xs text-slate-700">{log.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      default:
        return <SuperAdminDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 flex flex-col font-sans">
      <div className="flex flex-1">
        {/* Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          mobileOpen={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        {/* Main Content Pane */}
        <div className="flex-1 flex flex-col min-w-0">
          <TopNavbar
            currentTab={currentTab}
            onOpenSecurityLab={() => setSecurityLabOpen(true)}
            onOpenCodebase={() => setCurrentTab('codebase')}
            onOpenApiDocs={() => setCurrentTab('api-docs')}
          />

          {/* Mobile menu trigger */}
          <div className="p-3 bg-white border-b border-slate-200 flex items-center gap-2 md:hidden">
            <button
              onClick={() => setMobileSidebarOpen(true)}
              className="p-1.5 text-slate-700 hover:bg-slate-100 rounded-md"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-xs font-semibold text-slate-900 capitalize">
              {currentTab.replace('-', ' ')}
            </span>
          </div>

          <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
            {renderContent()}
          </main>
        </div>
      </div>

      {/* Modals */}
      <TenantSecurityLabModal
        isOpen={securityLabOpen}
        onClose={() => setSecurityLabOpen(false)}
      />

      <StudentIdCardModal
        student={idCardStudent}
        onClose={() => setIdCardStudent(null)}
      />

      <TranscriptModal
        student={transcriptData.student}
        exam={transcriptData.exam}
        onClose={() => setTranscriptData({ student: null, exam: null })}
      />

      <FeeReceiptModal
        payment={receiptData.payment}
        invoice={receiptData.invoice}
        onClose={() => setReceiptData({ payment: null, invoice: null })}
      />
    </div>
  );
};

const AppRoot: React.FC = () => {
  const { isAuthenticated } = useApp();

  if (!isAuthenticated) {
    return <LandingPage />;
  }

  return <MainAppContent />;
};

export default function App() {
  return (
    <LanguageProvider>
      <AppProvider>
        <AppRoot />
      </AppProvider>
    </LanguageProvider>
  );
}
