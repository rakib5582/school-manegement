import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import {
  Role,
  Tenant,
  User,
  SubscriptionPlan,
  Student,
  Teacher,
  Parent,
  SchoolClass,
  Section,
  Subject,
  AttendanceRecord,
  Exam,
  Mark,
  FeeInvoice,
  PaymentRecord,
  RoutineSlot,
  Assignment,
  Notice,
  SchoolEvent,
  Book,
  TransportRoute,
  HostelRoom,
  AuditLog,
} from '../types';
import {
  INITIAL_PLANS,
  INITIAL_TENANTS,
  INITIAL_USERS,
  INITIAL_CLASSES,
  INITIAL_SECTIONS,
  INITIAL_SUBJECTS,
  INITIAL_TEACHERS,
  INITIAL_PARENTS,
  INITIAL_STUDENTS,
  INITIAL_ATTENDANCE,
  INITIAL_EXAMS,
  INITIAL_MARKS,
  INITIAL_INVOICES,
  INITIAL_PAYMENTS,
  INITIAL_ROUTINES,
  INITIAL_ASSIGNMENTS,
  INITIAL_NOTICES,
  INITIAL_EVENTS,
  INITIAL_BOOKS,
  INITIAL_ROUTES,
  INITIAL_HOSTELS,
  INITIAL_AUDIT_LOGS,
} from '../data/initialData';
import {
  authService,
  studentService,
  teacherService,
  parentService,
  academicService,
  attendanceService,
  examService,
  feeService,
  routineService,
  assignmentService,
  noticeService,
  eventService,
  bookService,
  transportService,
  hostelService,
  tenantService,
  tokenStorage,
  ApiError,
} from '../api';

export interface AppContextType {
  currentUser: User;
  currentTenant: Tenant | null;
  activeRole: Role;
  tenants: Tenant[];
  plans: SubscriptionPlan[];
  users: User[];
  students: Student[];
  teachers: Teacher[];
  parents: Parent[];
  classes: SchoolClass[];
  sections: Section[];
  subjects: Subject[];
  attendanceRecords: AttendanceRecord[];
  exams: Exam[];
  marks: Mark[];
  invoices: FeeInvoice[];
  payments: PaymentRecord[];
  routines: RoutineSlot[];
  assignments: Assignment[];
  notices: Notice[];
  events: SchoolEvent[];
  books: Book[];
  routes: TransportRoute[];
  hostels: HostelRoom[];
  auditLogs: AuditLog[];

  // API State
  isLoading: boolean;
  apiError: string | null;
  refreshData: () => Promise<void>;

  // Tenant-scoped filtered getters
  getTenantStudents: () => Student[];
  getTenantTeachers: () => Teacher[];
  getTenantParents: () => Parent[];
  getTenantClasses: () => SchoolClass[];
  getTenantSections: (classId?: string) => Section[];
  getTenantSubjects: () => Subject[];
  getTenantAttendance: (date?: string) => AttendanceRecord[];
  getTenantExams: () => Exam[];
  getTenantInvoices: () => FeeInvoice[];
  getTenantPayments: () => PaymentRecord[];
  getTenantRoutines: (classId?: string, sectionId?: string) => RoutineSlot[];
  getTenantAssignments: () => Assignment[];
  getTenantNotices: (audience?: string) => Notice[];
  getTenantEvents: () => SchoolEvent[];
  getTenantBooks: () => Book[];
  getTenantRoutes: () => TransportRoute[];
  getTenantHostels: () => HostelRoom[];

  // Role & Tenant Switching
  switchRole: (role: Role, userEmail?: string) => Promise<void>;
  switchTenant: (tenantId: string) => void;

  // Actions
  addStudent: (studentData: Omit<Student, 'id' | 'tenantId' | 'userId'> & { firstName: string; lastName: string; email: string }) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addTeacher: (teacherData: Omit<Teacher, 'id' | 'tenantId' | 'userId'> & { firstName: string; lastName: string; email: string }) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addParent: (parentData: { firstName: string; lastName: string; email: string; phone?: string; occupation: string; relationship: string; studentId?: string }) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addClass: (classData: { name: string; numericGrade: number }) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addSection: (sectionData: { classId: string; name: string; capacity: number }) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addSubject: (subjectData: { name: string; code: string; type: 'THEORY' | 'PRACTICAL'; fullMarks: number; passMarks: number }) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  createExam: (examData: { name: string; startDate: string; endDate: string }) => { success: boolean; error?: string };
  recordAttendance: (date: string, records: { studentId: string; status: 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE'; remarks?: string }[]) => Promise<void> | void;
  submitMarks: (examId: string, subjectId: string, markEntries: { studentId: string; obtainedMarks: number; remarks?: string }[]) => Promise<void> | void;
  createInvoice: (studentId: string, title: string, amount: number, dueDate: string) => Promise<void> | void;
  recordPayment: (invoiceId: string, amount: number, method: 'CASH' | 'CARD' | 'BANK_TRANSFER' | 'ONLINE') => Promise<{ receiptNumber: string }> | { receiptNumber: string };
  createRoutineSlot: (slot: Omit<RoutineSlot, 'id' | 'tenantId'>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  createNotice: (title: string, content: string, audience: 'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS') => Promise<void> | void;
  addAssignment: (assignmentData: Omit<Assignment, 'id' | 'tenantId'>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addEvent: (eventData: Omit<SchoolEvent, 'id' | 'tenantId'>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addBook: (bookData: Omit<Book, 'id' | 'tenantId' | 'availableCopies'>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  issueBook: (bookId: string) => Promise<{ success: boolean; message: string }> | { success: boolean; message: string };
  returnBook: (bookId: string) => Promise<{ success: boolean; message: string }> | { success: boolean; message: string };
  addRoute: (routeData: Omit<TransportRoute, 'id' | 'tenantId'>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addHostel: (hostelData: Omit<HostelRoom, 'id' | 'tenantId'>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  updateSchoolSettings: (settings: Partial<Tenant>) => Promise<{ success: boolean; error?: string }> | { success: boolean; error?: string };
  addSchool: (schoolData: { name: string; code: string; email: string; phone: string; planCode: 'FREE' | 'BASIC' | 'PREMIUM'; adminName: string; adminEmail: string }) => Promise<void> | void;
  toggleSchoolStatus: (tenantId: string) => void;

  // Auth & Session
  isAuthenticated: boolean;
  login: (emailOrRole?: string | Role, passwordOrEmail?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;

  // Tenant Isolation Security Audit Tool
  testCrossTenantSecurity: () => {
    attempt: string;
    sourceTenant: string;
    targetTenant: string;
    result: 'BLOCKED' | 'ALLOWED';
    statusCode: number;
    message: string;
  };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Persistence states
  const [tenants, setTenants] = useState<Tenant[]>(() => {
    const saved = localStorage.getItem('edupulse_tenants');
    return saved ? JSON.parse(saved) : INITIAL_TENANTS;
  });

  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('edupulse_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('edupulse_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [teachers, setTeachers] = useState<Teacher[]>(() => {
    const saved = localStorage.getItem('edupulse_teachers');
    return saved ? JSON.parse(saved) : INITIAL_TEACHERS;
  });

  const [parents, setParents] = useState<Parent[]>(() => {
    const saved = localStorage.getItem('edupulse_parents');
    return saved ? JSON.parse(saved) : INITIAL_PARENTS;
  });

  const [classes, setClasses] = useState<SchoolClass[]>(() => {
    const saved = localStorage.getItem('edupulse_classes');
    return saved ? JSON.parse(saved) : INITIAL_CLASSES;
  });

  const [sections, setSections] = useState<Section[]>(() => {
    const saved = localStorage.getItem('edupulse_sections');
    return saved ? JSON.parse(saved) : INITIAL_SECTIONS;
  });

  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem('edupulse_subjects');
    return saved ? JSON.parse(saved) : INITIAL_SUBJECTS;
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(() => {
    const saved = localStorage.getItem('edupulse_attendance');
    return saved ? JSON.parse(saved) : INITIAL_ATTENDANCE;
  });

  const [exams, setExams] = useState<Exam[]>(() => {
    const saved = localStorage.getItem('edupulse_exams');
    return saved ? JSON.parse(saved) : INITIAL_EXAMS;
  });

  const [marks, setMarks] = useState<Mark[]>(() => {
    const saved = localStorage.getItem('edupulse_marks');
    return saved ? JSON.parse(saved) : INITIAL_MARKS;
  });

  const [invoices, setInvoices] = useState<FeeInvoice[]>(() => {
    const saved = localStorage.getItem('edupulse_invoices');
    return saved ? JSON.parse(saved) : INITIAL_INVOICES;
  });

  const [payments, setPayments] = useState<PaymentRecord[]>(() => {
    const saved = localStorage.getItem('edupulse_payments');
    return saved ? JSON.parse(saved) : INITIAL_PAYMENTS;
  });

  const [routines, setRoutines] = useState<RoutineSlot[]>(() => {
    const saved = localStorage.getItem('edupulse_routines');
    return saved ? JSON.parse(saved) : INITIAL_ROUTINES;
  });

  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem('edupulse_assignments');
    return saved ? JSON.parse(saved) : INITIAL_ASSIGNMENTS;
  });

  const [notices, setNotices] = useState<Notice[]>(() => {
    const saved = localStorage.getItem('edupulse_notices');
    return saved ? JSON.parse(saved) : INITIAL_NOTICES;
  });

  const [events, setEvents] = useState<SchoolEvent[]>(() => {
    const saved = localStorage.getItem('edupulse_events');
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [books, setBooks] = useState<Book[]>(() => {
    const saved = localStorage.getItem('edupulse_books');
    return saved ? JSON.parse(saved) : INITIAL_BOOKS;
  });

  const [routes, setRoutes] = useState<TransportRoute[]>(() => {
    const saved = localStorage.getItem('edupulse_routes');
    return saved ? JSON.parse(saved) : INITIAL_ROUTES;
  });

  const [hostels, setHostels] = useState<HostelRoom[]>(() => {
    const saved = localStorage.getItem('edupulse_hostels');
    return saved ? JSON.parse(saved) : INITIAL_HOSTELS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved = localStorage.getItem('edupulse_audit_logs');
    return saved ? JSON.parse(saved) : INITIAL_AUDIT_LOGS;
  });

  // Current active user & tenant & auth state
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const session = tokenStorage.getSession();
    if (session) {
      return {
        id: session.userId,
        tenantId: session.tenantId,
        username: session.username,
        email: session.email,
        role: session.role,
        firstName: session.fullName ? session.fullName.split(' ')[0] : session.username,
        lastName: session.fullName ? session.fullName.split(' ').slice(1).join(' ') : '',
        active: true,
      };
    }
    return INITIAL_USERS[1];
  });

  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(() => {
    const session = tokenStorage.getSession();
    if (session && session.tenantId) {
      const match = INITIAL_TENANTS.find(t => t.id === session.tenantId);
      if (match) return match;
    }
    return INITIAL_TENANTS[0];
  });

  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return authService.isAuthenticated();
  });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [apiError, setApiError] = useState<string | null>(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('edupulse_tenants', JSON.stringify(tenants));
    localStorage.setItem('edupulse_users', JSON.stringify(users));
    localStorage.setItem('edupulse_students', JSON.stringify(students));
    localStorage.setItem('edupulse_teachers', JSON.stringify(teachers));
    localStorage.setItem('edupulse_parents', JSON.stringify(parents));
    localStorage.setItem('edupulse_classes', JSON.stringify(classes));
    localStorage.setItem('edupulse_sections', JSON.stringify(sections));
    localStorage.setItem('edupulse_subjects', JSON.stringify(subjects));
    localStorage.setItem('edupulse_attendance', JSON.stringify(attendanceRecords));
    localStorage.setItem('edupulse_exams', JSON.stringify(exams));
    localStorage.setItem('edupulse_marks', JSON.stringify(marks));
    localStorage.setItem('edupulse_invoices', JSON.stringify(invoices));
    localStorage.setItem('edupulse_payments', JSON.stringify(payments));
    localStorage.setItem('edupulse_routines', JSON.stringify(routines));
    localStorage.setItem('edupulse_assignments', JSON.stringify(assignments));
    localStorage.setItem('edupulse_notices', JSON.stringify(notices));
    localStorage.setItem('edupulse_events', JSON.stringify(events));
    localStorage.setItem('edupulse_books', JSON.stringify(books));
    localStorage.setItem('edupulse_routes', JSON.stringify(routes));
    localStorage.setItem('edupulse_hostels', JSON.stringify(hostels));
    localStorage.setItem('edupulse_audit_logs', JSON.stringify(auditLogs));
  }, [
    tenants,
    users,
    students,
    teachers,
    parents,
    classes,
    sections,
    subjects,
    attendanceRecords,
    exams,
    marks,
    invoices,
    payments,
    routines,
    assignments,
    notices,
    events,
    books,
    routes,
    hostels,
    auditLogs,
  ]);

  // Handle unauthorized event
  useEffect(() => {
    const handleUnauthorized = () => {
      setIsAuthenticated(false);
      tokenStorage.clearAll();
    };
    window.addEventListener('edupulse:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('edupulse:unauthorized', handleUnauthorized);
  }, []);

  // Fetch real data from backend API
  const fetchTenantData = useCallback(async () => {
    setIsLoading(true);
    setApiError(null);
    try {
      // 1. Students
      try {
        const studentPage = await studentService.getStudents({ size: 100 });
        if (studentPage && Array.isArray(studentPage.content)) {
          const mapped: Student[] = studentPage.content.map(s => ({
            id: s.id,
            tenantId: s.tenantId,
            userId: s.userId,
            admissionNumber: s.admissionNumber,
            rollNumber: s.rollNumber || '101',
            classId: classes.find(c => c.name === s.className)?.id || classes[0]?.id || '',
            sectionId: sections.find(sec => sec.name === s.sectionName)?.id || sections[0]?.id || '',
            gender: (s.gender as any) || 'Male',
            dateOfBirth: s.dateOfBirth || '2010-01-01',
            bloodGroup: s.bloodGroup || 'O+',
            emergencyContact: s.phone || '',
            admissionDate: new Date().toISOString().split('T')[0],
            status: (s.status as any) || 'ACTIVE',
          }));
          setStudents(mapped);
        }
      } catch (err: any) {
        console.warn('API sync: students', err.message);
      }

      // 2. Teachers
      try {
        const teacherPage = await teacherService.getTeachers({ size: 100 });
        if (teacherPage && Array.isArray(teacherPage.content)) {
          const mapped: Teacher[] = teacherPage.content.map(t => ({
            id: t.id,
            tenantId: t.tenantId,
            userId: t.userId,
            employeeId: t.employeeId,
            designation: t.designation,
            department: t.department || 'Faculty',
            qualification: t.qualification || 'M.Sc',
            joiningDate: t.joiningDate || new Date().toISOString().split('T')[0],
            salary: t.salary || 5000,
            status: (t.status as any) || 'ACTIVE',
          }));
          setTeachers(mapped);
        }
      } catch (err: any) {
        console.warn('API sync: teachers', err.message);
      }

      // 3. Parents
      try {
        const parentPage = await parentService.getParents({ size: 100 });
        if (parentPage && Array.isArray(parentPage.content)) {
          const mapped: Parent[] = parentPage.content.map(p => ({
            id: p.id,
            tenantId: p.tenantId,
            userId: p.userId,
            occupation: p.occupation,
            relationship: p.relationship,
          }));
          setParents(mapped);
        }
      } catch (err: any) {
        console.warn('API sync: parents', err.message);
      }

      // 4. Classes
      try {
        const classList = await academicService.getClasses();
        if (Array.isArray(classList)) {
          setClasses(classList.map(c => ({
            id: c.id,
            tenantId: c.tenantId,
            name: c.name,
            numericGrade: c.numericGrade,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: classes', err.message);
      }

      // 5. Sections
      try {
        const sectionList = await academicService.getSections();
        if (Array.isArray(sectionList)) {
          setSections(sectionList.map(s => ({
            id: s.id,
            tenantId: s.tenantId,
            classId: s.classId,
            name: s.name,
            capacity: s.capacity || 35,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: sections', err.message);
      }

      // 6. Subjects
      try {
        const subList = await academicService.getSubjects();
        if (Array.isArray(subList)) {
          setSubjects(subList.map(s => ({
            id: s.id,
            tenantId: s.tenantId,
            name: s.name,
            code: s.code,
            type: (s.type as any) || 'THEORY',
            fullMarks: s.fullMarks || 100,
            passMarks: s.passMarks || 40,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: subjects', err.message);
      }

      // 7. Invoices
      try {
        const invoicePage = await feeService.getInvoices({ size: 100 });
        if (invoicePage && Array.isArray(invoicePage.content)) {
          const mapped: FeeInvoice[] = invoicePage.content.map(i => ({
            id: i.id,
            tenantId: currentTenant?.id || tenants[0].id,
            studentId: i.studentId,
            invoiceNumber: i.invoiceNumber,
            title: i.title,
            totalAmount: Number(i.totalAmount),
            paidAmount: Number(i.paidAmount),
            dueDate: i.dueDate,
            status: (i.status as any) || 'UNPAID',
          }));
          setInvoices(mapped);
        }
      } catch (err: any) {
        console.warn('API sync: invoices', err.message);
      }

      // 8. Notices
      try {
        const noticeList = await noticeService.getNotices();
        if (Array.isArray(noticeList)) {
          setNotices(noticeList.map(n => ({
            id: n.id,
            tenantId: n.tenantId,
            title: n.title,
            content: n.content,
            targetAudience: (n.targetAudience as any) || 'ALL',
            publishedDate: n.publishedDate,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: notices', err.message);
      }

      // 9. Events
      try {
        const eventList = await eventService.getEvents();
        if (Array.isArray(eventList)) {
          setEvents(eventList.map(e => ({
            id: e.id,
            tenantId: e.tenantId,
            title: e.title,
            description: e.description,
            eventDate: e.eventDate,
            eventType: (e.eventType as any) || 'GENERAL',
          })));
        }
      } catch (err: any) {
        console.warn('API sync: events', err.message);
      }

      // 10. Books
      try {
        const bookList = await bookService.getBooks();
        if (Array.isArray(bookList)) {
          setBooks(bookList.map(b => ({
            id: b.id,
            tenantId: b.tenantId,
            title: b.title,
            author: b.author,
            isbn: b.isbn,
            totalCopies: b.totalCopies,
            availableCopies: b.availableCopies,
            rackNumber: b.rackNumber,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: books', err.message);
      }

      // 11. Transport
      try {
        const routeList = await transportService.getRoutes();
        if (Array.isArray(routeList)) {
          setRoutes(routeList.map(r => ({
            id: r.id,
            tenantId: r.tenantId,
            routeName: r.routeName,
            vehicleNumber: r.vehicleNumber,
            driverName: r.driverName,
            driverPhone: r.driverPhone,
            fareMonthly: r.fareMonthly,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: transport', err.message);
      }

      // 12. Hostels
      try {
        const hostelList = await hostelService.getHostels();
        if (Array.isArray(hostelList)) {
          setHostels(hostelList.map(h => ({
            id: h.id,
            tenantId: h.tenantId,
            buildingName: h.buildingName,
            roomNumber: h.roomNumber,
            bedCount: h.bedCount,
            monthlyFee: h.monthlyFee,
          })));
        }
      } catch (err: any) {
        console.warn('API sync: hostels', err.message);
      }
    } catch (globalErr: any) {
      setApiError(globalErr.message || 'Error syncing data from backend');
    } finally {
      setIsLoading(false);
    }
  }, [classes, sections, currentTenant, tenants]);

  // Trigger sync on authentication change
  useEffect(() => {
    if (isAuthenticated) {
      fetchTenantData();
    }
  }, [isAuthenticated, fetchTenantData]);

  // Log action
  const logAudit = (action: string, entityName: string, entityId: string, description: string) => {
    const newLog: AuditLog = {
      id: `audit-${Date.now()}`,
      tenantId: currentTenant?.id || null,
      userId: currentUser.id,
      userEmail: currentUser.email,
      action,
      entityName,
      entityId,
      ipAddress: '127.0.0.1 (Authenticated)',
      description,
      createdAt: new Date().toISOString(),
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Real Login implementation calling POST /api/v1/auth/login
  const login = async (
    emailOrRole?: string | Role,
    passwordOrEmail?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);
      setApiError(null);

      let targetEmail = 'admin@greenwood.edu';
      let targetPassword = 'DemoPassword@2026!';

      if (emailOrRole) {
        // If passed a Role enum like 'SUPER_ADMIN', find its email
        if (['SUPER_ADMIN', 'SCHOOL_ADMIN', 'TEACHER', 'STUDENT', 'PARENT'].includes(emailOrRole)) {
          if (passwordOrEmail && passwordOrEmail.includes('@')) {
            targetEmail = passwordOrEmail;
          } else if (emailOrRole === 'SUPER_ADMIN') {
            targetEmail = 'superadmin@saas-edupulse.com';
          } else if (emailOrRole === 'TEACHER') {
            targetEmail = 'teacher.sarah@greenwood.edu';
          } else if (emailOrRole === 'STUDENT') {
            targetEmail = 'student.alex@greenwood.edu';
          } else if (emailOrRole === 'PARENT') {
            targetEmail = 'parent.robert@greenwood.edu';
          } else {
            targetEmail = 'admin@greenwood.edu';
          }
        } else {
          targetEmail = emailOrRole;
          if (passwordOrEmail) targetPassword = passwordOrEmail;
        }
      }

      // Execute Real Backend REST call: POST /api/v1/auth/login
      const loginRes = await authService.login({
        emailOrUsername: targetEmail,
        password: targetPassword,
      });

      const authenticatedUser: User = {
        id: loginRes.userId,
        tenantId: loginRes.tenantId,
        username: loginRes.username,
        email: loginRes.email,
        role: loginRes.role as Role,
        firstName: loginRes.fullName ? loginRes.fullName.split(' ')[0] : loginRes.username,
        lastName: loginRes.fullName ? loginRes.fullName.split(' ').slice(1).join(' ') : '',
        active: true,
      };

      setCurrentUser(authenticatedUser);

      if (loginRes.tenantId) {
        const foundTenant = tenants.find(t => t.id === loginRes.tenantId);
        if (foundTenant) {
          setCurrentTenant(foundTenant);
        } else {
          const freshTenant: Tenant = {
            id: loginRes.tenantId,
            code: loginRes.tenantCode || 'TENANT',
            name: loginRes.schoolName || 'Enrolled School',
            subdomain: (loginRes.tenantCode || 'school').toLowerCase(),
            contactEmail: loginRes.email,
            contactPhone: '+1 (555) 000-0000',
            address: 'Campus Address',
            primaryColor: '#4F46E5',
            secondaryColor: '#06B6D4',
            timezone: 'UTC',
            currency: 'USD',
            academicYearName: '2026-2027',
            planId: INITIAL_PLANS[1].id,
            status: 'ACTIVE',
            subscriptionExpiresAt: '2027-10-01T00:00:00Z',
          };
          setCurrentTenant(freshTenant);
          setTenants(prev => [...prev, freshTenant]);
        }
      } else {
        setCurrentTenant(null); // Super Admin operates globally
      }

      setIsAuthenticated(true);
      logAudit('LOGIN', 'User', authenticatedUser.id, `User signed in successfully as ${authenticatedUser.role}`);

      // Refresh data
      await fetchTenantData();
      return { success: true };
    } catch (err: any) {
      const msg = err.message || 'Login failed. Invalid credentials or network error.';
      setApiError(msg);
      return { success: false, error: msg };
    } finally {
      setIsLoading(false);
    }
  };

  // Role switching using backend authentication
  const switchRole = async (role: Role, userEmail?: string) => {
    let email = userEmail;
    if (!email) {
      if (role === 'SUPER_ADMIN') email = 'superadmin@saas-edupulse.com';
      else if (role === 'TEACHER') email = 'teacher.sarah@greenwood.edu';
      else if (role === 'STUDENT') email = 'student.alex@greenwood.edu';
      else if (role === 'PARENT') email = 'parent.robert@greenwood.edu';
      else email = 'admin@greenwood.edu';
    }
    await login(email, 'DemoPassword@2026!');
  };

  const switchTenant = (tenantId: string) => {
    const tenant = tenants.find(t => t.id === tenantId);
    if (tenant) {
      setCurrentTenant(tenant);
      logAudit('TENANT_SWITCH', 'Tenant', tenant.id, `Context switched to ${tenant.name}`);
      fetchTenantData();
    }
  };

  const logout = () => {
    authService.logout();
    setIsAuthenticated(false);
    setCurrentTenant(null);
  };

  // Filtered Tenant Getters
  const getTenantStudents = () => {
    if (!currentTenant) return students;
    return students.filter(s => s.tenantId === currentTenant.id);
  };

  const getTenantTeachers = () => {
    if (!currentTenant) return teachers;
    return teachers.filter(t => t.tenantId === currentTenant.id);
  };

  const getTenantParents = () => {
    if (!currentTenant) return parents;
    return parents.filter(p => p.tenantId === currentTenant.id);
  };

  const getTenantClasses = () => {
    if (!currentTenant) return classes;
    return classes.filter(c => c.tenantId === currentTenant.id);
  };

  const getTenantSections = (classId?: string) => {
    if (!currentTenant) return sections;
    return sections.filter(s => s.tenantId === currentTenant.id && (!classId || s.classId === classId));
  };

  const getTenantSubjects = () => {
    if (!currentTenant) return subjects;
    return subjects.filter(s => s.tenantId === currentTenant.id);
  };

  const getTenantAttendance = (date?: string) => {
    if (!currentTenant) return attendanceRecords;
    const targetDate = date || new Date().toISOString().split('T')[0];
    return attendanceRecords.filter(a => a.tenantId === currentTenant.id && a.attendanceDate === targetDate);
  };

  const getTenantExams = () => {
    if (!currentTenant) return exams;
    return exams.filter(e => e.tenantId === currentTenant.id);
  };

  const getTenantInvoices = () => {
    if (!currentTenant) return invoices;
    return invoices.filter(i => i.tenantId === currentTenant.id);
  };

  const getTenantPayments = () => {
    if (!currentTenant) return payments;
    return payments.filter(p => p.tenantId === currentTenant.id);
  };

  const getTenantRoutines = (classId?: string, sectionId?: string) => {
    if (!currentTenant) return routines;
    return routines.filter(r =>
      r.tenantId === currentTenant.id &&
      (!classId || r.classId === classId) &&
      (!sectionId || r.sectionId === sectionId)
    );
  };

  const getTenantAssignments = () => {
    if (!currentTenant) return assignments;
    return assignments.filter(a => a.tenantId === currentTenant.id);
  };

  const getTenantNotices = (audience?: string) => {
    if (!currentTenant) return notices;
    return notices.filter(n =>
      n.tenantId === currentTenant.id &&
      (!audience || n.targetAudience === 'ALL' || n.targetAudience === audience)
    );
  };

  const getTenantEvents = () => {
    if (!currentTenant) return events;
    return events.filter(e => e.tenantId === currentTenant.id);
  };

  const getTenantBooks = () => {
    if (!currentTenant) return books;
    return books.filter(b => b.tenantId === currentTenant.id);
  };

  const getTenantRoutes = () => {
    if (!currentTenant) return routes;
    return routes.filter(r => r.tenantId === currentTenant.id);
  };

  const getTenantHostels = () => {
    if (!currentTenant) return hostels;
    return hostels.filter(h => h.tenantId === currentTenant.id);
  };

  // -------------------------------------------------------------
  // MUTATION ACTIONS (Connected to real API services)
  // -------------------------------------------------------------
  const addStudent = async (studentData: Omit<Student, 'id' | 'tenantId' | 'userId'> & { firstName: string; lastName: string; email: string }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };

    try {
      const created = await studentService.createStudent({
        firstName: studentData.firstName,
        lastName: studentData.lastName,
        email: studentData.email,
        admissionNumber: studentData.admissionNumber,
        rollNumber: studentData.rollNumber,
        classId: studentData.classId,
        sectionId: studentData.sectionId,
        gender: studentData.gender,
        dateOfBirth: studentData.dateOfBirth,
        bloodGroup: studentData.bloodGroup,
        emergencyContact: studentData.emergencyContact,
        parentId: studentData.parentId || undefined,
      });

      const newStudent: Student = {
        id: created.id,
        tenantId: created.tenantId,
        userId: created.userId,
        parentId: studentData.parentId || null,
        admissionNumber: created.admissionNumber,
        rollNumber: created.rollNumber,
        classId: studentData.classId,
        sectionId: studentData.sectionId,
        gender: (created.gender as any) || studentData.gender,
        dateOfBirth: created.dateOfBirth || studentData.dateOfBirth,
        bloodGroup: created.bloodGroup || studentData.bloodGroup,
        emergencyContact: studentData.emergencyContact,
        admissionDate: new Date().toISOString().split('T')[0],
        status: (created.status as any) || 'ACTIVE',
      };

      setStudents(prev => [newStudent, ...prev]);
      logAudit('CREATE_STUDENT', 'Student', newStudent.id, `Enrolled student ${studentData.firstName} ${studentData.lastName}`);
      return { success: true };
    } catch (err: any) {
      const msg = err.message || 'Failed to enroll student';
      return { success: false, error: msg };
    }
  };

  const addTeacher = async (teacherData: Omit<Teacher, 'id' | 'tenantId' | 'userId'> & { firstName: string; lastName: string; email: string }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };

    try {
      const created = await teacherService.createTeacher({
        firstName: teacherData.firstName,
        lastName: teacherData.lastName,
        email: teacherData.email,
        employeeId: teacherData.employeeId,
        designation: teacherData.designation,
        department: teacherData.department,
        qualification: teacherData.qualification,
        joiningDate: teacherData.joiningDate,
        salary: teacherData.salary,
      });

      const newTeacher: Teacher = {
        id: created.id,
        tenantId: created.tenantId,
        userId: created.userId,
        employeeId: created.employeeId,
        designation: created.designation,
        department: created.department || 'Faculty',
        qualification: created.qualification || 'M.Sc',
        joiningDate: created.joiningDate || new Date().toISOString().split('T')[0],
        salary: created.salary || 5000,
        status: (created.status as any) || 'ACTIVE',
      };

      setTeachers(prev => [newTeacher, ...prev]);
      logAudit('CREATE_TEACHER', 'Teacher', newTeacher.id, `Added faculty member ${teacherData.firstName} ${teacherData.lastName}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to add teacher' };
    }
  };

  const addParent = async (parentData: { firstName: string; lastName: string; email: string; phone?: string; occupation: string; relationship: string; studentId?: string }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };

    try {
      const created = await parentService.registerParent({
        firstName: parentData.firstName,
        lastName: parentData.lastName,
        email: parentData.email,
        phone: parentData.phone,
        occupation: parentData.occupation,
        relationship: parentData.relationship,
        studentId: parentData.studentId,
      });

      const newParent: Parent = {
        id: created.id,
        tenantId: created.tenantId,
        userId: created.userId,
        occupation: created.occupation,
        relationship: created.relationship,
      };

      setParents(prev => [newParent, ...prev]);
      logAudit('REGISTER_PARENT', 'Parent', newParent.id, `Registered guardian ${parentData.firstName} ${parentData.lastName}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to register guardian' };
    }
  };

  const addClass = async (classData: { name: string; numericGrade: number }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };

    try {
      const created = await academicService.createClass(classData.name, classData.numericGrade);
      const newClass: SchoolClass = {
        id: created.id,
        tenantId: created.tenantId,
        name: created.name,
        numericGrade: created.numericGrade,
      };
      setClasses(prev => [...prev, newClass]);
      logAudit('CREATE_CLASS', 'SchoolClass', newClass.id, `Created academic grade ${classData.name}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create class' };
    }
  };

  const addSection = async (sectionData: { classId: string; name: string; capacity: number }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };

    try {
      const created = await academicService.createSection(sectionData.classId, sectionData.name, sectionData.capacity);
      const newSection: Section = {
        id: created.id,
        tenantId: created.tenantId,
        classId: created.classId,
        name: created.name,
        capacity: created.capacity || 35,
      };
      setSections(prev => [...prev, newSection]);
      logAudit('CREATE_SECTION', 'Section', newSection.id, `Created section ${sectionData.name}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create section' };
    }
  };

  const addSubject = async (subjectData: { name: string; code: string; type: 'THEORY' | 'PRACTICAL'; fullMarks: number; passMarks: number }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };

    try {
      const created = await academicService.createSubject({
        name: subjectData.name,
        code: subjectData.code,
        type: subjectData.type,
        fullMarks: subjectData.fullMarks,
        passMarks: subjectData.passMarks,
      });

      const newSubject: Subject = {
        id: created.id,
        tenantId: created.tenantId,
        name: created.name,
        code: created.code,
        type: subjectData.type,
        fullMarks: created.fullMarks || 100,
        passMarks: created.passMarks || 40,
      };
      setSubjects(prev => [...prev, newSubject]);
      logAudit('CREATE_SUBJECT', 'Subject', newSubject.id, `Added course curriculum ${subjectData.name}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create subject' };
    }
  };

  const createExam = (examData: { name: string; startDate: string; endDate: string }) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    const newExam: Exam = {
      id: `exm-${Date.now()}`,
      tenantId: currentTenant.id,
      name: examData.name,
      startDate: examData.startDate,
      endDate: examData.endDate,
      published: true,
    };
    setExams(prev => [...prev, newExam]);
    logAudit('CREATE_EXAM', 'Exam', newExam.id, `Scheduled assessment ${examData.name}`);
    return { success: true };
  };

  const recordAttendance = async (date: string, recordsList: { studentId: string; status: 'PRESENT' | 'ABSENT' | 'LATE' | 'LEAVE'; remarks?: string }[]) => {
    if (!currentTenant) return;
    try {
      await attendanceService.recordBulkAttendance({
        classId: classes[0]?.id || '',
        sectionId: sections[0]?.id || '',
        date,
        records: recordsList.map(r => ({
          studentId: r.studentId,
          status: r.status,
          remarks: r.remarks,
        })),
      });

      setAttendanceRecords(prev => {
        const filtered = prev.filter(a => !(a.tenantId === currentTenant.id && a.attendanceDate === date));
        const newEntries: AttendanceRecord[] = recordsList.map(r => ({
          id: `att-${Date.now()}-${r.studentId}`,
          tenantId: currentTenant.id,
          studentId: r.studentId,
          attendanceDate: date,
          status: r.status,
          remarks: r.remarks,
        }));
        return [...newEntries, ...filtered];
      });

      logAudit('SUBMIT_ATTENDANCE', 'Attendance', date, `Marked attendance for ${recordsList.length} students on ${date}`);
    } catch (err: any) {
      console.error('Failed to submit attendance:', err.message);
    }
  };

  const submitMarks = async (examId: string, subjectId: string, markEntries: { studentId: string; obtainedMarks: number; remarks?: string }[]) => {
    if (!currentTenant) return;
    try {
      await examService.submitMarks({
        examId,
        subjectId,
        entries: markEntries.map(e => ({
          studentId: e.studentId,
          obtainedMarks: e.obtainedMarks,
          totalMarks: 100,
          remarks: e.remarks,
        })),
      });

      setMarks(prev => {
        const withoutTarget = prev.filter(m => !(m.examId === examId && m.subjectId === subjectId));
        const newMarks: Mark[] = markEntries.map(entry => {
          let grade = 'F';
          if (entry.obtainedMarks >= 90) grade = 'A+';
          else if (entry.obtainedMarks >= 80) grade = 'A';
          else if (entry.obtainedMarks >= 70) grade = 'B';
          else if (entry.obtainedMarks >= 60) grade = 'C';
          else if (entry.obtainedMarks >= 50) grade = 'D';

          return {
            id: `mrk-${Date.now()}-${entry.studentId}`,
            tenantId: currentTenant.id,
            examId,
            studentId: entry.studentId,
            subjectId,
            obtainedMarks: entry.obtainedMarks,
            totalMarks: 100,
            grade,
            remarks: entry.remarks,
          };
        });
        return [...withoutTarget, ...newMarks];
      });

      logAudit('SUBMIT_MARKS', 'ExamResult', examId, `Recorded examination marks for subject ${subjectId}`);
    } catch (err: any) {
      console.error('Failed to submit marks:', err.message);
    }
  };

  const createInvoice = async (studentId: string, title: string, amount: number, dueDate: string) => {
    if (!currentTenant) return;
    try {
      const created = await feeService.createInvoice({
        studentId,
        title,
        totalAmount: amount,
        dueDate,
      });

      const newInvoice: FeeInvoice = {
        id: created.id,
        tenantId: currentTenant.id,
        studentId,
        invoiceNumber: created.invoiceNumber,
        title,
        totalAmount: amount,
        paidAmount: 0,
        dueDate,
        status: 'UNPAID',
      };
      setInvoices(prev => [newInvoice, ...prev]);
      logAudit('CREATE_INVOICE', 'FeeInvoice', newInvoice.id, `Generated invoice ${newInvoice.invoiceNumber} for $${amount}`);
    } catch (err: any) {
      console.error('Failed to create invoice:', err.message);
    }
  };

  const recordPayment = async (invoiceId: string, amount: number, method: 'CASH' | 'CARD' | 'BANK_TRANSFER' | 'ONLINE') => {
    if (!currentTenant) return { receiptNumber: 'REC-ERROR' };
    try {
      const res = await feeService.recordPayment({
        invoiceId,
        amount,
        paymentMethod: method,
      });

      setInvoices(prev => prev.map(inv => {
        if (inv.id === invoiceId) {
          const nextPaid = inv.paidAmount + amount;
          return {
            ...inv,
            paidAmount: nextPaid,
            status: nextPaid >= inv.totalAmount ? 'PAID' : 'PARTIAL',
          };
        }
        return inv;
      }));

      const newPayment: PaymentRecord = {
        id: res.paymentId,
        tenantId: currentTenant.id,
        invoiceId,
        receiptNumber: res.receiptNumber,
        amount,
        paymentMethod: method,
        transactionId: res.transactionId || `TXN_${Date.now()}`,
        paidAt: new Date().toISOString(),
      };
      setPayments(prev => [newPayment, ...prev]);
      logAudit('RECORD_PAYMENT', 'PaymentRecord', newPayment.id, `Cleared fee payment of $${amount} via ${method}`);
      return { receiptNumber: res.receiptNumber };
    } catch (err: any) {
      console.error('Payment error:', err.message);
      return { receiptNumber: `REC-${Date.now().toString().slice(-6)}` };
    }
  };

  const createRoutineSlot = async (slot: Omit<RoutineSlot, 'id' | 'tenantId'>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      const created = await routineService.createRoutineSlot({
        classId: slot.classId,
        sectionId: slot.sectionId,
        subjectId: slot.subjectId,
        teacherId: slot.teacherId,
        dayOfWeek: slot.dayOfWeek,
        startTime: slot.startTime,
        endTime: slot.endTime,
        roomNumber: slot.roomNumber,
      });

      const newSlot: RoutineSlot = {
        id: created.id,
        tenantId: currentTenant.id,
        ...slot,
      };
      setRoutines(prev => [...prev, newSlot]);
      logAudit('CREATE_ROUTINE_SLOT', 'Routine', newSlot.id, `Added timetable slot ${slot.dayOfWeek} ${slot.startTime}-${slot.endTime}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Routine slot conflict' };
    }
  };

  const createNotice = async (title: string, content: string, audience: 'ALL' | 'TEACHERS' | 'STUDENTS' | 'PARENTS') => {
    if (!currentTenant) return;
    try {
      const created = await noticeService.createNotice(title, content, audience);
      const newNotice: Notice = {
        id: created.id,
        tenantId: currentTenant.id,
        title,
        content,
        targetAudience: audience,
        publishedDate: new Date().toISOString().split('T')[0],
      };
      setNotices(prev => [newNotice, ...prev]);
      logAudit('CREATE_NOTICE', 'Notice', newNotice.id, `Published bulletin notice "${title}" to ${audience}`);
    } catch (err: any) {
      console.error('Notice error:', err.message);
    }
  };

  const addAssignment = async (assignmentData: Omit<Assignment, 'id' | 'tenantId'>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      const created = await assignmentService.createAssignment({
        classId: assignmentData.classId,
        sectionId: assignmentData.sectionId,
        subjectId: assignmentData.subjectId,
        teacherId: assignmentData.teacherId,
        title: assignmentData.title,
        description: assignmentData.description,
        dueDate: assignmentData.dueDate,
        totalPoints: assignmentData.totalPoints,
      });

      const newAssignment: Assignment = {
        id: created.id,
        tenantId: currentTenant.id,
        ...assignmentData,
      };
      setAssignments(prev => [newAssignment, ...prev]);
      logAudit('CREATE_ASSIGNMENT', 'Assignment', newAssignment.id, `Published homework "${assignmentData.title}"`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to create assignment' };
    }
  };

  const addEvent = async (eventData: Omit<SchoolEvent, 'id' | 'tenantId'>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      const created = await eventService.addEvent({
        title: eventData.title,
        description: eventData.description,
        eventDate: eventData.eventDate,
        eventType: eventData.eventType,
      });

      const newEvent: SchoolEvent = {
        id: created.id,
        tenantId: currentTenant.id,
        ...eventData,
      };
      setEvents(prev => [newEvent, ...prev]);
      logAudit('CREATE_EVENT', 'SchoolEvent', newEvent.id, `Scheduled school calendar event "${eventData.title}"`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to schedule event' };
    }
  };

  const addBook = async (bookData: Omit<Book, 'id' | 'tenantId' | 'availableCopies'>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      const created = await bookService.addBook({
        title: bookData.title,
        author: bookData.author,
        isbn: bookData.isbn,
        totalCopies: bookData.totalCopies,
        rackNumber: bookData.rackNumber,
      });

      const newBook: Book = {
        id: created.id,
        tenantId: currentTenant.id,
        title: created.title,
        author: created.author,
        isbn: created.isbn,
        totalCopies: created.totalCopies,
        availableCopies: created.availableCopies,
        rackNumber: created.rackNumber,
      };
      setBooks(prev => [newBook, ...prev]);
      logAudit('ADD_BOOK', 'Book', newBook.id, `Cataloged library book "${bookData.title}"`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to catalog book' };
    }
  };

  const issueBook = async (bookId: string) => {
    try {
      await bookService.issueBook(bookId);
      setBooks(prev => prev.map(b => b.id === bookId ? { ...b, availableCopies: Math.max(0, b.availableCopies - 1) } : b));
      logAudit('ISSUE_BOOK', 'Book', bookId, `Issued copy of library book ${bookId}`);
      return { success: true, message: 'Book copy issued successfully to student' };
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to issue book' };
    }
  };

  const returnBook = async (bookId: string) => {
    try {
      await bookService.returnBook(bookId);
      setBooks(prev => prev.map(b => b.id === bookId ? { ...b, availableCopies: Math.min(b.totalCopies, b.availableCopies + 1) } : b));
      logAudit('RETURN_BOOK', 'Book', bookId, `Returned copy of library book ${bookId}`);
      return { success: true, message: 'Book copy safely returned to inventory shelf' };
    } catch (err: any) {
      return { success: false, message: err.message || 'Failed to return book' };
    }
  };

  const addRoute = async (routeData: Omit<TransportRoute, 'id' | 'tenantId'>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      const created = await transportService.addRoute({
        routeName: routeData.routeName,
        vehicleNumber: routeData.vehicleNumber,
        driverName: routeData.driverName,
        driverPhone: routeData.driverPhone,
        fareMonthly: routeData.fareMonthly,
      });

      const newRoute: TransportRoute = {
        id: created.id,
        tenantId: currentTenant.id,
        ...routeData,
      };
      setRoutes(prev => [newRoute, ...prev]);
      logAudit('CREATE_TRANSPORT_ROUTE', 'TransportRoute', newRoute.id, `Registered bus transit route ${routeData.routeName}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to register transport route' };
    }
  };

  const addHostel = async (hostelData: Omit<HostelRoom, 'id' | 'tenantId'>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      const created = await hostelService.addRoom({
        buildingName: hostelData.buildingName,
        roomNumber: hostelData.roomNumber,
        bedCount: hostelData.bedCount,
        monthlyFee: hostelData.monthlyFee,
      });

      const newHostel: HostelRoom = {
        id: created.id,
        tenantId: currentTenant.id,
        ...hostelData,
      };
      setHostels(prev => [newHostel, ...prev]);
      logAudit('CREATE_HOSTEL_ROOM', 'HostelRoom', newHostel.id, `Allocated dormitory room ${hostelData.roomNumber} in ${hostelData.buildingName}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to allocate hostel room' };
    }
  };

  const updateSchoolSettings = async (settings: Partial<Tenant>) => {
    if (!currentTenant) return { success: false, error: 'No active tenant' };
    try {
      await tenantService.updateTenantSettings({
        name: settings.name,
        contactEmail: settings.contactEmail,
        contactPhone: settings.contactPhone,
        address: settings.address,
        primaryColor: settings.primaryColor,
      });

      const updatedTenant: Tenant = {
        ...currentTenant,
        ...settings,
      };
      setCurrentTenant(updatedTenant);
      setTenants(prev => prev.map(t => t.id === currentTenant.id ? updatedTenant : t));
      logAudit('UPDATE_SETTINGS', 'Tenant', currentTenant.id, `Updated school profile configuration for ${currentTenant.name}`);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to update settings' };
    }
  };

  const addSchool = async (schoolData: { name: string; code: string; email: string; phone: string; planCode: 'FREE' | 'BASIC' | 'PREMIUM'; adminName: string; adminEmail: string }) => {
    try {
      await authService.registerSchool({
        schoolCode: schoolData.code,
        schoolName: schoolData.name,
        contactEmail: schoolData.email,
        contactPhone: schoolData.phone,
        adminUsername: `admin_${schoolData.code.toLowerCase()}`,
        adminPassword: 'DemoPassword@2026!',
        adminFirstName: schoolData.adminName.split(' ')[0] || 'Admin',
        adminLastName: schoolData.adminName.split(' ')[1] || 'Principal',
        planCode: schoolData.planCode,
      });

      const plan = INITIAL_PLANS.find(p => p.code === schoolData.planCode) || INITIAL_PLANS[1];
      const newTenantId = `ten-${Date.now()}`;
      const newTenant: Tenant = {
        id: newTenantId,
        code: schoolData.code.toUpperCase(),
        name: schoolData.name,
        subdomain: schoolData.code.toLowerCase(),
        contactEmail: schoolData.email,
        contactPhone: schoolData.phone,
        address: 'Main Campus',
        primaryColor: '#4F46E5',
        secondaryColor: '#06B6D4',
        timezone: 'UTC',
        currency: 'USD',
        academicYearName: '2026-2027',
        planId: plan.id,
        status: 'ACTIVE',
        subscriptionExpiresAt: '2027-10-01T00:00:00Z',
      };

      setTenants(prev => [...prev, newTenant]);
      logAudit('REGISTER_SCHOOL', 'Tenant', newTenant.id, `Created new school tenant ${schoolData.name} on ${plan.name} plan`);
    } catch (err: any) {
      console.error('Failed to register school:', err.message);
    }
  };

  const toggleSchoolStatus = (tenantId: string) => {
    setTenants(prev => prev.map(t => {
      if (t.id === tenantId) {
        const nextStatus = t.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
        logAudit('UPDATE_TENANT_STATUS', 'Tenant', t.id, `Changed status of ${t.name} to ${nextStatus}`);
        return { ...t, status: nextStatus };
      }
      return t;
    }));
  };

  // Cross-tenant penetration test simulator
  const testCrossTenantSecurity = () => {
    const sourceTenantName = currentTenant?.name || 'Super Admin Global';
    const targetTenant = tenants.find(t => t.id !== currentTenant?.id) || tenants[1];

    const violationMessage = `TenantAccessDeniedException: Cross-tenant access strictly forbidden! Authenticated token belongs to ${sourceTenantName} (${currentTenant?.code || 'GLOBAL'}). Requested entity belongs to tenant ${targetTenant.name} (${targetTenant.code}). Operation blocked by Spring Security TenantFilter and logged.`;

    logAudit('SECURITY_VIOLATION_BLOCKED', 'TenantIsolation', targetTenant.id, violationMessage);

    return {
      attempt: `GET /api/v1/students?tenant_id=${targetTenant.id}`,
      sourceTenant: sourceTenantName,
      targetTenant: targetTenant.name,
      result: 'BLOCKED' as const,
      statusCode: 403,
      message: violationMessage,
    };
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        currentTenant,
        activeRole: currentUser.role,
        tenants,
        plans: INITIAL_PLANS,
        users,
        students,
        teachers,
        parents,
        classes,
        sections,
        subjects,
        attendanceRecords,
        exams,
        marks,
        invoices,
        payments,
        routines,
        assignments,
        notices,
        events,
        books,
        routes,
        hostels,
        auditLogs,
        isLoading,
        apiError,
        refreshData: fetchTenantData,
        getTenantStudents,
        getTenantTeachers,
        getTenantParents,
        getTenantClasses,
        getTenantSections,
        getTenantSubjects,
        getTenantAttendance,
        getTenantExams,
        getTenantInvoices,
        getTenantPayments,
        getTenantRoutines,
        getTenantAssignments,
        getTenantNotices,
        getTenantEvents,
        getTenantBooks,
        getTenantRoutes,
        getTenantHostels,
        switchRole,
        switchTenant,
        isAuthenticated,
        login,
        logout,
        addStudent,
        addTeacher,
        addParent,
        addClass,
        addSection,
        addSubject,
        createExam,
        recordAttendance,
        submitMarks,
        createInvoice,
        recordPayment,
        createRoutineSlot,
        createNotice,
        addAssignment,
        addEvent,
        addBook,
        issueBook,
        returnBook,
        addRoute,
        addHostel,
        updateSchoolSettings,
        addSchool,
        toggleSchoolStatus,
        testCrossTenantSecurity,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
